﻿using System.Xml.Serialization;
using BelleTire.FreedomPay.Core.TransactionResponse;
using BelleTire.FreedomPay.Core.TransactionResponse.Soap;

namespace BelleTire.FreedomPay.Core.Serialization;

public class FreedomPaySoapResponseDeserializer
{
    public FreedomPayTransactionResponse GetFreewayResponseFromXmlString(string xmlString)
    {
        var stringReader = new StringReader(xmlString);
        var serializer = new XmlSerializer(typeof(FreedomPayResponseSoapEnvelope));

        var responseEnvelope = serializer.Deserialize(stringReader) as FreedomPayResponseSoapEnvelope;

        return responseEnvelope?.Body.SubmitResponse.FreedomPayTransactionResponse ?? throw new InvalidOperationException();
    }
}