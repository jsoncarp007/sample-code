﻿using System.Text;
using System.Xml;
using System.Xml.Serialization;
using BelleTire.FreedomPay.Core.TransactionRequest;
using BelleTire.FreedomPay.Core.TransactionRequest.Soap;

namespace BelleTire.FreedomPay.Core.Serialization;

public class FreedomPaySoapRequestFactory
{
        public string GetFreewayTransactionRequestXmlString(FreedomPayApiRequest apiRequest)
        {
           var settings = new XmlWriterSettings
            {
                Encoding = Encoding.UTF8,
                CheckCharacters = false,
                NamespaceHandling = NamespaceHandling.OmitDuplicates
            };

            var namespaces = new XmlSerializerNamespaces(new[]
            {
                XmlQualifiedName.Empty,
                new XmlQualifiedName("soap", "http://schemas.xmlsoap.org/soap/envelope/"),
                new XmlQualifiedName("xsi", "http://www.w3.org/2001/XMLSchema-instance"),
                new XmlQualifiedName("xsd", "http://www.w3.org/2001/XMLSchema")
            });

            var requestTypes =
                apiRequest.GetType().GetCustomAttributes(typeof(XmlIncludeAttribute), true)
                    .OfType<XmlIncludeAttribute>()
                    .Where(attrib => attrib.Type != null)
                    .Select(attrib => attrib.Type );
            
            // wrap the request in a SOAP envelope
            var soapRequest = new FreedomPaySoapRequestEnvelope(apiRequest);
            
            // Serialize the SOAP envelope into XML
            using var stream = new StringWriter();
            using var xmlWriter = XmlWriter.Create(stream, settings);
            var serializer = new XmlSerializer(soapRequest.GetType(), requestTypes.ToArray()!);
            serializer.Serialize(xmlWriter, soapRequest, namespaces);

            // Clean/fix serialized xml output 
            var xml = stream.ToString()
                .Replace($" xsi:type=\"{apiRequest.GetType().Name}\"", string.Empty) // remove the xsi:type attribute
                .Replace("_x003A_", ":") // convert the tag names semi-colon character back (i.e. soap_x003A_Envelope back to soap:Envelope)
                .Replace(" xmlns=\"\"", string.Empty);  // remove empty namespace declarations
            
            return xml;
        }
}

