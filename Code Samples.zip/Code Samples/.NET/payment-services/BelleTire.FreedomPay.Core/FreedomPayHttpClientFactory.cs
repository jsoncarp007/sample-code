﻿using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;

namespace BelleTire.FreedomPay.Core;

public class FreedomPayHttpClientFactory
{
    public HttpClientHandler GetFreedomPayHttpClientHandler(string certificateSerialNumber)
    {
        var handler = new HttpClientHandler()
        {
            ClientCertificateOptions = ClientCertificateOption.Manual,
            SslProtocols = SslProtocols.Tls12
        };
        handler.ClientCertificates.Add(GetCertificate(certificateSerialNumber));
        return handler;
    }
    
    private X509Certificate2 GetCertificate(string certificateSerialNumber)
    {
        var localComputerStore = new X509Store(StoreName.My, StoreLocation.LocalMachine);
        localComputerStore.Open(OpenFlags.OpenExistingOnly | OpenFlags.ReadOnly);
        
        var certificate = localComputerStore.Certificates.Find(X509FindType.FindBySerialNumber,
            certificateSerialNumber, true).FirstOrDefault();

        if (certificate != null)
            return certificate;
        
        var store = new X509Store(StoreName.My, StoreLocation.CurrentUser);
        store.Open(OpenFlags.OpenExistingOnly | OpenFlags.ReadOnly);
        
        certificate = store.Certificates.Find(X509FindType.FindBySerialNumber,
            certificateSerialNumber, true).FirstOrDefault();

        if (certificate == null)
            throw new Exception($"Can't find certificate with serial number: {certificateSerialNumber}");

        return certificate;
    }
}