﻿using BelleTire.FreedomPay.Core.TransactionRequest;
using BelleTire.FreedomPay.Core.TransactionResponse;
using BelleTire.FreedomPay.Core.TransactionResponse.ReasonCode;

namespace BelleTire.FreedomPay.Core.TransactionResult;

public class FreedomPayTransactionResultProcessor
{
    private readonly FreedomPayReasonCodeFactory _freedomPayReasonCodeFactory;

    public FreedomPayTransactionResultProcessor()
    {
        _freedomPayReasonCodeFactory = new FreedomPayReasonCodeFactory();
    }

    internal FreedomPayTransactionResult ProcessTransactionException(FreedomPayApiRequest request, Exception exception) =>
        new()
        {
            InvoiceNumber = request?.InvoiceHeader?.InvoiceNumber,
            ReferenceId = request?.ReferenceCode,
            TransactionStatus = FreedomPayTransactionStatus.FatalError,
            TransactionAmount = Convert.ToDecimal(request?.PurchaseTotals?.ChargeAmount),
            StatusDetails =
                exception switch
                {
                    InvalidOperationException => $"Invalid Operation / Serialization Error",
                    HttpRequestException httpRequestException => $"Http Error: {httpRequestException.StatusCode?.GetType().Name}",
                    not null => $"General Exception",
                    _ => throw new ArgumentOutOfRangeException(nameof(exception), exception, null)
                } +
                $", Detail: {exception.Message}, Inner: {exception.InnerException?.Message}, Stack: {exception.StackTrace}"
        };

    internal FreedomPayTransactionResult ProcessTransactionResponse(FreedomPayTransactionResponse response, FreedomPayApiRequest request)
    {
        var reasonCodeDetail = _freedomPayReasonCodeFactory.GetReasonCode(response?.ReasonCode ?? -1);
        
        var transactionResult = new FreedomPayTransactionResult()
        {
            ReferenceId = response?.MerchantReferenceCode,
            ApprovalCode = response?.AuthorizationReply?.AuthorizationCode.ToString(),
            TransactionId = response?.RequestID,
            InvoiceNumber = request?.InvoiceHeader?.InvoiceNumber,
            TransactionStatus = GetTransactionStatus(reasonCodeDetail),
            TransactionAmount = Convert.ToDecimal(request?.PurchaseTotals?.ChargeAmount),
            PromotionOptions = GetPromotionOptions(response!),
            AccountToken = response?.TokenInformation?.Token,
            PromotionCode = request?.Items?.FirstOrDefault(i=>!string.IsNullOrEmpty(i.PromoCode))?.PromoCode,
            PromotionApr = response?.AuthorizationReply?.AccountApr,
            AprType = response?.AuthorizationReply?.AccountAprType,
            StatusDetails = $"{reasonCodeDetail.ReasonCode}: {reasonCodeDetail.Description}, Type: {reasonCodeDetail.Type}"
        };
        return transactionResult;
    }

    private FreedomPayPromotionOption[] GetPromotionOptions(FreedomPayTransactionResponse response)
    {
        if (response?.PromoReply?.Promotions?.Promo == null) return Array.Empty<FreedomPayPromotionOption>();

        return response.PromoReply.Promotions.Promo
            .Select(promotionOptionResponse => new FreedomPayPromotionOption()
            {
                Description = promotionOptionResponse.Description,
                Threshold = promotionOptionResponse.Threshold,
                PromotionCode = promotionOptionResponse.Code?.ToString() ?? string.Empty,
                InterestRate = promotionOptionResponse.InterestRate,
                Disclaimer = promotionOptionResponse.Disclaimer
            })
            .ToArray();
    }

    private FreedomPayTransactionStatus GetTransactionStatus(FreedomPayReasonCode reasonCodeDetail)
    {
        return reasonCodeDetail switch
        {
            // success 
            { Type: FreedomPayReasonCodeType.Success } => FreedomPayTransactionStatus.Success,
            
            // transaction declined 
            { Type: FreedomPayReasonCodeType.InsufficientFunds } => FreedomPayTransactionStatus.TransactionDeclined,
            { Type: FreedomPayReasonCodeType.CardDeclined } => FreedomPayTransactionStatus.TransactionDeclined,
            
            // duplicate transaction 
            { Type: FreedomPayReasonCodeType.DuplicateTransaction } => FreedomPayTransactionStatus.DuplicateTransaction,
            
            // void issues
            { Type: FreedomPayReasonCodeType.VoidFailedNoActionRequired } => FreedomPayTransactionStatus.NonCriticalError,
            { Type: FreedomPayReasonCodeType.VoidDuplicate } => FreedomPayTransactionStatus.NonCriticalError,
            
            // possible fraud
            { Type: FreedomPayReasonCodeType.StolenCard } => FreedomPayTransactionStatus.PossibleFraud,
            { Type: FreedomPayReasonCodeType.LostOrStolenCard } => FreedomPayTransactionStatus.PossibleFraud,
            { Type: FreedomPayReasonCodeType.SuspectedFraud } => FreedomPayTransactionStatus.PossibleFraud,
            
            // authorization issues
            { Type: FreedomPayReasonCodeType.AuthorizationError } => FreedomPayTransactionStatus.AuthorizationError,
            { Type: FreedomPayReasonCodeType.AuthorizationExpired } => FreedomPayTransactionStatus.AuthorizationError,
            { Type: FreedomPayReasonCodeType.DuplicateAuthorization } => FreedomPayTransactionStatus.AuthorizationError,
            { Type: FreedomPayReasonCodeType.ManualAuthorizationRequired } => FreedomPayTransactionStatus.AuthorizationError,
            
            // temporary / communication errors
            { Type: FreedomPayReasonCodeType.CommunicationFailure } => FreedomPayTransactionStatus.TemporaryError,
           
            // Currency conversion availability notifications
            { Type: FreedomPayReasonCodeType.DccAvailable } => FreedomPayTransactionStatus.NonCriticalError,
            { Type: FreedomPayReasonCodeType.DccUnavailable } => FreedomPayTransactionStatus.NonCriticalError,
            
            // card/account data mismatch
            { Type: FreedomPayReasonCodeType.InvalidCvv } => FreedomPayTransactionStatus.ValidationFailed,
            { Type: FreedomPayReasonCodeType.InvalidPin } => FreedomPayTransactionStatus.ValidationFailed,
            
            // other data error 
            { Type: FreedomPayReasonCodeType.RequestDataInvalid } => FreedomPayTransactionStatus.RequestDataError,
            
            // card reader error
            { Type: FreedomPayReasonCodeType.CardReaderError } => FreedomPayTransactionStatus.CardReaderDataError,
            
            // fatal errors - to be reviewed by IT
            { Type: FreedomPayReasonCodeType.TokenError } => FreedomPayTransactionStatus.FatalError,
            { Type: FreedomPayReasonCodeType.FatalError } => FreedomPayTransactionStatus.FatalError,
            { Type: FreedomPayReasonCodeType.RequestStructureInvalid } => FreedomPayTransactionStatus.FatalError,
            { Type: FreedomPayReasonCodeType.InvalidLocation } => FreedomPayTransactionStatus.FatalError,
            _ => FreedomPayTransactionStatus.FatalError
        };
    }
}

