﻿namespace BelleTire.FreedomPay.Core.TransactionResult;

public class FreedomPayTransactionResult
{
    public FreedomPayTransactionStatus TransactionStatus { get; set; }

    public string? StatusDetails { get; set; }
    public string? ReferenceId { get; set; }
    public string? ApprovalCode { get; set; }
    public string? TransactionId { get; set; }
    public string? InvoiceNumber { get; set; }
    public string? AccountToken { get; set; }
    public decimal? TransactionAmount { get; set; }
    public string? PromotionCode { get; set; }
    public decimal? PromotionApr { get; set; }
    public string? AprType { get; set; }
    public string? PromotionDisclosure { get; set; }
    
    public FreedomPayPromotionOption[]? PromotionOptions { get; set; }

}