namespace BelleTire.FreedomPay.Core.TransactionResult;

public class FreedomPayPromotionOption
{
    public string PromotionCode { get; set; } = null!;
    public string Description { get; set; } = null!;
    public decimal Threshold { get; set; }
    public decimal InterestRate { get; set; }
    public string? Disclaimer { get; set; }
}