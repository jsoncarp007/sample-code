﻿using BelleTire.FreedomPay.Core.TransactionRequest;
using BelleTire.FreedomPay.Core.TransactionResult;

namespace BelleTire.FreedomPay.Core;

public class FreedomPayService : IFreedomPayService
{
    private readonly FreedomPayFreewayService _freewayService;
    private readonly FreedomPayTransactionResultProcessor _transactionResultProcessor;

    public FreedomPayService(HttpClient freewayHttpClient)
    {
        _freewayService = new FreedomPayFreewayService(freewayHttpClient);
        _transactionResultProcessor = new FreedomPayTransactionResultProcessor();
    } 
        
    public async Task<FreedomPayTransactionResult> SubmitTransaction(FreedomPayApiRequest apiRequest)
    {
        try
        {
            var transactionResponse = await _freewayService.SendTransactionRequest(apiRequest).ConfigureAwait(false);
            return _transactionResultProcessor.ProcessTransactionResponse(transactionResponse, apiRequest);
        }
        catch (Exception ex)
        {
            return _transactionResultProcessor.ProcessTransactionException(apiRequest, ex);
        }
    }
}