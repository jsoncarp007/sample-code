﻿using BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

namespace BelleTire.FreedomPay.Core.TransactionRequest;

public abstract class FreedomPayReferencedTransactionRequest : FreedomPayApiRequest
{
    /// <summary>
    /// For Serialization Only
    /// </summary>
    protected FreedomPayReferencedTransactionRequest()
    {
    }

    /// <summary>
    /// FreedomPay Freeway - Base class for a transaction referencing a previous transaction (i.e. void or refund)
    /// </summary>
    /// <param name="transactionSourceData">Transaction Source Data (store id, terminal/workstation id, user id)</param>
    /// <param name="transactionId">The unique identifier for the previous transaction (generated internally and returned in the request result)</param>
    /// <param name="orderReferenceNumber">The reference number for the transaction (Belle order/Invoice number)</param>
    protected FreedomPayReferencedTransactionRequest(TransactionSourceData transactionSourceData, string transactionId, string orderReferenceNumber) : base(
        transactionSourceData)
    {
        OriginalRequestId = transactionId;
        ReferenceCode = orderReferenceNumber;
        //FollowUp = new TransactionRequestFollowUp() {Run = "true"};
        InvoiceHeader = new TransactionRequestInvoiceHeader() { InvoiceNumber = orderReferenceNumber };
    }
    
}