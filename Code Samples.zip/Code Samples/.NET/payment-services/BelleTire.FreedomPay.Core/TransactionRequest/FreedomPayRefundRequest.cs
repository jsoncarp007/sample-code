﻿using BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

namespace BelleTire.FreedomPay.Core.TransactionRequest;

public class FreedomPayRefundRequest : FreedomPayReferencedTransactionRequest
{
    /// <summary>
    /// For Serialization Only
    /// </summary>
    public FreedomPayRefundRequest() {}

    /// <summary>
    /// FreedomPay Freeway - Request to refund a previous transaction (to original card/account and for original amount)
    /// </summary>
    /// <param name="transactionSourceData">Transaction Source Data (store id, terminal/workstation id, user id)</param>
    /// <param name="transactionId">The unique identifier for the previous transaction (generated internally and returned in the request result)</param>
    /// <param name="orderReferenceNumber">The reference number for the transaction (Belle order/Invoice number)</param>
    /// <param name="chargeAmount">The amount charged to the card to be refunded</param>
    public FreedomPayRefundRequest(TransactionSourceData transactionSourceData, string transactionId, string orderReferenceNumber, decimal chargeAmount) : base(transactionSourceData, transactionId, orderReferenceNumber)
    {
        Refund = new TransactionRequestRefund() { Run = "true" };
        PurchaseTotals = new TransactionRequestPurchaseTotals() { ChargeAmount = chargeAmount.ToString("F2") };
    }
}