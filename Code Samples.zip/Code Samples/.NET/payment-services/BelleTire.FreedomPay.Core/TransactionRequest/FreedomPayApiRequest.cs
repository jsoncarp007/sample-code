﻿using System.Xml.Serialization;
using BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

namespace BelleTire.FreedomPay.Core.TransactionRequest;
// api docs - \\marvin\is\Projects\CreditCard\FreedomPay
// wsdl - https://cs.uat.freedompay.com/Freeway/Service.asmx?wsdl

[Serializable]
[XmlInclude(typeof(FreedomPayVoidRequest))]
[XmlInclude(typeof(FreedomPayRefundRequest))]
[XmlInclude(typeof(FreedomPayPromotionLookupRequest))]
[XmlInclude(typeof(FreedomPayAuthorizationRequest))]
[XmlInclude(typeof(FreedomPayDebitTransactionRequest))]
[XmlInclude(typeof(FreedomPayCreditTransactionRequest))]
[XmlInclude(typeof(FreedomPayAccountLookupRequest))]
[XmlType("request", IncludeInSchema = false, AnonymousType = true)]
public abstract class FreedomPayApiRequest
{
    /// <summary>
    /// For Serialization Only 
    /// </summary>
    protected FreedomPayApiRequest(){}
    
    
   /// <summary>
   /// Base constructor for a FreedomPay "Freeway" API request
   /// </summary>
   /// <param name="transactionSourceData">Transaction Source Data (store id, terminal/workstation id, user id)</param>
    protected FreedomPayApiRequest(TransactionSourceData transactionSourceData)
    {
        StoreId = transactionSourceData.StoreId;
        TerminalId = transactionSourceData.TerminalId;
        EmployeeId = transactionSourceData.EmployeeId;
            
        ClientMetaData = new TransactionRequestClientMetaData()
        {
            ApplicationUser = Environment.MachineName,
            ApplicationVersion = "1.0.0",
            ApplicationName = "BelleTire.FreedomPay",
        };

        ReferenceCode = string.IsNullOrEmpty(ReferenceCode) ? BuildReferenceCode() : ReferenceCode;
    }

    /// <summary>
    /// Creates a unique reference code for this transaction
    ///
    /// </summary>
    /// <returns>a unique reference code for this transaction (string)</returns>
    private string BuildReferenceCode()
    {
        var guidString = Guid.NewGuid().ToString().Replace("-", String.Empty);

        return $"FP-{guidString}";
    }

    /// <summary>
    /// Freeway Store Identification Number
    /// </summary>
    [XmlElement(ElementName = "storeId")]
    public string? StoreId { get; set; } 

    /// <summary>
    /// Freeway Terminal Identification Number
    /// </summary>
    [XmlElement(ElementName = "terminalId")]
    public string? TerminalId { get; set; } 

    /// <summary>
    /// Enhanced Security Key - Required for eCommerce and Mobile
    /// </summary>
    [XmlElement(ElementName = "esKey")]
    public string? EnhancedSecurityKey { get; set; } 

    /// <summary>
    /// Employee number of clerk performing transactions
    /// </summary>
    [XmlElement(ElementName = "clerkId")]
    public string? EmployeeId { get; set; } 

    /// <summary>
    /// Comments associated with the transaction
    /// </summary>
    [XmlElement(ElementName = "comments")]
    public string? Comments { get; set; } 

    /// <summary>
    /// Merchant-generated order reference or tracking number
    /// </summary>
    [XmlElement(ElementName = "merchantReferenceCode")]
    public string? ReferenceCode { get; set; } 

    /// <summary>
    /// Merchant System assigned Batch Id for Client Initiated Batch Requests
    /// </summary>
    [XmlElement(ElementName = "merchantBatchId")]
    public string? BatchId { get; set; } 

    /// <summary>
    /// Original request ID for follow-on requests
    /// </summary>
    [XmlElement(ElementName = "orderRequestId")]
    public string? OriginalRequestId { get; set; } 

    /// <summary>
    /// Authorization parameters
    /// </summary>
    [XmlElement(ElementName = "ccAuthService")]
    public TransactionRequestTransactionAuthorization? Authorization { get; set; } 

    /// <summary>
    /// Refund (credit) parameters
    /// </summary>
    [XmlElement(ElementName = "ccCreditService")]
    public TransactionRequestRefund? Refund { get; set; } 

    /// <summary>
    /// Client device/system environment details 
    /// </summary>
    [XmlElement(ElementName = "clientMetadata")]
    public TransactionRequestClientMetaData? ClientMetaData { get; set; } 

    /// <summary>
    /// Private label account inquiry parameters
    /// </summary>
    [XmlElement(ElementName = "inquiryService")]
    public TransactionRequestInquiry? TransactionRequestInquiry { get; set; }

    /// <summary>
    /// Void parameters
    /// </summary>
    [XmlElement(ElementName = "voidService")]
    public TransactionRequestVoid? Void { get; set; }

    /// <summary>
    /// Name, address and contact data for transacting customer
    /// </summary>
    [XmlElement(ElementName = "billTo")]
    public TransactionRequestBillTo? BillTo { get; set; }

    /// <summary>
    /// Credit Card Information
    /// </summary>
    [XmlElement(ElementName = "card")]
    public TransactionRequestCard? Card { get; set; } 

    /// <summary>
    /// Used in conjunction with orderRequestID - must be true or blank 
    /// </summary>
    [XmlElement(ElementName = "ccFollowupService")]
    public TransactionRequestFollowUp? FollowUp { get; set; }

    /// <summary>
    /// Invoice/Check information
    /// </summary>
    [XmlElement(ElementName = "invoiceHeader")]
    public TransactionRequestInvoiceHeader? InvoiceHeader { get; set; } 

    /// <summary>
    /// Point? of sale information 
    /// </summary>
    [XmlElement(ElementName = "pos")] 
    public TransactionRequestPos? PointOfSaleData { get; set; } 

    /// <summary>
    /// Transaction amounts and subtotals
    /// </summary>
    [XmlElement(ElementName = "purchaseTotals")]
    public TransactionRequestPurchaseTotals? PurchaseTotals { get; set; }

    /// <summary>
    /// Terms promotion parameters
    /// </summary>
    [XmlElement(ElementName = "promoService")]
    public TransactionRequestPromotionService? PromotionService { get; set; }

    /// <summary>
    /// Token creation request parameters
    /// </summary>
    [XmlElement(ElementName = "tokenCreateService")]
    public TransactionRequestTokenCreateService? TokenCreateService { get; set; }

    /// <summary>
    /// Line detail information
    /// </summary>
    [XmlArrayItem(ElementName="item", Type = typeof(TransactionRequestItem))]
    [XmlArray(ElementName = "items")] 
    public List<TransactionRequestItem> Items { get; set; } 

    /// <summary>
    /// Member Data information
    /// </summary>
    [XmlElement(ElementName = "memberData")]
    public TransactionRequestMemberData MemberData { get; set; } 

    /// <summary>
    /// Capture parameters
    /// </summary>
    [XmlElement(ElementName = "ccCaptureService")]
    public TransactionRequestCaptureService CaptureService { get; set; } 
    
}