﻿using BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

namespace BelleTire.FreedomPay.Core.TransactionRequest;

public abstract class FreedomPayAccountRequest : FreedomPayApiRequest
{
    /// <summary>
    /// For Serialization Only 
    /// </summary>
    protected FreedomPayAccountRequest()
    {
    }

    /// <summary>
    /// FreedomPay Freeway - Request including Card/Account data
    /// </summary>
    /// <param name="transactionSourceData">Transaction Source Data (store id, terminal/workstation id, user id)</param>
    /// <param name="accountNumber">Card number or token</param>
    /// <param name="freedomPayAccountNumberType">Card or Token (default=Card)</param>
    /// <param name="expirationMonth">Expiration month (required for Card)</param>
    /// <param name="expirationYear">Expiration year (required for Card)</param>
    /// <param name="cvv">CVV code (optional, not all cards have CVV)</param>
    protected FreedomPayAccountRequest(TransactionSourceData transactionSourceData, string accountNumber,
        FreedomPayAccountNumberType freedomPayAccountNumberType = FreedomPayAccountNumberType.Card, int? expirationMonth = null, int? expirationYear = null, string? cvv = null) : base(transactionSourceData)
    {
        CreateCard(freedomPayAccountNumberType, accountNumber, expirationMonth, expirationYear, cvv);
    }

    private void CreateCard(FreedomPayAccountNumberType? accountNumberType, string accountNumber, int? expirationMonth, int? expirationYear, string? cvv)
    {
        if (accountNumberType is FreedomPayAccountNumberType.Token)
            CreateTokenCard(accountNumber);
        else
            CreateCard(accountNumber, expirationMonth, expirationYear, cvv);
    }

    private void CreateCard(string accountNumber, int? expirationMonth, int? expirationYear, string? cvv)
    {
        Card = new TransactionRequestCard
        {
            AccountNumber = accountNumber,
            Cvv = cvv ?? string.Empty,
            CvvCodeIndicator =
                !string.IsNullOrEmpty(cvv)
                    ? "0"
                    : "1", // "0" indicates CVV not provided, needed for new card accounts that haven't been issued a physical card yet
            ExpirationMonth = expirationMonth.HasValue ? expirationMonth.Value.ToString("00") : string.Empty,
            ExpirationYear = expirationYear.HasValue ? expirationYear.Value.ToString() : string.Empty
        };
    }
    
    private void CreateTokenCard(string accountToken)
    {
        Card = new TransactionRequestCard()
        {
            AccountNumber = accountToken,
            CardType = "token"
        };
    }
    /// <summary>
    /// Sets the selected promotion code
    /// </summary>
    /// <param name="promotionCode">Promotion code (options returned from promotion lookup request)</param>
    internal void SetPromotionSelection(string promotionCode)
    {
        PromotionService = new TransactionRequestPromotionService()
        {
            Run = "true",
            Action = "validate",
            ScenarioCode = "3",
        };
        Items = new List<TransactionRequestItem>() {new() {PromoCode = promotionCode}};
    }
    
    public void SetAccountData(string firstName, string lastName, string street1, string street2, string city, string state, string zip)
    {
        BillTo = new TransactionRequestBillTo()
        {
            City = city, State = state, Street1 = street1, Street2 = street2, FirstName = firstName,
            LastName = lastName, PostalCode = zip
        };
    }
    
}