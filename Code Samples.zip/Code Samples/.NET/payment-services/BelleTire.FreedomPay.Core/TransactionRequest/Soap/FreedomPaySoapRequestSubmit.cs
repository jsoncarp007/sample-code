﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.Soap;

[Serializable]
public class FreedomPaySoapRequestSubmit
{
   [XmlElement(ElementName="request", Type = typeof(FreedomPayApiRequest))]
    public FreedomPayApiRequest Request { get; set; } = null!;

    [XmlAttribute("xmlns")]
    public string XmlNamespace => "http://freeway.freedompay.com/";
    
    public FreedomPaySoapRequestSubmit() {}

    public FreedomPaySoapRequestSubmit(FreedomPayApiRequest request)
    {
        Request = request;
    }
}