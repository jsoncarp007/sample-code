﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.Soap;

[Serializable]
public class FreedomPaySoapRequestBody
{
    [XmlElement(ElementName="Submit", Namespace = "http://freeway.freedompay.com/")]
    public FreedomPaySoapRequestSubmit Submit { get; set; }

    [XmlAttribute("xmlns:xsi")]
    public string Xsi => "http://www.w3.org/2001/XMLSchema-instance";
    
    [XmlAttribute("xmlns:xsd")]
    public string Xsd => "http://www.w3.org/2001/XMLSchema";

    public FreedomPaySoapRequestBody()
    {
        Submit = new FreedomPaySoapRequestSubmit();
    }

    public FreedomPaySoapRequestBody(FreedomPayApiRequest request)
    {
        Submit = new FreedomPaySoapRequestSubmit(request);
    }
}