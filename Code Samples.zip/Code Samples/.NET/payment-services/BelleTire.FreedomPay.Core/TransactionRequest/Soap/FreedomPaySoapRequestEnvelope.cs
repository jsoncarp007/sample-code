﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.Soap;

[Serializable]
[XmlType("soap:Envelope")]
public class FreedomPaySoapRequestEnvelope
{
    [XmlElement(ElementName="soap:Body")]
    public FreedomPaySoapRequestBody Body { get; set; }

    [XmlAttribute("xmlns:soap")] 
    public string XmlNamespaceSoap => "http://schemas.xmlsoap.org/soap/envelope";
    
    [XmlAttribute("xmlns:xsi")] 
    public string XmlXsiNamespace => "http://www.w3.org/2001/XMLSchema-instance";
    
    [XmlAttribute("xmlns:xsd")] 
    public string XmlXsdNamespace => "http://www.w3.org/2001/XMLSchema";

    public FreedomPaySoapRequestEnvelope()
    {
        Body = new FreedomPaySoapRequestBody();
    }

    public FreedomPaySoapRequestEnvelope(FreedomPayApiRequest request)
    {
        Body = new FreedomPaySoapRequestBody(request);
    }
}