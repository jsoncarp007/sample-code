﻿using BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

namespace BelleTire.FreedomPay.Core.TransactionRequest;

public class FreedomPayPromotionLookupRequest : FreedomPayAccountRequest
{
    /// <summary>
    /// For serialization only
    /// </summary>
    public FreedomPayPromotionLookupRequest() {}

    /// <summary>
    /// FreedomPay Freeway - Promotion Options Lookup Request
    /// </summary>
    /// <param name="transactionSourceData">Transaction Source Data (store id, terminal/workstation id, user id)</param>
    /// <param name="transactionAmount">Amount of the transaction to find promotion options for</param>
    /// <param name="accountNumber">Card number or token</param>
    /// <param name="freedomPayAccountNumberType">Card or Token (default=Card)</param>
    /// <param name="expirationMonth">Expiration month (required for Card)</param>
    /// <param name="expirationYear">Expiration year (required for Card)</param>
    /// <param name="cvv">CVV code (optional, not all cards have CVV)</param>
    public FreedomPayPromotionLookupRequest(TransactionSourceData transactionSourceData, decimal transactionAmount, string accountNumber, FreedomPayAccountNumberType freedomPayAccountNumberType, int? expirationMonth = null, int? expirationYear = null, string? cvv = null) 
        : base(transactionSourceData, accountNumber, freedomPayAccountNumberType, expirationMonth, expirationYear, cvv)
    {
        PurchaseTotals = new TransactionRequestPurchaseTotals() {ChargeAmount = transactionAmount.ToString("F2")};
        EnablePromotionLookup();
    }

    private void EnablePromotionLookup()
    {
        PromotionService = new TransactionRequestPromotionService() { Run = "true", Action = "lookup", ScenarioCode = "3"};
    }
}