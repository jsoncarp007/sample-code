﻿using BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

namespace BelleTire.FreedomPay.Core.TransactionRequest;

[Serializable]
public abstract class FreedomPayTransactionRequest : FreedomPayAccountRequest
{
    /// <summary>
    /// For serialization only
    /// </summary>
    protected FreedomPayTransactionRequest()
    {
    }

    /// <summary>
    /// FreedomPay Freeway - Transaction Request
    ///
    /// Base class for a card/account transaction (abstract)
    /// </summary>
    /// <param name="transactionSourceData">Transaction Source Data (store id, terminal/workstation id, user id)</param>
    /// <param name="orderReferenceNumber">Reference number for the transaction (order number)</param>
    /// <param name="transactionAmount">Amount of the transaction to find promotion options for</param>
    /// <param name="accountNumber">Card number or token</param>
    /// <param name="freedomPayAccountNumberType">Card or Token (optional, default=Card)</param>
    /// <param name="expirationMonth">Expiration month (optional, required for Card)</param>
    /// <param name="expirationYear">Expiration year (optional, required for Card)</param>
    /// <param name="cvv">CVV code (optional, not all cards have CVV)</param>
    /// <param name="promotionCode">Promotion code (optional, if card supports promos will default to "standard" - i.e. no financing)</param>
    protected FreedomPayTransactionRequest(TransactionSourceData transactionSourceData, string orderReferenceNumber, decimal transactionAmount, string accountNumber, FreedomPayAccountNumberType freedomPayAccountNumberType, int? expirationMonth, int? expirationYear, string? cvv, string? zipCode, string promotionCode)
        : base(transactionSourceData, accountNumber, freedomPayAccountNumberType, expirationMonth, expirationYear, cvv)
    {
        SetTransactionRequestValues(orderReferenceNumber, transactionAmount, cvv, zipCode);
        SetPromotionSelection(promotionCode);
    }

    /// <summary>
    /// Sets the request parameters for a sale/transaction
    /// </summary>
    /// <param name="orderReferenceNumber"></param>
    /// <param name="transactionAmount"></param>
    /// <param name="cvv"></param>
    /// <param name="zipCode"></param>
    private void SetTransactionRequestValues(string orderReferenceNumber, decimal transactionAmount, string? cvv, string? zipCode)
    {
        ReferenceCode = orderReferenceNumber;
        PurchaseTotals = new TransactionRequestPurchaseTotals() {ChargeAmount = transactionAmount.ToString("F2")};
        InvoiceHeader = new TransactionRequestInvoiceHeader() {InvoiceNumber = orderReferenceNumber};
        Authorization = new TransactionRequestTransactionAuthorization() {Run = "true", TransactionType = "inquiry", EnableAvs = !string.IsNullOrEmpty(zipCode) ? "Y" : string.Empty, CommerceIndicator = !string.IsNullOrEmpty(cvv) ? "internet" : string.Empty}; }
}