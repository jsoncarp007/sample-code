using BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

namespace BelleTire.FreedomPay.Core.TransactionRequest;

public class FreedomPayAccountLookupRequest : FreedomPayAccountRequest
{
    /// <summary>
    /// For serialization only
    /// </summary>
    public FreedomPayAccountLookupRequest() {}

    /// <summary>
    /// FreedomPay Freeway - Account lookup request, by account number
    /// </summary>
    /// <param name="transactionSourceData">Transaction Source Data (store id, terminal/workstation id, user id)</param>
    /// <param name="accountNumber">Card number</param>
    /// <param name="cvv">Cvv code</param>
    /// <param name="expirationMonth">Expiration month</param>
    /// <param name="expirationYear">Expiration year</param>
    public FreedomPayAccountLookupRequest(TransactionSourceData transactionSourceData, string accountNumber, string cvv, int expirationMonth, int expirationYear) : base(transactionSourceData, accountNumber)
    {
        Card.CardType = "credit";
        Card.Cvv = cvv;
        Card.ExpirationMonth = expirationMonth.ToString();
        Card.ExpirationYear = expirationYear.ToString();
        CaptureService = new TransactionRequestCaptureService() {Run = "true" };
        Authorization = new TransactionRequestTransactionAuthorization() {Run = "true"};
        TokenCreateService = new TransactionRequestTokenCreateService() { Run = "true", TokenType = "7"};
        PurchaseTotals = new TransactionRequestPurchaseTotals() {ChargeAmount = "0.00"};
        //TransactionRequestInquiry = new TransactionRequestInquiry() {Run = "true", Fields = "B", VerifyMode = "zip"};
        
    }
}