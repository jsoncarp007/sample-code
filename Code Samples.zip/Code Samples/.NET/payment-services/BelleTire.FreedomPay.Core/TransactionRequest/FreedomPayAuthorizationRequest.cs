﻿using BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

namespace BelleTire.FreedomPay.Core.TransactionRequest;

public class FreedomPayAuthorizationRequest : FreedomPayAccountRequest
{
    /// <summary>
    /// For serialization only
    /// </summary>
    public FreedomPayAuthorizationRequest() {}

    /// <summary>
    /// FreedomPay Freeway - Authorization Request - required to obtain financing details for selected GYCC promotion
    /// </summary>
    /// <param name="transactionSourceData">Transaction Source Data (store id, terminal/workstation id, user id)</param>
    /// <param name="transactionAmount">Amount of the transaction</param>
    /// <param name="accountNumber">Card number or token</param>
    /// <param name="freedomPayAccountNumberType">Card or Token (default=Card)</param>
    /// <param name="expirationMonth">Expiration month (required for Card)</param>
    /// <param name="expirationYear">Expiration year (required for Card)</param>
    /// <param name="cvv">CVV code (optional, not all cards have CVV)</param>
    /// <param name="promotionCode">Selected Promotion Code (GYCC)</param>
    /// <param name="zipCode">Zip Code</param>
    public FreedomPayAuthorizationRequest(TransactionSourceData transactionSourceData, decimal transactionAmount,
        string accountNumber, FreedomPayAccountNumberType freedomPayAccountNumberType, int? expirationMonth = null,
        int? expirationYear = null, string? cvv = null, string? promotionCode = null, string? zipCode = null)
        : base(transactionSourceData, accountNumber, freedomPayAccountNumberType, expirationMonth, expirationYear, cvv)
    {
        PurchaseTotals = new TransactionRequestPurchaseTotals() {ChargeAmount = transactionAmount.ToString("F2")};
        Authorization = new TransactionRequestTransactionAuthorization() {Run = "true", TransactionType = "inquiry", EnableAvs = cvv != null ? "Y" : string.Empty, CommerceIndicator = cvv != null ? "internet" : string.Empty};
        //CaptureService = new TransactionRequestCaptureService() {Run = "true"};
        TokenCreateService = new TransactionRequestTokenCreateService() {Run = "true", TokenType = "7" };

        if (promotionCode != null)
            SetPromotionSelection(promotionCode);
    }
}