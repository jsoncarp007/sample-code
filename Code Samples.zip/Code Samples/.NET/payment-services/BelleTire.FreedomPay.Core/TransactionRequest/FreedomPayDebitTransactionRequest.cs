namespace BelleTire.FreedomPay.Core.TransactionRequest;

[Serializable]
public class FreedomPayDebitTransactionRequest : FreedomPayTransactionRequest
{
    public FreedomPayDebitTransactionRequest() {}
    
    public FreedomPayDebitTransactionRequest(TransactionSourceData transactionSourceData, string orderReferenceNumber, decimal transactionAmount, string cardNumber, int expirationMonth, int expirationYear, string? zipCode, string? cvv) 
        : base(transactionSourceData, orderReferenceNumber, transactionAmount, cardNumber, FreedomPayAccountNumberType.Card, expirationMonth, expirationYear, zipCode, cvv, null)
    {
        Card.CardType = "debit";
    }
}