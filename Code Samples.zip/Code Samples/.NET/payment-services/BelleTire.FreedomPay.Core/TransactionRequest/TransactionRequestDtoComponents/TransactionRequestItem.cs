﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

[XmlType("item", IncludeInSchema = false, AnonymousType = true)]
public class TransactionRequestItem
{
    /// <summary>
    /// Line Number
    ///
    /// Incremental number of item in ticket(i.e. – 0 -> 10 items= 11 items)
    ///
    /// If left blank, the items are numbered automatically
    /// 
    /// </summary>
    [XmlElement(ElementName = "id", DataType = "integer")]
    public string Id { get; set; } = null!;

    /// <summary>
    /// Total of all EID(s) and other applied discounts the line item
    /// </summary>
    [XmlElement(ElementName = "discountAmount")]
    public string DiscountAmount { get; set; } = null!;

    /// <summary>
    /// Used to determine the discount status of an item
    ///
    /// ‘Y’ if item was discounted 
    /// ‘N’ if not
    /// 
    /// Default is ‘Y’ if discountAmount is nonzero, else ‘N’ 
    /// 
    /// </summary>
    [XmlElement(ElementName = "discountFlag")]
    public string DiscountFlag { get; set; } = null!;

    /// <summary>
    /// Used to determine if the tax was applied to the total amount
    /// 
    /// This is intended primarily for e.g.movie theaters which have a ‘tax included’ pricing model to simplify making change
    ///
    /// ‘Y’ if totalAmount includes taxAmount 
    /// ‘N’ if totalAmount does not include taxAmount
    ///
    /// Default is ‘N’ if not specified
    /// 
    /// </summary>
    [XmlElement(ElementName = "taxIncludedFlag")]
    public string TaxIncludedFlag { get; set; } = null!;


    /// <summary>
    /// Code assigned to the product
    ///
    /// 15 chars
    /// 
    /// </summary>
    [XmlElement(ElementName = "productCode")]
    public string ProductCode { get; set; } = null!;

    /// <summary>
    /// UPC assigned to the product
    ///
    /// 14 chars
    /// 
    /// </summary>
    [XmlElement(ElementName = "productUPC")]
    public string ProductUPC { get; set; } = null!;

    /// <summary>
    /// SKU assigned to the product
    ///
    /// 30 chars
    /// 
    /// </summary>
    [XmlElement(ElementName = "productSKU")]
    public string ProductSKU { get; set; } = null!;

    /// <summary>
    /// Name of the product
    ///
    /// 35 chars
    /// 
    /// </summary>
    [XmlElement(ElementName = "productName")]
    public string ProductName { get; set; } = null!;

    /// <summary>
    /// Description of the product
    ///
    /// 40 chars
    /// 
    /// </summary>
    [XmlElement(ElementName = "productDescription")]
    public string ProductDescription { get; set; } = null!;

    /// <summary>
    /// Manufacturer of the product
    ///
    /// 50 chars
    /// 
    /// </summary>
    [XmlElement(ElementName = "productMake")]
    public string ProductMake { get; set; } = null!;

    /// <summary>
    /// Model of the product
    ///
    /// 50 chars
    /// 
    /// </summary>
    [XmlElement(ElementName = "productModel")]
    public string ProductModel { get; set; } = null!;

    /// <summary>
    /// Year of the product
    ///
    /// 4 digit preferred
    /// 
    /// </summary>
    [XmlElement(ElementName = "productYear", DataType = "integer")]
    public string ProductYear { get; set; } = null!;

    /// <summary>
    /// Part Number of the product
    ///
    /// 50 chars
    /// 
    /// </summary>
    [XmlElement(ElementName = "productPartNumber")]
    public string ProductPartNumber { get; set; } = null!;

    /// <summary>
    /// Governmental purchasing codes
    ///
    /// Up to 11 digits for lineitem classification
    /// 
    /// </summary>
    [XmlElement(ElementName = "commodityCode")]
    public string CommodityCode { get; set; } = null!;

    /// <summary>
    /// Serial Number 1 of the product
    ///
    /// 50 chars
    /// 
    /// </summary>
    [XmlElement(ElementName = "productSerial1")]
    public string ProductSerial1 { get; set; } = null!;

    /// <summary>
    /// Serial Number 2 of the product
    ///
    /// 50 chars
    /// 
    /// </summary>
    [XmlElement(ElementName = "productSerial2")]
    public string ProductSerial2 { get; set; } = null!;

    /// <summary>
    /// Serial Number 3 of the product
    ///
    /// 50 chars
    /// 
    /// </summary>
    [XmlElement(ElementName = "productSerial3")]
    public string ProductSerial3 { get; set; } = null!;

    /// <summary>
    /// Customer Asset Number assigned to the item
    ///
    /// 50 chars
    /// 
    /// </summary>
    [XmlElement(ElementName = "customerAssetId")]
    public string CustomerAssetId { get; set; } = null!;

    /// <summary>
    /// Price per unit of the item
    /// </summary>
    [XmlElement(ElementName = "unitPrice")]
    public string UnitPrice { get; set; } = null!;

    /// <summary>
    /// Unit of measure for the item
    ///
    /// 3 chars
    /// 
    /// </summary>
    [XmlElement(ElementName = "unitOfMeasure")]
    public string UnitOfMeasure { get; set; } = null!;

    /// <summary>
    /// Original unit price, before any discount(s) are applied
    ///
    /// Used to track original unit price, before EID discount(s). Needed if unitPrice is modified after applying EIDs.
    /// 
    /// </summary>
    [XmlElement(ElementName = "origUnitPrice")]
    public string OrigUnitPrice { get; set; } = null!;

    /// <summary>
    /// Quantity of item purchased
    ///
    /// Default = 1
    /// 
    /// </summary>
    [XmlElement(ElementName = "quantity", DataType = "integer")]
    public string Quantity { get; set; } = null!;

    /// <summary>
    /// Total amount of item (unit price x quantity), after discounts (use origTotalAmount and origUnitPrice if discounts are applied)
    /// </summary>
    [XmlElement(ElementName = "totalAmount")]
    public string TotalAmount { get; set; } = null!;

    /// <summary>
    /// Original total amount if different from totalAmount
    ///
    /// Used to track total value, before EID discounts.  Needed if totalAmount is modified after applying EIDs.
    /// 
    /// </summary>
    [XmlElement(ElementName = "origTotalAmount")]
    public string OrigTotalAmount { get; set; } = null!;

    /// <summary>
    /// Total amount of tax applicable to the item
    /// </summary>
    [XmlElement(ElementName = "taxAmount")]
    public string TaxAmount { get; set; } = null!;

    /// <summary>
    /// Amount of Freight cost applicable to the item
    /// </summary>
    [XmlElement(ElementName = "freightAmount")]
    public string FreightAmount { get; set; } = null!;

    /// <summary>
    /// Capture as raw-data unless used with promoService 
    /// </summary>
    [XmlElement(ElementName = "promoCode")]
    public string PromoCode { get; set; } = null!;

    /// <summary>
    /// General sales code for item
    ///
    /// 1 char
    ///
    /// 'S’ for Sale 
    /// ‘R’ for Return 
    /// ‘L’ for Lease/Rental
    /// 
    /// </summary>
    [XmlElement(ElementName = "saleCode")]
    public string SaleCode { get; set; } = null!;

    /// <summary>
    /// Merchant-assigned “format code” identifying how the custom fields should be interpreted
    ///
    /// Default is 0
    /// </summary>
    [XmlElement(ElementName = "customFormatId", DataType = "integer")]
    public string CustomFormatId { get; set; } = null!;

}