﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

public class TransactionRequestPurchaseTotals
{
    /// <summary>
    /// ISO-4217 (3-letter or 3-digit) currency code
    ///
    /// Default is ‘USD’
    /// 
    /// </summary>
    [XmlElement(ElementName = "currency")]
    public string Currency { get; set; } = null!;

    /// <summary>
    /// Total discounted amount from purchase
    ///
    /// This includes both discounts from EID, as well as discounts applied by the merchant
    /// </summary>
    [XmlElement(ElementName = "discountTotal")]
    public string DiscountTotal { get; set; } = null!;

    /// <summary>
    /// Total amount of duty applied to the ticket
    /// </summary>
    [XmlElement(ElementName = "dutyTotal")]
    public string DutyTotal { get; set; } = null!;

    /// <summary>
    /// Total amount of the freight applied to the ticket
    /// </summary>
    [XmlElement(ElementName = "freightTotal")]
    public string FreightTotal { get; set; } = null!;

    /// <summary>
    /// Total amount of tax applied to the ticket 
    /// </summary>
    [XmlElement(ElementName = "taxTotal")]
    public string TaxTotal { get; set; } = null!;

    /// <summary>
    /// Amount of tip applied to the ticket
    /// </summary>
    [XmlElement(ElementName = "tipAmount")]
    public string TipAmount { get; set; } = null!;

    /// <summary>
    /// Amount of cash back requested by the customer
    /// </summary>
    [XmlElement(ElementName = "cashBackAmount")]
    public string CashBackAmount { get; set; } = null!;

    /// <summary>
    /// Total amount of the invoice, after all surcharges, taxes and discounts
    /// </summary>
    [XmlElement(ElementName = "invoiceTotal")]
    public string InvoiceTotal { get; set; } = null!;

    /// <summary>
    /// Tender amount, may be different than the actual grand total.
    ///
    /// Final amount charged to a payment method
    /// </summary>
    [XmlElement(ElementName = "chargeAmount")]
    public string ChargeAmount { get; set; } = null!;

    /// <summary>
    /// No description in API docs
    /// </summary>
    [XmlElement(ElementName = "serviceCharge")]
    public string ServiceCharge { get; set; } = null!;

}