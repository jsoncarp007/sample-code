﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

public class TransactionRequestClientMetaData
{
    /// <summary>
    /// Name of the client application - required for certification
    /// </summary>
    [XmlElement(ElementName = "applicationName")]
    public string ApplicationName { get; set; } = null!;

    /// <summary>
    /// Version number of the client application 
    /// </summary>
    [XmlElement(ElementName = "applicationVersion")]
    public string ApplicationVersion { get; set; } = null!;

    /// <summary>
    /// Normally computer name of register originating transaction.  For e-commerce can be computer name or web server.
    /// </summary>
    [XmlElement(ElementName = "workstationId")]
    public string WorkstationId { get; set; } = null!;

    /// <summary>
    /// User information (i.e. – name or ID) for client application
    /// </summary>
    [XmlElement(ElementName = "applicationUser")]
    public string ApplicationUser { get; set; } = null!;

    /// <summary>
    /// Environment client is running on 
    /// </summary>
    [XmlElement(ElementName = "environment")]
    public string Environment { get; set; } = null!;

    /// <summary>
    /// Library client is using to communicate with Freeway
    /// </summary>
    [XmlElement(ElementName = "library")]
    public string Library { get; set; } = null!;

    /// <summary>
    /// Library version client is using to communicate with Freeway
    /// </summary>
    [XmlElement(ElementName = "libraryVersion")]
    public string LibraryVersion { get; set; } = null!;

    /// <summary>
    /// If not using system libraries the library used for TLS communication e.g., OpenSSL, LibreSSL, etc
    /// </summary>
    [XmlElement(ElementName = "securityLibrary")]
    public string SecurityLibrary { get; set; } = null!;

    /// <summary>
    /// Version Number of client application security library
    /// </summary>
    [XmlElement(ElementName = "securityLibraryVersion")]
    public string SecurityLibraryVersion { get; set; } = null!;

    /// <summary>
    /// Used to identify the device generating the card data
    ///
    /// [POI application type] '-' [hardware type code] ':' [device serial number]
    /// </summary>
    [XmlElement(ElementName = "poiDeviceIdentifier")]
    public string DeviceIdentifier { get; set; } = null!;

}