﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;


public class TransactionRequestRefund
{
    /// <summary>
    /// Specify “true” to request a credit/refund - must be true or empty string
    /// </summary>
    [XmlAttribute(AttributeName = "run")]
    public string Run { get; set; } = null!;

    /// <summary>
    /// Transaction Type definition for specific actions defined in Restrictions/Format
    ///
    /// ‘return’/blank = Regular merchandise return
    /// ‘payment’ = Bill payment(certain private label cards)
    ///
    /// Gift Cards only:
    /// ‘issue’ = Gift Card Issue
    /// ‘reload’ = Gift Card Reload
    /// ‘activate’ = Gift Card Activate
    /// 
    /// </summary>
    [XmlElement(ElementName = "transType")]
    public string TransactionType { get; set; } = null!;
}