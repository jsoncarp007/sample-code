using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

public class TransactionRequestCaptureService 
{
    /// <summary>
    /// Specify “true” to request a capture
    ///
    /// Must be "true" or empty string
    /// </summary>
    [XmlAttribute(AttributeName = "run")]
    public string Run { get; set; } = null!;
        
    /// <summary>
    /// Allows a single private-label authorization to be captured against multiple times
    ///
    /// 'Y’ to indicate that this is a partial capture of an authorization
    /// </summary>
    [XmlElement(ElementName = "isSplitTransaction")]
    public string IsSplitTransaction { get; set; } = null!;
        
}