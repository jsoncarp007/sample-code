﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

public class TransactionRequestMemberData
{
    /// <summary>
    /// Date of enrollment
    /// </summary>
    [XmlElement(ElementName = "enrollmentDate")]
    public string EnrollmentDate { get; set; } = null!;

    /// <summary>
    /// Whether the member is new
    /// </summary>
    [XmlElement(ElementName = "isNewMember")]
    public string IsNewMember { get; set; } = null!;

    /// <summary>
    /// The information relating to the enrollment of the Member
    /// </summary>
    [XmlElement(ElementName = "memberIdentification")]
    public string MemberIdentification { get; set; } = null!;

    /// <summary>
    /// The medium used to represent the information relating to the enrollment of the Member
    ///
    /// Example: "enrollment-qr-code"
    /// 
    /// </summary>
    [XmlElement(ElementName = "memberIdentificationType")]
    public string MemberIdentificationType { get; set; } = null!;

}