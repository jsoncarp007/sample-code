﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

[SoapInclude(typeof(TransactionRequestTransactionAuthorization))]
public class TransactionRequestTransactionAuthorization
{
    /// <summary>
    /// Specify “true” to request an authorization
    /// </summary>
    [XmlAttribute(AttributeName = "run")]
    public string Run { get; set; } = null!;

    /// <summary>
    /// Transaction type discriminator for usage in explicit scenarios 
    ///
    /// ‘purchase’ = Regular purchase
    /// 
    ///  ‘verify’ = Refund CVV/AVS-only verification
    ///
    /// If not submitted, default is 
    /// either ‘purchase’ (transaction amount > $0.00) or ‘verify’ (transaction amount = $0.00)
    ///
    ///  Gift Cards only:
    ///   ‘cashout’ = Cash-out gift card
    ///   ‘inquiry’ = Prepaid/Gift Card balance Inquiry
    ///   ‘deactivate’ = Gift Card deactivate
    /// 
    /// </summary>
    [XmlElement(ElementName = "transType")]
    public string TransactionType { get; set; } = null!;

    /// <summary>
    /// Indicates whether a partial authorization can be accepted by the merchant
    ///
    /// ‘Y’ if a partial authorization is acceptable
    /// ‘N’ to decline if the full amount cannot be authorized
    ///
    ///  Default value is ‘N’ if not submitted
    /// 
    /// </summary>
    [XmlElement(ElementName = "allowPartial")]
    public string AllowPartial { get; set; } = null!;

    /// <summary>
    /// If available, indicates to return the balance of the account used.
    ///
    /// ‘Y’ if the system is capable of printing or displaying an account balance
    /// </summary>
    [XmlElement(ElementName = "returnBalance")]
    public string ReturnBalance { get; set; } = null!;


    /// <summary>
    /// Authorization type
    ///
    ///  No value: Normal electronic authorization
    /// ‘verbal’: Authorization was obtained by phone(requires verbalAuthCode field)
    /// ‘forced’: Same as ‘verbal’
    /// ‘adjustment’: Modify the amount of an existing authorization(can adjust in either direction, based on the new chargeAmount)
    /// ‘link’: Link an authorization to a previously submitted transaction (used for industry-specific MITs)
    /// ‘reauth’: Create a new authorization based on an existing one ‘offline’: No authorization was performed (merchant assumes all risk for transactions with no authorizations)
    ///
    /// </summary>
    [XmlElement(ElementName = "authType")]
    public string AuthorizationType { get; set; } = null!;


    /// <summary>
    /// Authorization code previously obtained by phone. Typically superseded by orderRequestID.  Required if authType = ‘verbal’ or ‘forced’
    /// </summary>
    [XmlElement(ElementName = "verbalAuthCode")]
    public string VerbalAuthorizationCode { get; set; } = null!;

    /// <summary>
    /// Used in functionality that allows support for local ticket searching in some Point? of Sale solutions
    ///
    /// Original authorization amount (needed for authType = verbal/forced)
    /// 
    /// </summary>
    [XmlElement(ElementName = "origAuthAmount")]
    public string OriginalAuthorizationAmount { get; set; } = null!;

    /// <summary>
    /// Setting to control if an AVS is performed
    ///
    /// ‘Y’ = Request AVS
    /// ‘N’ = Do not perform AVS
    /// Blank/Omitted: Automatically perform AVS if billTo.street1 or billTo.postalCode is set
    /// 
    /// </summary>
    [XmlElement(ElementName = "enableAvs")]
    public string EnableAvs { get; set; } = null!;

    /// <summary>
    /// Indicates transaction was stored and forwarded
    ///
    /// Set to Y if the transaction is being replayed from a store and forward queue
    /// 
    /// </summary>
    [XmlElement(ElementName = "offline")]
    public string OfflineTransaction { get; set; } = null!;

    /// <summary>
    /// ECI Code Should be left as default
    ///
    /// If not specified, uses ‘default’, 
    /// otherwise:
    /// 
    /// ‘moto’: Mail-order/Telephone-order
    /// ‘reauthorize’: Reauthorize a Merchant Initiated Transaction (MIT)
    /// ‘recurring’: Subsequent transactions in a recurring chain.
    /// ‘internet’: internet transaction
    /// ‘retail’: retail transaction
    /// ‘delayed’: delayed charges for a Merchant Initiated transaction
    /// ‘unscheduled’: unscheduled credential on file transaction
    /// 
    /// </summary>
    [XmlElement(ElementName = "commerceIndicator")]
    public string CommerceIndicator { get; set; } = null!;


    /// <summary>
    /// Recurring transaction flag
    ///
    /// ‘Y’: Transaction is part of a recurring chain.
    /// 
    /// </summary>
    [XmlElement(ElementName = "recurring")]
    public string Recurring { get; set; } = null!;

    /// <summary>
    /// Total number of installment payments in a series associated with a merchant transaction
    ///
    /// Required for all installment payment transactions
    /// 
    /// </summary>
    [XmlElement(ElementName = "installmentCount", DataType = "integer")]
    public string InstallmentCount { get; set; } = null!;

    /// <summary>
    /// Exemption reasons for why SCA was not performed (multiple values supported)
    ///
    /// Each character indicates a requested exemption:
    ///
    /// ‘L’ = Low Value
    /// ‘R’ = Transaction Risk Analysis
    /// ‘T’ = Trusted Merchant
    /// ‘S’ = Secure Corporate Payment
    /// ‘D’ = Delegated Authentication
    /// 
    /// </summary>
    [XmlElement(ElementName = "scaExemptions")]
    public string ScaExemptions { get; set; } = null!;

}