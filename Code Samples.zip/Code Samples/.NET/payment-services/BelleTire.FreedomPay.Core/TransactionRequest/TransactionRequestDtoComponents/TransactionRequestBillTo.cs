﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

public class TransactionRequestBillTo
{
    /// <summary>
    /// Customer IP address, for internet orders
    /// </summary>
    [XmlElement(ElementName = "ipAddress")]
    public string IpAddress { get; set; } = null!;

    /// <summary>
    /// Merchant assigned customer Id 
    /// </summary>
    [XmlElement(ElementName = "customerId")]
    public string CustomerId { get; set; } = null!;

    /// <summary>
    /// Company name
    /// </summary>
    [XmlElement(ElementName = "company")]
    public string Company { get; set; } = null!;

    /// <summary>
    /// Title on billing address
    /// </summary>
    [XmlElement(ElementName = "title")]
    public string Title { get; set; } = null!;

    /// <summary>
    /// First name
    /// </summary>
    [XmlElement(ElementName = "firstName")]
    public string FirstName { get; set; } = null!;

    /// <summary>
    /// Middle name
    /// </summary>
    [XmlElement(ElementName = "middleName")]
    public string MiddleName { get; set; } = null!;

    /// <summary>
    /// Last name
    /// </summary>
    [XmlElement(ElementName = "lastName")]
    public string LastName { get; set; } = null!;

    /// <summary>
    /// Suffix
    /// </summary>
    [XmlElement(ElementName = "suffix")]
    public string Suffix { get; set; } = null!;

    /// <summary>
    /// Street Address 1
    /// </summary>
    [XmlElement(ElementName = "street1")]
    public string Street1 { get; set; } = null!;
    
    /// <summary>
    /// Street Address 2
    /// </summary>
    [XmlElement(ElementName = "street2")]
    public string Street2 { get; set; } = null!;

    /// <summary>
    /// Street Address 3
    /// </summary>
    [XmlElement(ElementName = "street3")]
    public string Street3 { get; set; } = null!;

    /// <summary>
    /// Street Address 4
    /// </summary>
    [XmlElement(ElementName = "street4")]
    public string Street4 { get; set; } = null!;

    /// <summary>
    /// City
    /// </summary>
    [XmlElement(ElementName = "city")]
    public string City { get; set; } = null!;

    /// <summary>
    /// State
    /// </summary>
    [XmlElement(ElementName = "state")]
    public string State { get; set; } = null!;

    /// <summary>
    /// Postal Code
    /// </summary>
    [XmlElement(ElementName = "postalCode")]
    public string PostalCode { get; set; } = null!;

    /// <summary>
    /// Country
    /// </summary>
    [XmlElement(ElementName = "country")]
    public string Country { get; set; } = null!;

    /// <summary>
    /// Phone number
    /// </summary>
    [XmlElement(ElementName = "phoneNumber")]
    public string PhoneNumber { get; set; } = null!;

    /// <summary>
    /// Fax number
    /// </summary>
    [XmlElement(ElementName = "faxNumber")]
    public string FaxNumber { get; set; } = null!;

    /// <summary>
    /// Email
    /// </summary>
    [XmlElement(ElementName = "email")]
    public string Email { get; set; } = null!;

    /// <summary>
    /// Last 4 of SSN
    /// </summary>
    [XmlElement(ElementName = "ssn")]
    public string Ssn { get; set; } = null!;

}