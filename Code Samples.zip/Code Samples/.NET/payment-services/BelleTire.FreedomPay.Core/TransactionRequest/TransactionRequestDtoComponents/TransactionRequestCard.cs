﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

public class TransactionRequestCard
{
    /// <summary>
    /// Contains the Primary Account Number (PAN) for the card information
    /// Required unless track 1 or track 2 is provided by the ‘pos’ element
    ///
    /// Use zero (0) when using ‘cash’ as a cardType
    /// Loyalty prefix in binmap table is 1 alpha char + 2 numeric chars (e.g.M01). 
    /// Format is Prefix:AccountNumber(e.g.M01:123456).
    /// </summary>
    [XmlElement(ElementName = "accountNumber")]
    public string AccountNumber { get; set; } = null!;

    /// <summary>
    /// Sub-account for debit transactions
    ///
    /// C – Checking (default) 
    /// S - Savings
    /// 
    /// </summary>
    [XmlElement(ElementName = "accountType")]
    public string AccountType { get; set; } = null!;

    /// <summary>
    /// Card or token type
    ///
    /// ‘credit’: Credit 
    /// ‘debit’: Debit 
    /// ‘token’: CardStor™ Token 
    /// ‘cash’: Cash Transaction 
    /// ‘sv’: Stored value transactions 
    /// 'mobile': Mobile transactions 
    /// ‘moniker’: MicroFrame™ single use token 
    /// ‘gc’: Gift Card 
    /// ‘ebtfood’: EBT (Food-stamp mode) 
    /// ‘ebtcash’: EBT (Cash mode) 
    /// ‘loyalty’: Loyalty Card 
    /// ‘freedomqr’: QR Code
    /// 
    /// Default is ‘credit’
    /// 
    /// </summary>
    [XmlElement(ElementName = "cardType")]
    public string CardType { get; set; } = null!;

    /// <summary>
    /// CVV Code Indicator
    ///
    /// 0: Not Provided 
    /// 1: Provided 
    /// 2: Illegible 
    /// 3: Missing from card 
    /// 
    /// Default is 1 if cvNumber is provided, otherwise 0
    /// 
    /// </summary>
    [XmlElement(ElementName = "cvIndicator")]
    public string CvvCodeIndicator { get; set; } = null!;

    /// <summary>
    /// CVV code from back of card
    ///
    /// 3-4 digits, all numeric
    /// </summary>
    [XmlElement(ElementName = "cvNumber")]
    public string Cvv { get; set; } = null!;

    /// <summary>
    /// Card expiration month
    /// 
    /// Required unless track 1 or track 2 is provided by the ‘pos’ element
    /// 
    /// </summary>
    [XmlElement(ElementName = "expirationMonth", DataType = "integer")]
    public string ExpirationMonth { get; set; } = null!;

    /// <summary>
    /// Card expiration year 
    /// Required unless track 1 or track 2 is provided by the ‘pos’ element
    ///
    /// 4-digit year preferred 
    /// 
    /// </summary>
    [XmlElement(ElementName = "expirationYear", DataType = "integer")]
    public string ExpirationYear { get; set; } = null!;

    /// <summary>
    /// EBT Issue Number
    /// </summary>
    [XmlElement(ElementName = "issueNumber", DataType = "integer")]
    public string IssueNumber { get; set; } = null!;

    /// <summary>
    /// Name as it appears on Card (26 chars)
    /// </summary>
    [XmlElement(ElementName = "nameOnCard")]
    public string CardholderName { get; set; } = null!;

    /// <summary>
    /// RFU (Credit card start month)
    /// </summary>
    [XmlElement(ElementName = "startMonth", DataType = "integer")]
    public string StartMonth { get; set; } = null!;

    /// <summary>
    /// RFU (Credit card start year)
    ///
    /// 4-digit year preferred
    /// 
    /// </summary>
    [XmlElement(ElementName = "startYear", DataType = "integer")]
    public string StartYear { get; set; } = null!;

    /// <summary>
    /// RFU
    ///
    /// 3 digit (0-9)
    /// 
    /// </summary>
    [XmlElement(ElementName = "serviceRestrictionCode")]
    public string ServiceRestrictionCode { get; set; } = null!;

    /// <summary>
    /// DUKPT SIMD/KSN
    /// 
    /// Required for cardType=’debit’
    ///
    /// 16-20 char - Only [0-9], [A-F], [a-f] 
    ///
    /// </summary>
    [XmlElement(ElementName = "pinKsn")]
    public string DebitPinKsn { get; set; } = null!;

    /// <summary>
    /// Debit PIN block
    /// 
    /// Required for cardType=’debit’
    ///
    /// 16 char - Only [0-9], [A-F], [a-f] 
    /// 
    /// </summary>
    [XmlElement(ElementName = "pinBlock")]
    public string DebitPinBlock { get; set; } = null!;

    /// <summary>
    /// Used for verbal authorizations of EBT cards
    ///
    /// 30 char
    /// 
    /// </summary>
    [XmlElement(ElementName = "voucherNumber")]
    public string VoucherNumber { get; set; } = null!;

    /// <summary>
    /// Gift card PIN/Passcode Data
    /// </summary>
    [XmlElement(ElementName = "pass")]
    public string PasscodeData { get; set; } = null!;

}