﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

public class TransactionRequestInvoiceHeader
{
    /// <summary>
    /// Date that the transaction will be considered to have happened on for batching and reporting purposes.
    ///
    /// ISO 8601 Combined Date and Time Format
    /// 
    /// </summary>
    [XmlElement(ElementName = "businessDate")]
    public string BusinessDate { get; set; } = null!;

    /// <summary>
    /// Invoice Number
    ///
    /// 20 char - required
    /// 
    /// </summary>
    [XmlElement(ElementName = "invoiceNumber")]
    public string InvoiceNumber { get; set; } = null!;

    /// <summary>
    /// Invoice date/time
    ///
    /// ISO 8601 Combined Date and Time Format
    /// 
    /// </summary>
    [XmlElement(ElementName = "invoiceDate")]
    public string InvoiceDate { get; set; } = null!;

    /// <summary>
    /// Date of purchase order
    ///
    /// ISO 8601 Combined Date and Time Format
    /// 
    /// </summary>
    [XmlElement(ElementName = "purchaserOrderDate")]
    public string PurchaseOrderDate { get; set; } = null!;

    /// <summary>
    /// Type of goods
    ///
    /// ‘unspecified’: Unspecified 
    /// ‘digital’: Digital goods 
    /// ‘physical’: Physical goods 
    ///
    /// Default if not provided is 'unspecified'
    /// 
    /// </summary>
    [XmlElement(ElementName = "goodsIndicator")]
    public string TypeOfGoods { get; set; } = null!;

    /// <summary>
    /// Purchase order number assigned to the invoice
    ///
    /// 25 chars
    /// 
    /// </summary>
    [XmlElement(ElementName = "customerPO")]
    public string CustomerPurchaseOrderNumber { get; set; } = null!;

}