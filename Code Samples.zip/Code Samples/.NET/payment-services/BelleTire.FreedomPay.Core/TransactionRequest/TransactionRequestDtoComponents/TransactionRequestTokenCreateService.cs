﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

public class TransactionRequestTokenCreateService
{
    /// <summary>
    /// Specify “true” to request a CardStor Token
    ///
    /// Must be true or empty string
    /// </summary>
    [XmlAttribute(AttributeName = "run")]
    public string Run { get; set; } = null!;

    /// <summary>
    /// Type of token to be created.
    ///
    /// To be provided by FreedomPay team
    /// </summary>
    [XmlElement(ElementName = "type")]
    public string TokenType { get; set; } = null!;

    /// <summary>
    /// Pass “Y” to create a dynamic-expiration token.
    /// </summary>
    [XmlElement(ElementName = "dynExp")]
    public string DynamicExpiration { get; set; } = null!;

    /// <summary>
    /// Up to 63 characters of printable ASCII characters (0x20-0x7E) that will be stored with the token and returned each time the token is used to perform a transaction.
    ///
    /// Must not place any sensitive data in this field (CVV numbers, track data, PAN.)
    ///
    /// 63 chars
    /// 
    /// </summary>
    [XmlElement(ElementName = "posData")]
    public string ReferenceData { get; set; } = null!;

}