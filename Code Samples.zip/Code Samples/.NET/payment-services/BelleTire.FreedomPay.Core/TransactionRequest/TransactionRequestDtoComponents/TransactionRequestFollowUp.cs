﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

public class TransactionRequestFollowUp
{
    /// <summary>
    /// Specify “true” to request a follow up transaction; used in conjunction with orderRequestID - must be "true" or empty string
    /// </summary>
    [XmlAttribute(AttributeName = "run")]
    public string Run { get; set; } = null!;
}