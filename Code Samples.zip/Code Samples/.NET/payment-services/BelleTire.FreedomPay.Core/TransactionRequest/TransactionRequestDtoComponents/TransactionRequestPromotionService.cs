﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

public class TransactionRequestPromotionService
{
    /// <summary>
    /// Specify “true” in order to request a promo operation (terms based)
    ///
    /// Must be "true" or blank
    /// </summary>
    [XmlAttribute(AttributeName = "run")]
    public string Run { get; set; } = null!;

    /// <summary>
    /// Allows request to specify functionality available for promotions (terms based)
    ///
    /// 0 No Options (Default; not required) 
    /// 1 Force – if promotion override is allowed and promotion code entered exists, will be passed through to the end-host
    /// 8 Fetch Upsell promos (only for private label partners configured for upsell)
    ///
    /// Response Hints:
    /// 0 None (Default; no hints available) 
    /// 1 Apply All – this signifies that a particular promotion code applies to all items on the ticket, and
    /// could be used with all line-items for the follow-on selection(and validation). This allows faster “bucketing”
    /// on the end-user system; especially in the case where the back-end host does not support multiple promotions per
    /// invoice/ticket (and a splitting of the ticket is required). 
    /// 
    /// </summary>
    [XmlElement(ElementName = "options", DataType = "integer")]
    public string Options { get; set; } = null!;

    /// <summary>
    /// Indicates desired promotion engine service (terms based)
    ///
    /// ‘lookup’ = Check ticket for applicable promotions, including end-user entered promotion(s)
    /// ‘validate’ = Verify that currently selected promotion(s) are valid for this ticket
    /// </summary>
    [XmlElement(ElementName = "action")]
    public string Action { get; set; } = null!;

    /// <summary>
    /// Defines the ‘transaction scenario’, constraining promotions returned to specific categorizations of sale(s)
    ///
    /// Implementation specific – are only applicable to promotions available to a specific merchant and/or private label.
    /// </summary>
    [XmlElement(ElementName = "scenarioCode")]
    public string ScenarioCode { get; set; } = null!;

    /// <summary>
    /// Codes defined on a project-level basis when establishing reasons for using Forces
    /// </summary>
    [XmlElement(ElementName = "forceCode")]
    public string ForceCode { get; set; } = null!;

    /// <summary>
    /// Comment to supplement the force reason
    ///
    /// 100 chars
    /// 
    /// </summary>
    [XmlElement(ElementName = "forceMessage")]
    public string ForceMessage { get; set; } = null!;

}