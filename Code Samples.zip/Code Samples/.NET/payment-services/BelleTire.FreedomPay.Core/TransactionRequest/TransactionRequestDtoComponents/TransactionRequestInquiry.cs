﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

public class TransactionRequestInquiry
{
    /// <summary>
    /// Specify “true” to request a balance inquiry/account status check
    ///
    /// Must be "true" or empty string
    /// </summary>
    [XmlAttribute(AttributeName = "run")]
    public string Run { get; set; } = null!;

    /// <summary>
    /// Specifies the type of verification to use for the balance/status inquiry
    ///
    /// ‘zip’ : Use first five digits of billTo.postalCode
    /// ‘phone’: Use the last four digits of the billTo.phoneNumber
    /// ‘ssn’ : Use the last four digits of the Social Security Number in the billTo.ssn
    /// </summary>
    [XmlElement(ElementName = "verifyMode")]
    public string VerifyMode { get; set; } = null!;

    /// <summary>
    /// Specifies the pieces of data that the service should retrieve
    /// Used as a concatenated string
    /// Only available in certain environments
    /// Example:
    /// “BPL” would ask for the customer’s current account balance, last payment date and amount, and the minimum amount and due date for their next payment.
    /// ‘B’ : Request current account balance.
    /// ‘C’ : Request current available credit.
    /// ‘P’ : Request due date and minimum amount of next payment.
    /// ‘L’ : Request date and amount of last payment.
    /// ‘#’ : Request customer service phone number.
    /// </summary>
    [XmlElement(ElementName = "fields")]
    public string Fields { get; set; } = null!;

}