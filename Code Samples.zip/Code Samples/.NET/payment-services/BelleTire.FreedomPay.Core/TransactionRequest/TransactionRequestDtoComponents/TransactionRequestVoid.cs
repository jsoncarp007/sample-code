﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

public class TransactionRequestVoid
{
    /// <summary>
    /// Specify “true” to request a void; used in conjunction with orderRequestID
    ///
    /// Must be “true” or omitted/blank
    /// 
    /// </summary>
    [XmlAttribute(AttributeName = "run")]
    public string Run { get; set; } = null!;

    /// <summary>
    /// Reason
    ///
    /// ‘cancel’/blank = User initiated 
    /// 
    /// EMV only:
    /// ‘error’ = EMV error 
    /// ‘latersp’ = Late response 
    /// ‘badmac’ = MAC error 
    /// ‘chipaac’ = Chip Declined 
    /// 
    /// </summary>
    [XmlElement(ElementName = "reason")]
    public string Reason { get; set; } = null!;


    /// <summary>
    /// Indicates transaction was stored and forwarded
    ///
    /// Set to Y if the transaction is being replayed from a store and forward queue 
    /// </summary>
    [XmlElement(ElementName = "offline")]
    public string Offline { get; set; } = null!;

}