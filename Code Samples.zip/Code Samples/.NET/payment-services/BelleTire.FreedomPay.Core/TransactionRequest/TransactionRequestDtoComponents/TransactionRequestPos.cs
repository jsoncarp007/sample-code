﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

/// <summary>
/// Card / device data  
/// </summary>
public class TransactionRequestPos
{
    /// <summary>
    /// Number of the POS device
    /// </summary>
    [XmlElement(ElementName = "registerNumber", DataType = "integer")]
    public string RegisterNumber { get; set; } = null!;

    /// <summary>
    /// Indicates how card information was entered
    ///
    /// ‘keyed’ = Manually entered 
    /// ‘swiped’ = Card was swiped 
    /// ‘rfid’ = Contactless transponder was read (Paywave, ApplePay, etc) 
    /// ‘icc’ = Chip read (EMV, Interac) 
    /// ‘ricc’ = Contactless chip read (EMV, Interac) 
    /// ‘scanned’ = Barcode or QR Code 
    /// ‘inapp’: In-App (Apple or Google Wallet) 
    /// 
    /// Default is ‘swiped’ if track1 or track2 data is present, otherwise 'keyed'
    ///  
    /// </summary>
    [XmlElement(ElementName = "entryMode")]
    public string EntryMode { get; set; } = null!;

    /// <summary>
    /// Unencrypted credit card track 1 contents
    /// </summary>
    [XmlElement(ElementName = "track1")]
    public string Track1 { get; set; } = null!;

    /// <summary>
    /// Unencrypted credit card track 2 contents
    /// </summary>
    [XmlElement(ElementName = "track2")]
    public string Track2 { get; set; } = null!;

    /// <summary>
    /// A string of encrypted track 1 data 
    /// </summary>
    [XmlElement(ElementName = "track1e")]
    public string Track1Encrypted { get; set; } = null!;

    /// <summary>
    /// A string of encrypted track 2 data 
    /// </summary>
    [XmlElement(ElementName = "track2e")]
    public string Track2Encrypted { get; set; } = null!;

    /// <summary>
    /// Length of the track 1 data (encrypted MSR only) 
    /// </summary>
    [XmlElement(ElementName = "track1len", DataType = "integer")]
    public string Track1Length { get; set; } = null!;

    /// <summary>
    /// Length of the track 2 data (encrypted MSR only) 
    /// </summary>
    [XmlElement(ElementName = "track2length", DataType = "integer")]
    public string Track2Length { get; set; } = null!;

    /// <summary>
    /// A string of encrypted track data
    /// </summary>
    [XmlElement(ElementName = "tracke")]
    public string TrackEncrypted { get; set; } = null!;


    /// <summary>
    /// Specifies the type of encryption used by the eMSR
    /// 
    /// ‘tdes’ = Triple DES 
    /// ‘aes’ = AES Encryption 
    /// ‘onguard’ = OnGuard 
    /// ‘roam’ = ROAM 
    /// ‘applewallet’ = Apple Wallet 
    /// ‘googlewallet’ = Google Wallet 
    /// ‘rsa’ = RSA Encryption
    /// 
    /// </summary>
    [XmlElement(ElementName = "encMode")]
    public string EncryptionMode { get; set; } = null!;

    /// <summary>
    /// Key serial number obtained when using an encrypting magstripe reader
    /// </summary>
    [XmlElement(ElementName = "trackKsn")]
    public string TrackKsn { get; set; } = null!;

    /// <summary>
    /// ‘Y’ = Card present 
    /// ‘N’ = Card not present
    ///
    /// Default is ‘Y’ if not specified
    /// </summary>
    [XmlElement(ElementName = "cardPresent")]
    public string CardPresent { get; set; } = null!;

    /// <summary>
    /// Specifies the physical hardware (credit card device) that is performing the transaction (MSR = Magnetic Swipe Reader)
    ///
    /// ‘idtechkb’ = ID TECH in keyboard mode 
    /// ‘idtechhid’ = ID TECH in HID mode 
    /// ‘ingenico’ = Ingenico device 
    /// ‘magtek’ = Magtek device 
    /// ‘equinox’ = Equinox device 
    /// ‘applepay’ = Apple device 
    /// ‘googlepay’ = Google device
    /// 
    /// </summary>
    [XmlElement(ElementName = "msrType")]
    public string CardReaderType { get; set; } = null!;

    /// <summary>
    /// Local date/time at POS device
    ///
    /// ISO 8601 Combined Date and Time Format
    /// 
    /// </summary>
    [XmlElement(ElementName = "paymentDate")]
    public string PurchaseOrderDate { get; set; } = null!;

    /// <summary>
    /// Chip device capabilities (EMV)
    ///
    /// Each character indicates a 
    /// supported feature: 
    /// 
    /// ‘P’ = Debit Pin Entry 
    /// ‘M’ = Magnetic Indicator 
    /// ‘R’ = Contactless magnetic stripe entry 
    /// ‘C’ = Chip 
    /// ‘K’ = Keyed manual entry 
    /// ‘V’ – No terminal (for AVR/IVR units only) 
    /// 
    /// Testing use only
    /// 
    /// </summary>
    [XmlElement(ElementName = "caps")]
    public string ChipDeviceCapabilities { get; set; } = null!;

    /// <summary>
    /// Chip data block (EMV)
    ///
    /// This element is a base64-encoded string representing a list of TLV (Tag Length Value) elements used 
    /// for smart card communication with FreeWay. The TLV data follows the X.690 BER-TLV encoding rules. 
    /// 
    /// The structure of this data is as follows: 
    /// 
    /// Bytes 1 and 2: 16-bit length prefix. This is a big-endian encoded length prefix of all the TLV data. 
    /// 
    /// Bytes 3 to N:  The binary contents of the TLV data follow the BER-TLV encoding rules. 
    /// 
    /// Example Base-64 string: 
    /// AISCAlwAhAegAAAAAxAQlQUCgACAAJoDFQURnAEAXyoCCECfAgYAAAAAJQCfAwYAAAAAAACfCQIAjJ8QBwYBCgOgAAC
    /// fGgIIQJ8eCDgwNDg1NzI0nyYIkYH8vharqjCfJwGAnzMD4PjInzQDHgMAnzUBIp82AgACnzcE7B9Zl59BBAAAAyM=
    ///
    /// Hexadecimal? dump of the binary chip data: 
    /// 
    /// 00000000- 00 84 82 02 5C 00 84 07 A0 00 00 00 03 10 10 95 [....\...........] 
    /// 00000001- 05 02 80 00 80 00 9A 03 15 05 11 9C 01 00 5F 2A [.............._*] 
    /// 00000002- 02 08 40 9F 02 06 00 00 00 00 25 00 9F 03 06 00 [..@.......%.....] 
    /// 00000003- 00 00 00 00 00 9F 09 02 00 8C 9F 10 07 06 01 0A [................] 
    /// 00000004- 03 A0 00 00 9F 1A 02 08 40 9F 1E 08 38 30 34 38 [........@...8048] 
    /// 00000005- 35 37 32 34 9F 26 08 91 81 FC BE 16 AB AA 30 9F [5724.&........0.] 
    /// 00000006- 27 01 80 9F 33 03 E0 F8 C8 9F 34 03 1E 03 00 9F ['...3.....4.....] 
    /// 00000007- 35 01 22 9F 36 02 00 02 9F 37 04 EC 1F 59 97 9F [5.".6....7...Y..] 
    /// 00000008- 41 04 00 00 03 23 [A....# ]  
    ///
    /// The first to bytes 0x00 and 0x84 is the length prefix of the message. So a total of 132 bytes should follow the length prefix. The total length of the message /// is 134 bytes, which includes the 2 byte length prefix. 
    /// 
    /// The rest of the bytes are the BER-TLV encoded chip data elements.
    /// 
    /// This example shows the following tag length value pairs: 
    /// 
    /// Tag Value 
    /// 82 5c00 
    /// 84 a0000000031010 
    /// 95 0280008000 
    /// 9a 150511 
    /// 9c 00 
    /// 5f2a 0840 
    /// 9f02 000000002500 
    /// 9f03 000000000000 
    /// 9f09 008c 
    /// 9f10 06010a03a00000 
    /// 9f1a 0840 
    /// 9f1e 3830343835373234 
    /// 9f26 9181fcbe16abaa30 
    /// 9f27 80 
    /// 9f33 e0f8c8 
    /// 9f34 1e0300 
    /// 9f35 22 
    /// 9f36 0002 
    /// 9f37 ec1f5997 
    /// 9f41 00000323 
    /// 
    /// 
    /// </summary>
    [XmlElement(ElementName = "chipData")]
    public string ChipData { get; set; } = null!;

    /// <summary>
    /// Signature Capture data
    /// </summary>
    [XmlElement(ElementName = "sigData")]
    public string SignatureCaptureData { get; set; } = null!;

    /// <summary>
    /// Specifies the reason for Fallback as determined by the reader
    ///
    /// ‘T’ = Technical 
    /// ‘B’ = Brand
    /// 
    /// </summary>
    [XmlElement(ElementName = "fallbackReason")]
    public string FallbackReason { get; set; } = null!;

}