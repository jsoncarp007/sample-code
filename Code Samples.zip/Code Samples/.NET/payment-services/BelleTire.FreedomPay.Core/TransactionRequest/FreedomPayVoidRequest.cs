﻿using BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

namespace BelleTire.FreedomPay.Core.TransactionRequest;

public class FreedomPayVoidRequest : FreedomPayReferencedTransactionRequest
{
    /// <summary>
    /// For Serialization Only
    /// </summary>
    public FreedomPayVoidRequest() {}

    /// <summary>
    /// FreedomPay Freeway - Request to void a previous transaction 
    /// </summary>
    /// <param name="transactionSourceData">Transaction Source Data (store id, terminal/workstation id, user id)</param>
    /// <param name="transactionId">The unique identifier for the previous transaction (generated internally and returned in the request result)</param>
    /// <param name="orderReferenceNumber">The reference number for the transaction (Belle order/Invoice number)</param>
    public FreedomPayVoidRequest(TransactionSourceData transactionSourceData, string transactionId, string orderReferenceNumber) : base(transactionSourceData, transactionId, orderReferenceNumber)
    {
        Void = new TransactionRequestVoid() { Run = "true" };
    }
}