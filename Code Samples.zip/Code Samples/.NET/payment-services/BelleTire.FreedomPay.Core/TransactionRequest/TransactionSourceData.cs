namespace BelleTire.FreedomPay.Core.TransactionRequest;

public class TransactionSourceData
{
    /// <summary>
    /// Store number or "WEB"
    /// </summary>
    public string StoreId { get; set; }
    
    /// <summary>
    /// Request source machine/workstation id
    /// </summary>
    public string TerminalId { get; set; }
    
    /// <summary>
    /// User identifier or "WEB"
    /// </summary>
    public string EmployeeId { get; set; }

    public TransactionSourceData(string storeId, string terminalId, string employeeId)
    {
        StoreId = storeId;
        TerminalId = terminalId;
        EmployeeId = employeeId;
    }
}