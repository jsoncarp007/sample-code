﻿using BelleTire.FreedomPay.Core.TransactionRequest.TransactionRequestDtoComponents;

namespace BelleTire.FreedomPay.Core.TransactionRequest;

[Serializable]
public class FreedomPayCreditTransactionRequest : FreedomPayTransactionRequest 
{
    public FreedomPayCreditTransactionRequest() {}

    /// <summary>
    /// FreedomPay Freeway - Credit Card Transaction/Sale Request
    /// </summary>
    /// <param name="transactionSourceData">Transaction Source Data (store id, terminal/workstation id, user id)</param>
    /// <param name="orderReferenceNumber">Order number</param>
    /// <param name="transactionAmount"></param>
    /// <param name="cardNumber"></param>
    /// <param name="expirationMonth"></param>
    /// <param name="expirationYear"></param>
    /// <param name="cvv"></param>
    /// <param name="promotionCode"></param>
    /// <param name="createToken"></param>
    public FreedomPayCreditTransactionRequest(TransactionSourceData transactionSourceData, string orderReferenceNumber, decimal transactionAmount, string cardNumber, int expirationMonth, int expirationYear, string? zipCode, string? cvv = null, string? promotionCode = null, bool createToken = true) 
        : base(transactionSourceData, orderReferenceNumber, transactionAmount, cardNumber, FreedomPayAccountNumberType.Card, expirationMonth, expirationYear, cvv, zipCode, promotionCode)
    {
        Card.CardType = "credit";
        CaptureService = new TransactionRequestCaptureService() {Run = "true"};

        if (createToken)
            TokenCreateService = new TransactionRequestTokenCreateService() { Run = "true", TokenType = "7" };
    }

    public FreedomPayCreditTransactionRequest(TransactionSourceData transactionSourceData, string orderReferenceNumber, decimal transactionAmount, string accountToken, string? promotionCode = null) 
        : base(transactionSourceData, orderReferenceNumber, transactionAmount, accountToken, FreedomPayAccountNumberType.Token, null, null, null, null, promotionCode)
    {
    }
}