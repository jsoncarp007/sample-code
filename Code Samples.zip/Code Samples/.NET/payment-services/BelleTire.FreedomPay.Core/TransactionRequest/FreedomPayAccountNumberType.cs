﻿namespace BelleTire.FreedomPay.Core.TransactionRequest;

public enum FreedomPayAccountNumberType
{
    Card,
    Token
}