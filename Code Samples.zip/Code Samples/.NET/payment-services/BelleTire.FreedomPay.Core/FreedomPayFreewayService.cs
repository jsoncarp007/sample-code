﻿using System.Text;
using BelleTire.FreedomPay.Core.Serialization;
using BelleTire.FreedomPay.Core.TransactionRequest;
using BelleTire.FreedomPay.Core.TransactionResponse;

namespace BelleTire.FreedomPay.Core;

public class FreedomPayFreewayService
{
    private readonly HttpClient _client;
    private readonly FreedomPaySoapResponseDeserializer _soapResponseDeserializer;
    private readonly FreedomPaySoapRequestFactory _requestFactory;

    public FreedomPayFreewayService(HttpClient client)
    {
        _client = client;
        _requestFactory = new FreedomPaySoapRequestFactory();
        _soapResponseDeserializer = new FreedomPaySoapResponseDeserializer();
    }

    public async Task<FreedomPayTransactionResponse> SendTransactionRequest(FreedomPayApiRequest apiRequest)
    {
        var xmlAsString = _requestFactory.GetFreewayTransactionRequestXmlString(apiRequest);
        using var content = new StringContent(xmlAsString, Encoding.UTF8, "text/xml");
        using var request = new HttpRequestMessage(HttpMethod.Post, "Freeway/Service.asmx");
        request.Headers.Add("SOAPAction", "http://freeway.freedompay.com/Submit");
        request.Content = content;
        using var response = await _client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead);
        response.EnsureSuccessStatusCode();
        var responseContent = await response.Content.ReadAsStringAsync();
        
        await File.WriteAllTextAsync($"FreewayTransactionRequestXml_{DateTime.Now.Ticks}.xml", xmlAsString);
        await File.WriteAllTextAsync($"FreewayTransactionResponseXml_{DateTime.Now.Ticks}.xml", responseContent);
        
        return _soapResponseDeserializer.GetFreewayResponseFromXmlString(responseContent);
    }

}