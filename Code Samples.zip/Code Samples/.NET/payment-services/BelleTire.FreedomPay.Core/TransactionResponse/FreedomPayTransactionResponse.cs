﻿using System.Xml.Serialization;
using BelleTire.FreedomPay.Core.TransactionResponse.TransactionResponseDtoComponents;

namespace BelleTire.FreedomPay.Core.TransactionResponse;

[XmlRoot(ElementName="SubmitResult", Namespace="http://freeway.freedompay.com/")]
public class FreedomPayTransactionResponse
{
	[XmlElement(ElementName="promoReply", Namespace="http://freeway.freedompay.com/")] 
	public FreedomPayResponsePromoReply PromoReply { get; set; } = null!;

	[XmlElement(ElementName="ccAuthReply", Namespace="http://freeway.freedompay.com/")] 
	public FreedomPayResponseAuthorizationReply AuthorizationReply { get; set; } = null!;

	[XmlElement(ElementName="ccCaptureReply", Namespace="http://freeway.freedompay.com/")] 
	public FreedomPayTransactionResponseCaptureReply CaptureReply { get; set; } = null!;
	
	[XmlElement(ElementName="tokenInformation", Namespace="http://freeway.freedompay.com/")] 
	public FreedomPayResponseTokenInformation TokenInformation { get; set; } = null!;

	[XmlElement(ElementName="requestID", Namespace="http://freeway.freedompay.com/")] 
	public string RequestID { get; set; } = null!;

	[XmlElement(ElementName="reasonCode", Namespace="http://freeway.freedompay.com/")] 
	public int ReasonCode { get; set; } 

	[XmlElement(ElementName="decision", Namespace="http://freeway.freedompay.com/")] 
	public string Decision { get; set; } = null!;

	[XmlElement(ElementName="merchantReferenceCode", Namespace="http://freeway.freedompay.com/")] 
	public string MerchantReferenceCode { get; set; } = null!;
	
	[XmlElement(ElementName="invalidFields", Namespace="http://freeway.freedompay.com/")] 
	public FreedomPayTransactionResponseInvalidFields InvalidFields { get; set; } = null!;
	
	[XmlElement(ElementName="tokenCreateReply", Namespace="http://freeway.freedompay.com/")]
	public FreedomPayResponseTokenCreationReply ResponseTokenCreationReply { get; set; } = null!;
	
}