﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionResponse.TransactionResponseDtoComponents;

[XmlRoot(ElementName="promo")]
public class FreedomPayResponsePromotion 
{
    [XmlAttribute(AttributeName="desc")] 
    public string Description { get; set; } = null!;

    [XmlAttribute(AttributeName="code")] 
    public string Code { get; set; } = null!;

    [XmlAttribute(AttributeName="hints")] 
    public int Hints { get; set; } 

    [XmlAttribute(AttributeName="moreInfo")] 
    public string MoreInfo { get; set; } = null!;

    [XmlAttribute(AttributeName="threshold")] 
    public decimal Threshold { get; set; } 
    
    [XmlAttribute(AttributeName = "apr")]
    public decimal InterestRate { get; set; }
    
    [XmlAttribute(AttributeName = "disclaim")]
    public string Disclaimer { get; set; }
}
