using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionResponse.TransactionResponseDtoComponents;

[XmlRoot(ElementName="tokenInformation", Namespace="http://freeway.freedompay.com/")]
public class FreedomPayResponseTokenInformation 
{
    [XmlElement(ElementName="token", Namespace="http://freeway.freedompay.com/")] 
    public string Token { get; set; } = null!;
    
    [XmlElement(ElementName="accountNumberMasked", Namespace="http://freeway.freedompay.com/")] 
    public string AccountNumberMasked { get; set; } = null!;

    [XmlElement(ElementName="cardExpirationYear", Namespace="http://freeway.freedompay.com/")] 
    public int CardExpirationYear { get; set; } 

    [XmlElement(ElementName="cardType", Namespace="http://freeway.freedompay.com/")] 
    public string CardType { get; set; } = null!;

    [XmlElement(ElementName="cardExpirationMonth", Namespace="http://freeway.freedompay.com/")] 
    public int CardExpirationMonth { get; set; } 

    [XmlElement(ElementName="brand", Namespace="http://freeway.freedompay.com/")] 
    public string Brand { get; set; } = null!;
}