﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionResponse.TransactionResponseDtoComponents;

[XmlRoot(ElementName="invalidFields")]
public class FreedomPayTransactionResponseInvalidFields { 

    [XmlElement(ElementName="invalidField")] 
    public List<string> InvalidField { get; set; } = null!;
}