﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionResponse.TransactionResponseDtoComponents;

[XmlRoot(ElementName="promoReply", Namespace="http://freeway.freedompay.com/")]
public class FreedomPayResponsePromoReply 
{
    [XmlElement(ElementName="mixedPromosAllowed", Namespace="http://freeway.freedompay.com/")] 
    public string MixedPromosAllowed { get; set; } = null!;

    [XmlElement(ElementName="reasonCode", Namespace="http://freeway.freedompay.com/")] 
    public int ReasonCode { get; set; } 
    
    [XmlElement(ElementName="promos", Namespace="http://freeway.freedompay.com/")]
    public FreedomPayResponsePromotions Promotions { get; set; } = null!;

    [XmlElement(ElementName="requestDateTime", Namespace="http://freeway.freedompay.com/")] 
    public DateTime RequestDateTime { get; set; } 

    [XmlElement(ElementName="validationCode", Namespace="http://freeway.freedompay.com/")] 
    public string ValidationCode { get; set; } = null!;
}