﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionResponse.TransactionResponseDtoComponents;

[XmlRoot(ElementName="tokenCreateReply")]
public class FreedomPayResponseTokenCreationReply
{
    [XmlElement("reasonCode")]
    public int ReasonCode { get; set; }
    
    [XmlElement("requestDateTime")]
    public string RequestDateTime { get; set; } = null!;
    
    [XmlElement("responseMessage")]
    public string ResponseMessage { get; set; } = null!;
}