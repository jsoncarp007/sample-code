﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionResponse.TransactionResponseDtoComponents;

[XmlRoot(ElementName="ccCaptureReply", Namespace="http://freeway.freedompay.com/")]
public class FreedomPayTransactionResponseCaptureReply { 

    [XmlElement(ElementName="partialAmount", Namespace="http://freeway.freedompay.com/")] 
    public string PartialAmount { get; set; } = null!;

    [XmlElement(ElementName="amount", Namespace="http://freeway.freedompay.com/")] 
    public double Amount { get; set; } 

    [XmlElement(ElementName="processorResponseCode", Namespace="http://freeway.freedompay.com/")] 
    public int ProcessorResponseCode { get; set; } 

    [XmlElement(ElementName="reasonCode", Namespace="http://freeway.freedompay.com/")] 
    public int ReasonCode { get; set; } 

    [XmlElement(ElementName="processorResponseMessage", Namespace="http://freeway.freedompay.com/")] 
    public string ProcessorResponseMessage { get; set; } = null!;

    [XmlElement(ElementName="requestDateTime", Namespace="http://freeway.freedompay.com/")] 
    public DateTime RequestDateTime { get; set; } 

    [XmlElement(ElementName="processorTransactionID", Namespace="http://freeway.freedompay.com/")] 
    public int ProcessorTransactionId { get; set; } 

    [XmlElement(ElementName="reconciliationID", Namespace="http://freeway.freedompay.com/")] 
    public int ReconciliationId { get; set; } 

    [XmlElement(ElementName="purchasingLevel3Enabled", Namespace="http://freeway.freedompay.com/")] 
    public string PurchasingLevel3Enabled { get; set; } = null!;

    [XmlElement(ElementName="enhancedDataEnabled", Namespace="http://freeway.freedompay.com/")] 
    public string EnhancedDataEnabled { get; set; } = null!;
}