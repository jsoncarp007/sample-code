﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionResponse.TransactionResponseDtoComponents;

[XmlRoot(ElementName="ccAuthReply", Namespace="http://freeway.freedompay.com/")]
public class FreedomPayResponseAuthorizationReply
{
    [XmlElement(ElementName="processorResponseMessage", Namespace="http://freeway.freedompay.com/")] 
    public string ProcessorResponseMessage { get; set; } = null!;

    [XmlElement(ElementName="authorizationCode", Namespace="http://freeway.freedompay.com/")] 
    public int AuthorizationCode { get; set; } 

    [XmlElement(ElementName="requestDateTime", Namespace="http://freeway.freedompay.com/")] 
    public DateTime RequestDateTime { get; set; } 

    [XmlElement(ElementName="reconciliationID", Namespace="http://freeway.freedompay.com/")] 
    public int ReconciliationId { get; set; }

    [XmlElement(ElementName="enhancedDataEnabled", Namespace="http://freeway.freedompay.com/")] 
    public string EnhancedDataEnabled { get; set; } = null!;

    [XmlElement(ElementName="authorizedDateTime", Namespace="http://freeway.freedompay.com/")] 
    public DateTime AuthorizedDateTime { get; set; } 

    [XmlElement(ElementName="reasonCode", Namespace="http://freeway.freedompay.com/")] 
    public int ReasonCode { get; set; } 

    [XmlElement(ElementName="amount", Namespace="http://freeway.freedompay.com/")] 
    public double Amount { get; set; } 

    [XmlElement(ElementName="processorResponseCode", Namespace="http://freeway.freedompay.com/")] 
    public int ProcessorResponseCode { get; set; } 

    [XmlElement(ElementName="partialAmount", Namespace="http://freeway.freedompay.com/")] 
    public string PartialAmount { get; set; } = null!;

    [XmlElement(ElementName="processorTransactionID", Namespace="http://freeway.freedompay.com/")] 
    public int ProcessorTransactionId { get; set; } 
    
    [XmlElement(ElementName="avsCodeRaw")] 
    public string AvsCodeRaw { get; set; } = null!;

    [XmlElement(ElementName="cvCode")] 
    public string CvCode { get; set; } = null!;

    [XmlElement(ElementName="accountAPR")] 
    public decimal AccountApr { get; set; }

    [XmlElement(ElementName="cvCodeRaw")] 
    public string CvCodeRaw { get; set; } = null!;

    [XmlElement(ElementName="accountAPRType")] 
    public string AccountAprType { get; set; } = null!;

    [XmlElement(ElementName="avsCode")] 
    public string AvsCode { get; set; } = null!;
}