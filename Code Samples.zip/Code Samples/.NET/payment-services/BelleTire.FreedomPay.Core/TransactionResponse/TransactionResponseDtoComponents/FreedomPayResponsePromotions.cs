using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionResponse.TransactionResponseDtoComponents;

[XmlRoot(ElementName="promos")]
public class FreedomPayResponsePromotions 
{
    [XmlElement(ElementName="promo")] 
    public List<FreedomPayResponsePromotion> Promo { get; set; } = null!;
}