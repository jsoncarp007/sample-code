namespace BelleTire.FreedomPay.Core.TransactionResponse.ReasonCode;

public class FreedomPayReasonCode
{
    public int ReasonCode { get; }
    public FreedomPayReasonCodeType Type { get; }
    public string Description { get; }

    public FreedomPayReasonCode(int reasonCode, string description, FreedomPayReasonCodeType type)
    {
        ReasonCode = reasonCode;
        Type = type;
        Description = description;
    }
}