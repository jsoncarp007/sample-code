namespace BelleTire.FreedomPay.Core.TransactionResponse.ReasonCode;

public enum FreedomPayReasonCodeType
{
    Success,
    CommunicationFailure, 
    RequestStructureInvalid,
    RequestDataInvalid,
    CardReaderError,
    FatalError,
    InvalidLocation,
    
    // authorization 
    ManualAuthorizationRequired,
    AuthorizationExpired,
    AuthorizationError,
    DuplicateAuthorization,
    
    // card / transaction issues
    InsufficientFunds,
    DuplicateTransaction,
    CardDeclined,
    LostOrStolenCard,
    StolenCard,
    SuspectedFraud,
    InvalidPin,
    InvalidCvv,
    
    // voids
    VoidFailure,
    VoidDuplicate,
    VoidFailedNoActionRequired,
    
    // promo
    PromotionInvalid,
    NotEligibleForPromotion,
    
    // token
    TokenError,
    
    // digital currency conversion
    DccAvailable,
    DccUnavailable,
}