﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionResponse.Soap;

[XmlRoot(ElementName="Envelope", Namespace="http://schemas.xmlsoap.org/soap/envelope/")]
public class FreedomPayResponseSoapEnvelope { 

    [XmlElement(ElementName="Body", Namespace="http://schemas.xmlsoap.org/soap/envelope/")] 
    public FreedomPayResponseSoapBody Body { get; set; } = null!;

    [XmlAttribute(AttributeName="soap", Namespace="http://www.w3.org/2000/xmlns/")] 
    public string Soap { get; set; } = null!;

    [XmlAttribute(AttributeName="xsi", Namespace="http://www.w3.org/2000/xmlns/")] 
    public string Xsi { get; set; } = null!;

    [XmlAttribute(AttributeName="xsd", Namespace="http://www.w3.org/2000/xmlns/")] 
    public string Xsd { get; set; } = null!;

    [XmlText] 
    public string Text { get; set; } = null!;
}