﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionResponse.Soap;

[XmlRoot(ElementName="SubmitResponse", Namespace="http://freeway.freedompay.com/")]
public class FreedomPayResponseSoapSubmit { 

    [XmlElement(ElementName="SubmitResult", Namespace="http://freeway.freedompay.com/")] 
    public FreedomPayTransactionResponse FreedomPayTransactionResponse { get; set; } = null!;

    [XmlAttribute(AttributeName="xmlns", Namespace="")] 
    public string Xmlns { get; set; } = null!;

    [XmlText] 
    public string Text { get; set; } = null!;
}