﻿using System.Xml.Serialization;

namespace BelleTire.FreedomPay.Core.TransactionResponse.Soap;

[XmlRoot(ElementName="Body", Namespace="http://schemas.xmlsoap.org/soap/envelope/")]
public class FreedomPayResponseSoapBody { 

    [XmlElement(ElementName="SubmitResponse", Namespace="http://freeway.freedompay.com/")] 
    public FreedomPayResponseSoapSubmit SubmitResponse { get; set; } = null!;
}