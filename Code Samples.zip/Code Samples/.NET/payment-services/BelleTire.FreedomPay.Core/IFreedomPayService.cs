﻿using BelleTire.FreedomPay.Core.TransactionRequest;
using BelleTire.FreedomPay.Core.TransactionResult;

namespace BelleTire.FreedomPay.Core;

public interface IFreedomPayService
{
    Task<FreedomPayTransactionResult> SubmitTransaction(FreedomPayApiRequest apiRequest);
}