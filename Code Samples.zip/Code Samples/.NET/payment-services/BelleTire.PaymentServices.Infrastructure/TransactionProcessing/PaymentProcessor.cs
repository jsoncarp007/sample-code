namespace BelleTire.PaymentServices.Infrastructure.TransactionProcessing;

public enum PaymentProcessor
{
    WorldPay,
    FreedomPay
}