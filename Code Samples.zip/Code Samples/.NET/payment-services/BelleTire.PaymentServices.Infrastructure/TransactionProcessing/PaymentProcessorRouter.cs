using BelleTire.PaymentServices.Core.Requests;

namespace BelleTire.PaymentServices.Infrastructure.TransactionProcessing;

public class PaymentProcessorRouter
{
    private static readonly string[] FreedomPayCardPrefixes = {"6035"};

    public PaymentProcessor GetPaymentProcessorForAccount(AccountData accountData) => FreedomPayCardPrefixes
        .Any(freedomPayCardPrefix => accountData.AccountNumber.StartsWith(freedomPayCardPrefix))
        ? PaymentProcessor.FreedomPay
        : PaymentProcessor.WorldPay;

}