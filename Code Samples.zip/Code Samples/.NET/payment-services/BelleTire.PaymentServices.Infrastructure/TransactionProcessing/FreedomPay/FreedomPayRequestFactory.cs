using BelleTire.FreedomPay.Core.TransactionRequest;
using BelleTire.PaymentServices.Core.Requests;

namespace BelleTire.PaymentServices.Infrastructure.TransactionProcessing.FreedomPay;

public class FreedomPayRequestFactory
{
    public FreedomPayPromotionLookupRequest GetPromotionLookupRequest(PromotionOptionsLookupRequest promotionOptionsLookupRequest) 
    {
        var transactionSource = GetTransactionSourceData(promotionOptionsLookupRequest.TransactionSource);
        var accountData = promotionOptionsLookupRequest.AccountData;

        return new FreedomPayPromotionLookupRequest(transactionSource, promotionOptionsLookupRequest.PurchaseAmount,
            accountData.AccountNumber, FreedomPayAccountNumberType.Card, accountData.ExpirationMonth,
            accountData.ExpirationYear, accountData.Cvv);
    }
    
    public FreedomPayAuthorizationRequest GetAuthorizationRequest(AuthorizationTransaction authorizationTransaction) 
    {
        var transactionSource = GetTransactionSourceData(authorizationTransaction.TransactionSource);
        var accountData = authorizationTransaction.CreditCardAccountData;
        
        var request = new FreedomPayAuthorizationRequest(transactionSource, authorizationTransaction.TransactionAmount,
            accountData.AccountNumber, FreedomPayAccountNumberType.Card, accountData.ExpirationMonth,
            accountData.ExpirationYear, accountData.Cvv, authorizationTransaction.PromotionId, authorizationTransaction.CustomerData?.Zip);
        
        if (authorizationTransaction.CustomerData != null)
            request.SetAccountData(authorizationTransaction.CustomerData?.FirstName, authorizationTransaction.CustomerData?.LastName, authorizationTransaction.CustomerData?.Address1, authorizationTransaction.CustomerData?.Address2, authorizationTransaction.CustomerData?.City, authorizationTransaction.CustomerData?.State, authorizationTransaction.CustomerData?.Zip);

        return request;
    }
    
    public FreedomPayCreditTransactionRequest GetCreditTransactionRequest(SaleTransaction saleTransaction, string promotionId)
    {
        var transactionSource = GetTransactionSourceData(saleTransaction.TransactionSource);
        var accountData = saleTransaction.CreditCardAccountData;

        var request = new FreedomPayCreditTransactionRequest(transactionSource, saleTransaction.OrderNumber,
            saleTransaction.TransactionAmount, accountData.AccountNumber, accountData.ExpirationMonth,
            accountData.ExpirationYear, saleTransaction.CustomerData?.Zip, accountData.Cvv, promotionId);
        
        if (saleTransaction.CustomerData != null)
            request.SetAccountData(saleTransaction.CustomerData?.FirstName, saleTransaction.CustomerData?.LastName, saleTransaction.CustomerData?.Address1, saleTransaction.CustomerData?.Address2, saleTransaction.CustomerData?.City, saleTransaction.CustomerData?.State, saleTransaction.CustomerData?.Zip);

        return request;
    }
    
    public FreedomPayCreditTransactionRequest GetCreditTransactionRequest(PromotionSaleTransaction promotionSaleTransaction)
    {
        return GetCreditTransactionRequest(promotionSaleTransaction, promotionSaleTransaction.PromotionId);
    }

    public FreedomPayVoidRequest GetVoidTransactionRequest(VoidTransaction voidTransaction)
    {
        var transactionSource = GetTransactionSourceData(voidTransaction.TransactionSource);
        return new FreedomPayVoidRequest(transactionSource, voidTransaction.ReferenceId, voidTransaction.OrderNumber);
    }
    
    public FreedomPayRefundRequest GetRefundTransactionRequest(RefundTransaction refundTransaction)
    {
        var transactionSource = GetTransactionSourceData(refundTransaction.TransactionSource);
        return new FreedomPayRefundRequest(transactionSource, refundTransaction.ReferenceId, refundTransaction.OrderNumber, refundTransaction.TransactionAmount);
    }

    public FreedomPayAccountLookupRequest GetAccountLookupRequest(
        AccountLookupByAccountNumberRequest accountLookupByAccountNumberRequest)
    {
        var transactionSource = GetTransactionSourceData(accountLookupByAccountNumberRequest.TransactionSource);
        
        var request = new FreedomPayAccountLookupRequest(transactionSource,
            accountLookupByAccountNumberRequest.AccountData.AccountNumber, accountLookupByAccountNumberRequest.AccountData.Cvv, accountLookupByAccountNumberRequest.AccountData.ExpirationMonth, accountLookupByAccountNumberRequest.AccountData.ExpirationYear);
        
        if (accountLookupByAccountNumberRequest.CustomerData != null)
            request.SetAccountData(accountLookupByAccountNumberRequest.CustomerData?.FirstName, accountLookupByAccountNumberRequest.CustomerData?.LastName, accountLookupByAccountNumberRequest.CustomerData?.Address1, accountLookupByAccountNumberRequest.CustomerData?.Address2, accountLookupByAccountNumberRequest.CustomerData?.City, accountLookupByAccountNumberRequest.CustomerData?.State, accountLookupByAccountNumberRequest.CustomerData?.Zip);

        return request;
    }
    
    private TransactionSourceData GetTransactionSourceData(TransactionSource? transactionSource)
    {
        return transactionSource != null
            ? new TransactionSourceData(transactionSource.StoreId, transactionSource.TerminalId,
                transactionSource.UserId)
            : new TransactionSourceData("NOT_SET", "NOT_SET", "NOT_SET");
    }
}