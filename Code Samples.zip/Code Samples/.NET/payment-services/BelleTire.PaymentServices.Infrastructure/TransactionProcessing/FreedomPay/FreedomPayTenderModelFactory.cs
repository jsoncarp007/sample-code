﻿using BelleTire.FreedomPay.Core.TransactionRequest;
using BelleTire.FreedomPay.Core.TransactionResult;
using BelleTire.PaymentServices.Core.DataModels;

namespace BelleTire.PaymentServices.Infrastructure.TransactionProcessing.FreedomPay;

public class FreedomPayTenderModelFactory
{
    public FreedomPayTender GetTenderModelForRequest(FreedomPayCreditTransactionRequest request)
    {
        return new FreedomPayTender()
        {
            Action = "000",
            ProcessingCode = "003900",
            PosEntryMode = "291101694140",
            CreditCardType = "GY",
            AprType = string.Empty,
            Amount1 = Convert.ToDecimal(request.PurchaseTotals.ChargeAmount),
            Amount2 = 0,
            TransactionType = "SALE_UNSIGNED",
            CreditPlan = request.Items.FirstOrDefault()?.PromoCode,
            Created = DateTime.Now,
            VoidReverse = "N",
            CardNumber = $"************" + request.Card.AccountNumber.Substring(request.Card.AccountNumber.Length-4, 4),
            Reference = request.ReferenceCode,
            CreditCardMerchantId = 419,
            DrawerControl = 0,
            OrderNumber = request.InvoiceHeader?.InvoiceNumber != null ? Convert.ToInt32(request.InvoiceHeader?.InvoiceNumber) : 0,
            BatchNumber = 0,
            ItemNum = 0,
            SysTraceAuditNumber = 0
        };
    }
    
    public FreedomPayTender GetTenderModelForRequest(FreedomPayVoidRequest request)
    {
        return new FreedomPayTender()
        {
            Action = "000",
            ProcessingCode = "003900",
            PosEntryMode = "291101694140",
            CreditCardType = "GY",
            Amount1 = 0,
            Amount2 = 0,
            TransactionType = "VOID",
            CreditPlan = string.Empty,
            Created = DateTime.Now,
            VoidReverse = "N",
            CardNumber = string.Empty,
            Reference = request.ReferenceCode,
            CreditCardMerchantId = 419,
            DrawerControl = 0,
            OrderNumber = request.InvoiceHeader?.InvoiceNumber != null ? Convert.ToInt32(request.InvoiceHeader?.InvoiceNumber) : 0,
            BatchNumber = 0,
            ItemNum = 0,
            SysTraceAuditNumber = 0
        };
    }

    public void UpdateTenderModelFromSaleResult(FreedomPayTender tender, FreedomPayTransactionResult result)
    {
        tender.Reference = result.TransactionId;
        tender.Apr = result.PromotionApr;
        tender.AprType = result.AprType;
        tender.ApprovalCode = result.ApprovalCode;
        tender.TransactionType = result.TransactionStatus == FreedomPayTransactionStatus.Success ? "SALE_UNSIGNED" : "SALE_FAILED";
    }
    
    public void UpdateTenderModelFromVoidResult(FreedomPayTender tender, FreedomPayTransactionResult result)
    {
        tender.Reference = result.TransactionId;
        tender.ApprovalCode = result.ApprovalCode;
        tender.TransactionType = result.TransactionStatus == FreedomPayTransactionStatus.Success ? "VOID" : "VOID_FAILED";
    }
}