﻿using BelleTire.FreedomPay.Core;
using BelleTire.PaymentServices.Core.Requests;
using BelleTire.PaymentServices.Core.Responses;
using BelleTire.PaymentServices.Infrastructure.Repository.FreedomPay;

namespace BelleTire.PaymentServices.Infrastructure.TransactionProcessing.FreedomPay;

public class FreedomPayTransactionService : ITransactionService
{
    private readonly IFreedomPayTenderRepository _freedomPayTenderRepository;
    private readonly FreedomPayRequestFactory _freedomPayRequestFactory;
    private readonly FreedomPayResponseConverter _freedomPayResponseConverter;
    private readonly FreedomPayService _freedomPayService;
    private readonly FreedomPayTenderModelFactory _freedomPayTenderFactory;

    public FreedomPayTransactionService(HttpClient httpClient, IFreedomPayTenderRepository freedomPayTenderRepository)
    {
        _freedomPayTenderRepository = freedomPayTenderRepository;
        _freedomPayService = new FreedomPayService(httpClient);
        _freedomPayRequestFactory = new FreedomPayRequestFactory();
        _freedomPayResponseConverter = new FreedomPayResponseConverter();
        _freedomPayTenderFactory = new FreedomPayTenderModelFactory();
    }

    public async Task<TransactionResponse> ProcessAuthorizationTransactionAsync(AuthorizationTransaction transaction) =>
        await ProcessTransactionAsync(transaction);
    public async Task<TransactionResponse> ProcessTransactionAsync(AuthorizationTransaction transaction)
    {
        var freedomPayRequest = _freedomPayRequestFactory.GetAuthorizationRequest(transaction);
        var freedomPayResponse = await _freedomPayService.SubmitTransaction(freedomPayRequest).ConfigureAwait(false);
        return _freedomPayResponseConverter.TranslateTransactionResult(freedomPayResponse);
    }

    public async Task<TransactionResponse> ProcessSaleTransactionAsync(PromotionSaleTransaction transaction) =>
        await ProcessTransactionAsync(transaction);
    public async Task<TransactionResponse> ProcessTransactionAsync(PromotionSaleTransaction transaction)
    {
        var freedomPayRequest = _freedomPayRequestFactory.GetCreditTransactionRequest(transaction);
        
        // create a record indicating a request is being made
        var freedomPayTender = _freedomPayTenderFactory.GetTenderModelForRequest(freedomPayRequest);
        await _freedomPayTenderRepository.Insert(freedomPayTender);
        
        // submit the transaction
        var freedomPayResponse = await _freedomPayService.SubmitTransaction(freedomPayRequest).ConfigureAwait(false);
        
        // update the record with the response details
        _freedomPayTenderFactory.UpdateTenderModelFromSaleResult(freedomPayTender, freedomPayResponse);
        await _freedomPayTenderRepository.Update(freedomPayTender);

        return _freedomPayResponseConverter.TranslateTransactionResult(freedomPayResponse);
    }

    public async Task<TransactionResponse> ProcessVoidTransactionAsync(VoidTransaction transaction) 
        => await ProcessTransactionAsync(transaction);
    public async Task<TransactionResponse> ProcessTransactionAsync(VoidTransaction transaction)
    {
        var freedomPayRequest = _freedomPayRequestFactory.GetVoidTransactionRequest(transaction);
        
        // create a record indicating a request is being made
        var freedomPayTender = _freedomPayTenderFactory.GetTenderModelForRequest(freedomPayRequest);
        await _freedomPayTenderRepository.Insert(freedomPayTender);
        
        // submit the transaction
        var freedomPayResponse = await _freedomPayService.SubmitTransaction(freedomPayRequest).ConfigureAwait(false);
        
        // update the record with the response details
        _freedomPayTenderFactory.UpdateTenderModelFromVoidResult(freedomPayTender, freedomPayResponse);
        await _freedomPayTenderRepository.Update(freedomPayTender);
        
        return _freedomPayResponseConverter.TranslateTransactionResult(freedomPayResponse);
    }

    public async Task<TransactionResponse> ProcessRefundTransactionAsync(RefundTransaction transaction) =>
        await ProcessTransactionAsync(transaction); 
    public async Task<TransactionResponse> ProcessTransactionAsync(RefundTransaction transaction)
    {
        var freedomPayRequest = _freedomPayRequestFactory.GetRefundTransactionRequest(transaction);
        var freedomPayResponse = await _freedomPayService.SubmitTransaction(freedomPayRequest).ConfigureAwait(false);
        return _freedomPayResponseConverter.TranslateTransactionResult(freedomPayResponse);
    }

    public async Task<TransactionResponse> AccountLookupByAccountNumberAsync(AccountLookupByAccountNumberRequest accountLookupRequest) =>
        await ProcessTransactionAsync(accountLookupRequest);

    public async Task<TransactionResponse> ProcessTransactionAsync(AccountLookupByAccountNumberRequest accountLookupRequest)
    {
        var freedomPayRequest = _freedomPayRequestFactory.GetAccountLookupRequest(accountLookupRequest);
        var freedomPayResponse = await _freedomPayService.SubmitTransaction(freedomPayRequest).ConfigureAwait(false);
        return _freedomPayResponseConverter.TranslateTransactionResult(freedomPayResponse);
    }

    public async Task<TransactionFinalizeResponse> FinalizeTransaction(string referenceId, int orderNumber)
    {
        var tender = _freedomPayTenderRepository.GetByReferenceId(referenceId).FirstOrDefault();

        if (tender == null)
            return new TransactionFinalizeResponse()
                {Success = false, ResponseText = $"Could not find a record for reference Id: {referenceId}"};

        tender.OrderNumber = orderNumber;
        tender.TransactionType = "SALE";
        
        await _freedomPayTenderRepository.Update(tender);
        
        return new TransactionFinalizeResponse() {Success = true, OrderNumber = orderNumber};
    }

    public async Task<TransactionCancellationResponse> CancelTransaction(CancelSaleRequestDto cancelSaleRequestDto)
    {
        var transactionSource = cancelSaleRequestDto.TransactionSource;
        var transactionAmount = cancelSaleRequestDto.TransactionAmount;
        var referenceId = cancelSaleRequestDto.ReferenceId;
        var orderNumber = cancelSaleRequestDto.OrderNumber;
        
        var request = new VoidTransaction(transactionSource, referenceId, orderNumber, transactionAmount);
        var response = await ProcessVoidTransactionAsync(request);
        
        var tender = _freedomPayTenderRepository.GetByReferenceId(referenceId).FirstOrDefault();

        if (tender == null)
            return new TransactionCancellationResponse()
                {Success = false, TransactionAmount = transactionAmount, ReferenceId = referenceId, ResponseText = $"Could not find a record for reference Id: {referenceId}"};

        if (response.TransactionResult == TransactionResult.Success)
        {
            tender.VoidReverse = "V";
            tender.TransactionType = "SALE_VOIDED";
        }
        else
        {
            var refundTransaction = new RefundTransaction(cancelSaleRequestDto.TransactionSource,
                cancelSaleRequestDto.ReferenceId, cancelSaleRequestDto.OrderNumber, tender.Amount1 ?? 0, tender.Amount1 ?? 0);

            var refundResponse = await ProcessRefundTransactionAsync(refundTransaction);
            if (refundResponse.TransactionResult == TransactionResult.Success)
            {
                tender.VoidReverse = "R";
                tender.TransactionType = "SALE_REFUNDED";
            }
        }

        await _freedomPayTenderRepository.Update(tender);

        return new TransactionCancellationResponse() {Success = response.TransactionResult == TransactionResult.Success, TransactionAmount = transactionAmount, ReferenceId = referenceId };
    }
}