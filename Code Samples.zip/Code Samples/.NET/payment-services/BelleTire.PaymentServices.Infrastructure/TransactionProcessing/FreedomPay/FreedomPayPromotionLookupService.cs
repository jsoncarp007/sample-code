using BelleTire.FreedomPay.Core;
using BelleTire.PaymentServices.Core.Requests;
using BelleTire.PaymentServices.Core.Responses;

namespace BelleTire.PaymentServices.Infrastructure.TransactionProcessing.FreedomPay;

public class FreedomPayPromotionLookupService : IPromotionLookupService
{
    private readonly FreedomPayService _freedomPayService;
    private readonly FreedomPayRequestFactory _freedomPayRequestFactory;
    private readonly FreedomPayResponseConverter _freedomPayResponseConverter;
    
    public FreedomPayPromotionLookupService(HttpClient httpClient)
    {
        _freedomPayService = new FreedomPayService(httpClient);
        _freedomPayRequestFactory = new FreedomPayRequestFactory();
        _freedomPayResponseConverter = new FreedomPayResponseConverter();
    }

    public async Task<PromotionOptionsLookupResponse> GetPromotionOptionsAsync(PromotionOptionsLookupRequest promotionOptionsLookupRequest)
    {
        var freedomPayRequest = _freedomPayRequestFactory.GetPromotionLookupRequest(promotionOptionsLookupRequest);
        var freedomPayResponse = await _freedomPayService.SubmitTransaction(freedomPayRequest);
        var promotionOptions = _freedomPayResponseConverter.GetPromotionOptionsFromResult(freedomPayResponse);

        return promotionOptions;
    }
}