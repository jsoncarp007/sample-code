using BelleTire.FreedomPay.Core.TransactionResult;
using BelleTire.PaymentServices.Core.Responses;

namespace BelleTire.PaymentServices.Infrastructure.TransactionProcessing.FreedomPay;

public class FreedomPayResponseConverter
{
    public PromotionOptionsLookupResponse GetPromotionOptionsFromResult(FreedomPayTransactionResult freedomPayTransactionResult)
    {
        var promotionOptions = freedomPayTransactionResult.PromotionOptions?.Select(po =>
            new PromotionOption(po.PromotionCode, po.Description, po.Threshold, po.InterestRate, string.Empty));
        
        return new PromotionOptionsLookupResponse(freedomPayTransactionResult.TransactionStatus == FreedomPayTransactionStatus.Success, promotionOptions?.ToList(), freedomPayTransactionResult.StatusDetails);
    }
    
    public TransactionResponse TranslateTransactionResult(FreedomPayTransactionResult freedomPayTransactionResult)
    {
        var transactionResultCode = freedomPayTransactionResult.TransactionStatus switch
        {
            FreedomPayTransactionStatus.Success => TransactionResult.Success,
            FreedomPayTransactionStatus.NonCriticalError => TransactionResult.NonCriticalError,
            FreedomPayTransactionStatus.PossibleFraud => TransactionResult.PossibleFraud,
            FreedomPayTransactionStatus.TransactionDeclined => TransactionResult.TransactionDeclined,
            FreedomPayTransactionStatus.ValidationFailed => TransactionResult.ValidationFailed,
            FreedomPayTransactionStatus.RequestDataError => TransactionResult.RequestDataError,
            FreedomPayTransactionStatus.AuthorizationError => TransactionResult.AuthorizationError,
            FreedomPayTransactionStatus.DuplicateTransaction => TransactionResult.DuplicateTransaction,
            FreedomPayTransactionStatus.CardReaderDataError => TransactionResult.CardReaderDataError,
            FreedomPayTransactionStatus.FatalError => TransactionResult.FatalError,
            FreedomPayTransactionStatus.TemporaryError => TransactionResult.TemporaryError,
            FreedomPayTransactionStatus.PromotionSelectionMissing => TransactionResult.PromotionSelectionMissing,
            _ => throw new ArgumentOutOfRangeException()
        };

        var firstPromotion = freedomPayTransactionResult?.PromotionOptions?.FirstOrDefault();

        if (firstPromotion != null)
        {
            var formattedDisclaimer = FormatDisclosure(firstPromotion.Disclaimer, freedomPayTransactionResult?.PromotionApr ?? 0, freedomPayTransactionResult.TransactionAmount ?? 0);
            
            var promotion = new PromotionOption(firstPromotion.PromotionCode, firstPromotion.Description,
                firstPromotion.Threshold, freedomPayTransactionResult?.PromotionApr ?? 0, formattedDisclaimer);

            return new TransactionResponse(transactionResultCode,
                freedomPayTransactionResult.ReferenceId ?? string.Empty,
                freedomPayTransactionResult.TransactionId ?? string.Empty,
                freedomPayTransactionResult.TransactionAmount ?? 0,
                freedomPayTransactionResult.InvoiceNumber ?? string.Empty,
                freedomPayTransactionResult.StatusDetails,
                freedomPayTransactionResult.AccountToken,
                promotion);
        }
        
        return new TransactionResponse(transactionResultCode,
            freedomPayTransactionResult.ReferenceId ?? string.Empty,
            freedomPayTransactionResult.TransactionId ?? string.Empty,
            freedomPayTransactionResult.TransactionAmount ?? 0,
            freedomPayTransactionResult.InvoiceNumber ?? string.Empty,
            freedomPayTransactionResult.StatusDetails,
            freedomPayTransactionResult.AccountToken,
            null);
    }

    private string FormatDisclosure(string disclosureTemplate, decimal interestRate, decimal transactionAmount)
    {
        disclosureTemplate = disclosureTemplate?.Replace("{FINANCE_AMOUNT}", transactionAmount.ToString("C"));
        disclosureTemplate = disclosureTemplate?.Replace("{TRANSACTION_DATE}", DateTime.Today.ToString("d"));
        disclosureTemplate = disclosureTemplate?.Replace("{APR}", interestRate.ToString("N2"));
        disclosureTemplate = disclosureTemplate?.Replace("Â ", string.Empty);
        disclosureTemplate = disclosureTemplate?.Replace("\\n", Environment.NewLine);
        
        return disclosureTemplate;
    }
}