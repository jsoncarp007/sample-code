using BelleTire.PaymentServices.Core.Requests;
using BelleTire.PaymentServices.Core.Responses;

namespace BelleTire.PaymentServices.Infrastructure;

public interface IPromotionLookupService
{
    Task<PromotionOptionsLookupResponse> GetPromotionOptionsAsync(PromotionOptionsLookupRequest promotionOptionsLookupRequest);
}