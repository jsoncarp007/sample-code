﻿

using BelleTire.Verifone.Core;

namespace BelleTire.PaymentServices.Infrastructure.CardReader;

public class CardReader
{
    private VerifoneDeviceClient _device; 
    
    public CardReader(int deviceId, string merchantId, string terminalId, string deviceIp, string macLabel, string macKey)
    {
        _device = new VerifoneDeviceClient(deviceIp);
    }
}