﻿namespace BelleTire.PaymentServices.Infrastructure.Repository;

public interface ISqlQueryFactory
{
    IEnumerable<QueryFilterField> GetFilterFieldsForObjectType(Type objectType);
    string GetDatesInRangeAsStringList(DateTime startDate, DateTime endDate);
    string GetColumnListSql(Type objectType);
    string? GetFieldValue(object value);
}