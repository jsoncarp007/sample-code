﻿using BelleTire.PaymentServices.Core.DataModels;
using Microsoft.EntityFrameworkCore;

namespace BelleTire.PaymentServices.Infrastructure.Repository.CardDevices;

public class CreditCardDeviceRepository : ICreditCardDeviceRepository
{
    private readonly InformixDbContext _informixDbContext;

    public CreditCardDeviceRepository(InformixDbContext informixDbContext)
    {
        _informixDbContext = informixDbContext;
    }

    public IEnumerable<CreditCardDeviceData> GetAllActiveDevices()
    {
        var baseSql = GetDeviceBaseSqlQuery();
        baseSql += "WHERE b.status = 'U' OR b.status = 'D' ORDER BY b.unit_num";

        return _informixDbContext.CreditCardDevices!.FromSqlRaw(baseSql);
    }

    public string GetDeviceBaseSqlQuery()
    {
        return @"SELECT b.device_id as DeviceId,
                      b.status AS Status,
                      'Store ' || NVL(b.unit_num, -1) || ' ' || b.location_descr || ', ' || TRIM(NVL(b.ip_address, '')) AS Description, 
                     TRIM(b.brand) AS DeviceBrand, 
                      TRIM(b.model) AS DeviceModel,
                      TRIM(b.serial_num) AS SerialNumber,
                      TRIM(b.device_cd) AS device_cd_device,
                      TRIM(NVL(b.ip_address, '')) AS IpAddress,
                      NVL(b.ip_port, -1) AS Port, 
                      TRIM(b.device_class) AS device_class,
                      b.uses_ssl,
                      NVL(b.unit_num, -1) AS StoreNumber,
                      TRIM(NVL(b.location_descr, '')) AS Location,
                      TRIM(NVL(b.cc_processor_key, '')) AS CreditCardProcessorKey,
                      TRIM(NVL(b.mac_label, '')) AS MacLabel,
                      TRIM(NVL(b.mac_key, '')) AS MacKey
               FROM 
                    device b ";

    }
}