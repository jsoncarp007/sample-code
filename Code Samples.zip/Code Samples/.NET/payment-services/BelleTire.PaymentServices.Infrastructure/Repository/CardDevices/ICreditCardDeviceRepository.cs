using BelleTire.PaymentServices.Core.DataModels;

namespace BelleTire.PaymentServices.Infrastructure.Repository.CardDevices;

public interface ICreditCardDeviceRepository
{
    IEnumerable<CreditCardDeviceData> GetAllActiveDevices();
    string GetDeviceBaseSqlQuery();
}