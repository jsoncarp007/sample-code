﻿using Microsoft.EntityFrameworkCore;

namespace BelleTire.PaymentServices.Infrastructure.Repository.PosTender;

public class PosTenderRepository : IPosTenderRepository
{
    private readonly InformixDbContext _informixDbContext;
    private readonly ISqlQueryFactory _queryFactory;

    public PosTenderRepository(InformixDbContext informixDbContext, ISqlQueryFactory queryFactory)
    {
        _informixDbContext = informixDbContext;
        _queryFactory = queryFactory;
    }

    public IEnumerable<Core.DataModels.PosTender> GetByFieldValue(string fieldName, object fieldValue)
    {
        if (string.IsNullOrEmpty(fieldName)) 
            return Enumerable.Empty<Core.DataModels.PosTender>();
        
        var fieldConditionSql = fieldValue is string ? $"LIKE '{fieldValue}'" : $"= {fieldValue}";
        
        return _informixDbContext
            .PosTenders
            .FromSqlRaw<Core.DataModels.PosTender>(
                $@"SELECT {_queryFactory.GetColumnListSql(typeof(Core.DataModels.PosTender))} 
                    FROM pos_tender 
                    WHERE {fieldName} {fieldConditionSql}")
            .AsEnumerable();
    }

    public IEnumerable<Core.DataModels.PosTender> GetByDateRange(DateTime startDate, DateTime? endDate)
    {
        var endDateToUse = endDate ?? DateTime.Now;

        var records = _informixDbContext
            .PosTenders!
            .FromSqlRaw<Core.DataModels.PosTender>(
                $@"SELECT {_queryFactory.GetColumnListSql(typeof(Core.DataModels.PosTender))} 
                    FROM pos_tender 
                    WHERE tender_date in ({_queryFactory.GetDatesInRangeAsStringList(startDate, endDateToUse)})")
            .AsEnumerable();

        return records;
    }
    
    public IEnumerable<QueryFilterField> GetQueryFilterFields() => 
        _queryFactory.GetFilterFieldsForObjectType(typeof(Core.DataModels.PosTender));
}