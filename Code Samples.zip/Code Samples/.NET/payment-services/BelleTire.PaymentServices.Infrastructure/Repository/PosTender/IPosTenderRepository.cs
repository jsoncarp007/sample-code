﻿namespace BelleTire.PaymentServices.Infrastructure.Repository.PosTender;

public interface IPosTenderRepository
{
    IEnumerable<QueryFilterField> GetQueryFilterFields();
    IEnumerable<Core.DataModels.PosTender> GetByDateRange(DateTime startDate, DateTime? endDate);
    IEnumerable<Core.DataModels.PosTender> GetByFieldValue(string fieldName, object fieldValue);
}