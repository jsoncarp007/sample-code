namespace BelleTire.PaymentServices.Infrastructure.Repository;

public class QueryFilterField
{
    public string? ColumnName { get; set; }
    public string? FriendlyName { get; set; }
    public Type? DataType { get; set; }
}