﻿using BelleTire.PaymentServices.Core.DataModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace BelleTire.PaymentServices.Infrastructure.Repository;

public class InformixDbContext : DbContext
{
    public virtual DbSet<Core.DataModels.PosTender>? PosTenders { get; set; }
    public virtual DbSet<FreedomPayTender>? FreedomPayTenders { get; set; }
    public virtual DbSet<CreditCardDeviceData>? CreditCardDevices { get; set; }
    
    public InformixDbContext(DbContextOptions options) : base(options)
    {
        Database.SetCommandTimeout(int.MaxValue);
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Core.DataModels.PosTender>()
            .HasKey(pr => (new {pr.OrderNumber, pr.OrderTenderId }));
        
        modelBuilder.Entity<FreedomPayTender>()
            .HasKey(pr => (new {pr.HpsTenderId }));

        modelBuilder.Entity<CreditCardDeviceData>().HasKey(ccd => (new {ccd.SerialNumber }));;

        AddStringTrimConverterToStringProperties(modelBuilder);
    }
    
    private void AddStringTrimConverterToStringProperties(ModelBuilder modelBuilder)
    {
        // Create instance of Trim converter
        var stringTrimConverter = new ValueConverter<string, string>(
            v => v.TrimEnd(), // trims when saving to db
            v => v.TrimEnd()); // trims when retrieving from the db

        // Get all the types in the Models which have a [Column] attribute on at least one of their properties
        // var types = Assembly.GetAssembly(typeof(PosHeader)).GetTypes()
        //     .Where(t => t.IsClass
        //                 && t.Namespace == $"{nameof(BelleTire)}.{nameof(Rebate)}.{nameof(Core)}.{nameof(Core.Models)}"
        //                 && t.GetProperties().SelectMany(p => p.GetCustomAttributes()).Any(a => a is ColumnAttribute))
        //     .ToList();
        var types = new[] { typeof(Core.DataModels.PosTender) }; 
            
        foreach (var type in types)
        {
            // Access each of the Models as an Entity
            var model = modelBuilder.Entity(type);

            //Retrieve only the string properties
            var stringProperties = type.GetProperties().Where(p => p.PropertyType.FullName == typeof(string).FullName).ToList();

            foreach (var prop in stringProperties)
            {
                // Apply the Trim converter to the property
                model.Property(prop.Name).HasConversion(stringTrimConverter);
            }
        }
    }
}