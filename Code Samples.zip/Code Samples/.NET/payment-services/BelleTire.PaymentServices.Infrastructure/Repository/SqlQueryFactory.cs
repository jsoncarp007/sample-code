﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace BelleTire.PaymentServices.Infrastructure.Repository;

public class SqlQueryFactory : ISqlQueryFactory
{
    public string GetDatesInRangeAsStringList(DateTime startDate, DateTime endDate)
    {
        if (endDate < startDate) return string.Empty;
        
        var dateStringList = new List<string>();
        var currentDate = startDate;
        while (currentDate <= endDate)
        {
            currentDate = currentDate.AddDays(1);
            dateStringList.Add($"'{currentDate:MM/dd/yyyy}'");
        }

        return string.Join(", ", dateStringList);
    }
    
    public string GetColumnListSql(Type objectType)
    {
        var columnNameList = new List<string>();
        foreach (var property in objectType.GetProperties())
        {
            var columnNameAttribute = property.GetCustomAttributes(true).OfType<ColumnAttribute>().FirstOrDefault();
            if (columnNameAttribute == null) continue;
            columnNameList.Add(property.PropertyType == typeof(decimal)
                ? $"CAST({columnNameAttribute.Name} as DECIMAL(9, 2)) as {columnNameAttribute.Name}"
                : $"{columnNameAttribute.Name}");
        }

        return string.Join(",", columnNameList);
    }

    public IEnumerable<QueryFilterField> GetFilterFieldsForObjectType(Type objectType) =>
        objectType
            .GetProperties()
            .Select(property => new QueryFilterField()
            {
                ColumnName = property.GetCustomAttributes(true).OfType<ColumnAttribute>().FirstOrDefault()?.Name ?? string.Empty, 
                DataType = property.PropertyType, 
                FriendlyName = property.GetCustomAttributes(true).OfType<DisplayNameAttribute>().FirstOrDefault()?.DisplayName ?? property.Name
            })
            .ToList();

    public string? GetFieldValue(object value) =>
        value switch
        {
            DateTime dateTime => $"TO_DATE('{dateTime:MM-dd-yyyy}','%m-%d-%Y')",
            string dateTimeString => $"'{dateTimeString}'",
            _ => value.ToString()
        };
}