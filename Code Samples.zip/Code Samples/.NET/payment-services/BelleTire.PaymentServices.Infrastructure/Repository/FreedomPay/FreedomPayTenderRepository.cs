﻿using BelleTire.PaymentServices.Core.DataModels;
using Microsoft.EntityFrameworkCore;

namespace BelleTire.PaymentServices.Infrastructure.Repository.FreedomPay;

public class FreedomPayTenderRepository : IFreedomPayTenderRepository
{
    private readonly InformixDbContext _informixDbContext;
    private readonly ISqlQueryFactory _queryFactory;

    public FreedomPayTenderRepository(InformixDbContext informixDbContext, ISqlQueryFactory queryFactory)
    {
        _informixDbContext = informixDbContext;
        _queryFactory = queryFactory;
    }
    
    public IEnumerable<FreedomPayTender> GetByReferenceId(string referenceId)
    {
       return _informixDbContext
            .FreedomPayTenders!
            .FromSqlRaw(
                $@"SELECT *  
                    FROM hps_tender 
                    WHERE reference = '{referenceId}'")
            .AsEnumerable();
    }
    
    public IEnumerable<FreedomPayTender> GetByFieldValue(string fieldName, object fieldValue)
    {
        if (string.IsNullOrEmpty(fieldName)) 
            return Enumerable.Empty<FreedomPayTender>();

        var fieldConditionSql = fieldValue is string ? $"LIKE '{fieldValue}'" : $"= {fieldValue}";
        
        return _informixDbContext
            .FreedomPayTenders!
            .FromSqlRaw(
                $@"SELECT {_queryFactory.GetColumnListSql(typeof(FreedomPayTender))} 
                    FROM hps_tender 
                    WHERE {fieldName} {fieldConditionSql}")
            .AsEnumerable();
    }

    public IEnumerable<FreedomPayTender> GetByDateRange(DateTime startDate, DateTime? endDate)
    {
        var endDateToUse = endDate ?? DateTime.Now;

        var records = _informixDbContext
            .FreedomPayTenders!
            .FromSqlRaw(
                $@"SELECT {_queryFactory.GetColumnListSql(typeof(FreedomPayTender))} 
                    FROM hps_tender 
                    WHERE create_dtm >= {_queryFactory.GetFieldValue(startDate)} 
                    AND create_dtm <=  {_queryFactory.GetFieldValue(endDateToUse)}")
            .AsEnumerable();

        return records;
    }
    
    public IEnumerable<QueryFilterField> GetQueryFilterFields()
    {
        return _queryFactory.GetFilterFieldsForObjectType(typeof(FreedomPayTender));
    }

    public async Task<bool> Insert(FreedomPayTender tender)
    {
        _informixDbContext.FreedomPayTenders?.Add(tender);
        return await _informixDbContext.SaveChangesAsync() > -1;
    }
    
    public async Task<bool> Update(FreedomPayTender tender)
    {
        _informixDbContext.FreedomPayTenders?.Update(tender);
        return await _informixDbContext.SaveChangesAsync() > -1;
    }
}