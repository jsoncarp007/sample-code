﻿using BelleTire.FreedomPay.Freeway.Core.Models;
using IBM.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace BelleTire.PaymentServices.Infrastructure.Repository.FreedomPay.DbContext;

public class FreewayTokenContext : Microsoft.EntityFrameworkCore.DbContext
{
    public FreewayTokenContext()
    {
    }

    public FreewayTokenContext(DbContextOptions<FreewayTokenContext> options)
        : base(options)
    {
    }

    public virtual DbSet<FreedomPayAccountMgr> FreedomPayAccountMgrs { get; set; }
    public virtual DbSet<FreedomPayAccountOwner> FreedomPayAccountOwners { get; set; }
    public virtual DbSet<FreedomPayAuthUserTransaction> FreedomPayAuthUserTransactions { get; set; }
    public virtual DbSet<FreedomPayAuthorizedUser> FreedomPayAuthorizedUsers { get; set; }
    public virtual DbSet<FreedomPayWallet> FreedomPayWallets { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<FreedomPayAccountMgr>(entity =>
        {
            entity.HasKey(e => e.FreedomPayAccountMgrId)
                .HasName("FreedomPay_account_mgr_p1")
                .ForDb2IsClustered(false);

            entity.ToTable("FreedomPay_account_mgr", "dbadm");

            entity.Property(e => e.FreedomPayAccountMgrId)
                .HasColumnType("int(4)")
                .HasColumnName("FreedomPay_account_mgr_id");

            entity.Property(e => e.Active)
                .IsRequired()
                .HasColumnType("char(1)")
                .HasColumnName("active")
                .HasDefaultValueSql("Y");

            entity.Property(e => e.Arnum)
                .IsRequired()
                .HasColumnType("char(8)")
                .HasColumnName("arnum");

            entity.Property(e => e.CreateDtm)
                .HasColumnType("datetime year to second(3594)")
                .HasColumnName("create_dtm");

            entity.Property(e => e.FreedomPayAccountOwnerId)
                .HasColumnType("int(4)")
                .HasColumnName("FreedomPay_account_owner_id");

            entity.HasOne(d => d.FreedomPayAccountOwner)
                .WithMany(p => p.FreedomPayAccountMgrs)
                .HasForeignKey(d => d.FreedomPayAccountOwnerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FreedomPay_account_mgr_f01");
        });

        modelBuilder.Entity<FreedomPayAccountOwner>(entity =>
        {
            entity.HasKey(e => e.FreedomPayAccountOwnerId)
                .HasName("FreedomPay_account_owner_p1")
                .ForDb2IsClustered(false);

            entity.ToTable("FreedomPay_account_owner", "dbadm");

            entity.Property(e => e.FreedomPayAccountOwnerId)
                .HasColumnType("int(4)")
                .HasColumnName("FreedomPay_account_owner_id");

            entity.Property(e => e.Arnum)
                .HasColumnType("char(8)")
                .HasColumnName("arnum");

            entity.Property(e => e.CreateDtm)
                .HasColumnType("datetime year to second(3594)")
                .HasColumnName("create_dtm");
        });

        modelBuilder.Entity<FreedomPayAuthUserTransaction>(entity =>
        {
            entity.HasKey(e => e.FreedomPayAuthUserTransactionId)
                .HasName("FreedomPay_auth_user_transaction_p01")
                .ForDb2IsClustered(false);

            entity.ToTable("FreedomPay_auth_user_transaction", "dbadm");

            entity.Property(e => e.FreedomPayAuthUserTransactionId)
                .HasColumnType("int(4)")
                .HasColumnName("FreedomPay_auth_user_transaction_id");

            entity.Property(e => e.ActiveUser)
                .IsRequired()
                .HasColumnType("char(1)")
                .HasColumnName("active_user")
                .HasDefaultValueSql("Y");

            entity.Property(e => e.CreateDtm)
                .HasColumnType("datetime year to second(3594)")
                .HasColumnName("create_dtm");

            entity.Property(e => e.FirstName)
                .IsRequired()
                .HasColumnType("char(20)")
                .HasColumnName("first_name");

            entity.Property(e => e.FreedomPayAuthorizedUserId)
                .HasColumnType("int(4)")
                .HasColumnName("FreedomPay_authorized_user_id");

            entity.Property(e => e.FreedomPayTenderId)
                .HasColumnType("int(4)")
                .HasColumnName("FreedomPay_tender_id");

            entity.Property(e => e.LastName)
                .IsRequired()
                .HasColumnType("char(20)")
                .HasColumnName("last_name");
        });

        modelBuilder.Entity<FreedomPayAuthorizedUser>(entity =>
        {
            entity.HasKey(e => e.FreedomPayAuthorizedUsersId)
                .HasName("FreedomPay_authorized_users_p1")
                .ForDb2IsClustered(false);

            entity.ToTable("FreedomPay_authorized_users", "dbadm");

            entity.Property(e => e.FreedomPayAuthorizedUsersId)
                .HasColumnType("int(4)")
                .HasColumnName("FreedomPay_authorized_users_id");

            entity.Property(e => e.CreateDtm)
                .HasColumnType("datetime year to second(3594)")
                .HasColumnName("create_dtm");

            entity.Property(e => e.Email)
                .HasColumnType("char(50)")
                .HasColumnName("email");

            entity.Property(e => e.Fax)
                .HasColumnType("char(12)")
                .HasColumnName("fax");

            entity.Property(e => e.FirstName)
                .IsRequired()
                .HasColumnType("char(20)")
                .HasColumnName("first_name");

            entity.Property(e => e.FreedomPayAccountMgrId)
                .HasColumnType("int(4)")
                .HasColumnName("FreedomPay_account_mgr_id");

            entity.Property(e => e.LastName)
                .IsRequired()
                .HasColumnType("char(20)")
                .HasColumnName("last_name");

            entity.Property(e => e.Phone)
                .HasColumnType("char(12)")
                .HasColumnName("phone");

            entity.HasOne(d => d.FreedomPayAccountMgr)
                .WithMany(p => p.FreedomPayAuthorizedUsers)
                .HasForeignKey(d => d.FreedomPayAccountMgrId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FreedomPay_authorized_users_f01");
        });

        modelBuilder.Entity<FreedomPayWallet>(entity =>
        {
            entity.HasKey(e => e.FreedomPayWalletId)
                .HasName("FreedomPay_wallet_p1")
                .ForDb2IsClustered(false);

            entity.ToTable("FreedomPay_wallet", "dbadm");

            entity.Property(e => e.FreedomPayWalletId)
                .HasColumnType("int(4)")
                .HasColumnName("FreedomPay_wallet_id");

            entity.Property(e => e.CardLogo)
                .HasColumnType("int(4)")
                .HasColumnName("card_logo");

            entity.Property(e => e.CreateDtm)
                .HasColumnType("datetime year to second(3594)")
                .HasColumnName("create_dtm");

            entity.Property(e => e.ExpMonth)
                .HasColumnType("int(4)")
                .HasColumnName("exp_month");

            entity.Property(e => e.ExpYear)
                .HasColumnType("int(4)")
                .HasColumnName("exp_year");

            entity.Property(e => e.FreedomPayAccountMgrId)
                .HasColumnType("int(4)")
                .HasColumnName("FreedomPay_account_mgr_id");

            entity.Property(e => e.Token)
                .IsRequired()
                .HasColumnType("char(20)")
                .HasColumnName("token");

            entity.HasOne(d => d.FreedomPayAccountMgr)
                .WithMany(p => p.FreedomPayWallets)
                .HasForeignKey(d => d.FreedomPayAccountMgrId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FreedomPay_wallet_f01");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    private void OnModelCreatingPartial(ModelBuilder modelBuilder)
    {
        throw new System.NotImplementedException();
    }
}