﻿using BelleTire.FreedomPay.CustomerAccount.Core.ContextModels;
using IBM.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace BelleTire.PaymentServices.Infrastructure.Repository.FreedomPay.DbContext;

public class FreewayContext : Microsoft.EntityFrameworkCore.DbContext
{
    public FreewayContext()
    {
    }

    public FreewayContext(DbContextOptions<FreewayContext> options)
        : base(options)
    {
    }

    public virtual DbSet<FreedomPayCustomerAccountLookup> FreedomPayCustomerAccountLookups { get; set; }
    public virtual DbSet<FreedomPayCustomerAccountMoniker> FreedomPayCustomerAccountMonikers { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {

        modelBuilder.Entity<FreedomPayCustomerAccountLookup>(entity =>
        {
            entity.HasKey(e => e.FreedomPayCustomerAccountLookupId)
                .HasName("FreedomPay_cas_lookup_p01")
                .ForDb2IsClustered(false);

            entity.ToTable("FreedomPay_cas_lookup", "dbadm");

            entity.Property(e => e.FreedomPayCustomerAccountLookupId)
                .HasColumnType("int(4)")
                .HasColumnName("FreedomPay_cas_lookup_id");

            entity.Property(e => e.CasRequestLogId)
                .HasColumnType("char(64)")
                .HasColumnName("cas_request_log_id")
                .HasDefaultValue("");

            entity.Property(e => e.CountryCode)
                .IsRequired()
                .HasColumnType("char(3)")
                .HasColumnName("country_code");

            entity.Property(e => e.HomePhoneNbr)
                .IsRequired()
                .HasColumnType("char(10)")
                .HasColumnName("home_phone_nbr");

            entity.Property(e => e.IspFaultCode)
                .HasColumnType("char(10)")
                .HasColumnName("isp_fault_code")
                .HasDefaultValue("");

            entity.Property(e => e.IspFaultMsg)
                .HasColumnType("char(100)")
                .HasColumnName("isp_fault_msg")
                .HasDefaultValue("");

            entity.Property(e => e.IspFriendlyMsg)
                .HasColumnType("char(100)")
                .HasColumnName("isp_friendly_msg")
                .HasDefaultValue("");

            entity.Property(e => e.OperatorId)
                .IsRequired()
                .HasColumnType("char(4)")
                .HasColumnName("operator_id");

            entity.Property(e => e.OrderNum)
                .HasColumnType("int(4)")
                .HasColumnName("order_num");

            entity.Property(e => e.ServerResponsedtm)
                .HasColumnType("datetime year to second(3594)")
                .HasColumnName("server_responsedtm");

            entity.Property(e => e.Ssn4)
                .IsRequired()
                .HasColumnType("char(4)")
                .HasColumnName("ssn4");

            entity.Property(e => e.StoreId)
                .IsRequired()
                .HasColumnType("char(64)")
                .HasColumnName("store_id");

            entity.Property(e => e.TerminalId)
                .IsRequired()
                .HasColumnType("char(64)")
                .HasColumnName("terminal_id");

            entity.Property(e => e.ZipCode)
                .IsRequired()
                .HasColumnType("char(6)")
                .HasColumnName("zip_code");

            entity.Property(e => e.SearchRecordRefNbr)
                .HasColumnType("char(100)")
                .HasColumnName("search_record_ref_nbr");

        });

        modelBuilder.Entity<FreedomPayCustomerAccountMoniker>(entity =>
        {
            entity.HasKey(e => e.FreedomPayCustomerAccountMonikerId)
                .HasName("FreedomPay_cas_moniker_p01")
                .ForDb2IsClustered(false);

            entity.ToTable("FreedomPay_cas_moniker", "dbadm");

            entity.Property(e => e.FreedomPayCustomerAccountMonikerId)
                .HasColumnType("int(4)")
                .HasColumnName("FreedomPay_cas_moniker_id");

            entity.Property(e => e.FreedomPayCustomerAccountLookupId)
                .HasColumnType("int(4)")
                .HasColumnName("FreedomPay_cas_lookup_id");

            entity.Property(e => e.MonikerToken)
                .IsRequired()
                .HasColumnType("char(20)")
                .HasColumnName("moniker_token");

            entity.Property(e => e.OrderNum)
                .HasColumnType("int(4)")
                .HasColumnName("order_num");

            entity.Property(e => e.ServerResponseDtm)
                .HasColumnType("datetime year to second(3594)")
                .HasColumnName("server_responsedtm");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    private void OnModelCreatingPartial(ModelBuilder modelBuilder)
    {
        //throw new System.NotImplementedException();
    }
}