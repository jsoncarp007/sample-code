﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using BelleTire.FreedomPay.CustomerAccount.Core.ContextModels;
using BelleTire.FreedomPay.CustomerAccount.Core.Interfaces;
using BelleTire.FreedomPay.CustomerAccount.Core.ServiceClasses;
using BelleTire.PaymentServices.Infrastructure.Repository.FreedomPay.DbContext;
using Microsoft.EntityFrameworkCore;

namespace BelleTire.PaymentServices.Infrastructure.Repository.FreedomPay;

public class CustomerAccountRepository : ICustomerAccountRepository
{
    private readonly FreewayContext _freewayCasContext;

    public CustomerAccountRepository(FreewayContext freewayCasContext)
    {
        _freewayCasContext = freewayCasContext;
    }

    public async Task<FreedomPayCustomerAccountLookup> InsertAccountLookupRecordAsync(AccountLookup accountLookup, int orderNum)
    {
        if (accountLookup is null) throw new ArgumentNullException(nameof(accountLookup));

        var record = new FreedomPayCustomerAccountLookup
        {
            StoreId = accountLookup.storeId.ToString(),
            TerminalId = accountLookup.terminalId.ToString(),
            OrderNum = orderNum,
            FreedomPayCustomerAccountLookupId = 0,
            CountryCode = accountLookup.countryCode,
            Ssn4 = accountLookup.ssn4.ToString(),
            HomePhoneNbr = accountLookup.homePhoneNbr.ToString(),
            ZipCode = accountLookup.zipCode,
            OperatorId = accountLookup.operatorId
        };

        var result = await _freewayCasContext.FreedomPayCustomerAccountLookups.AddAsync(record);

        await _freewayCasContext.SaveChangesAsync().ConfigureAwait(false);

        // var FreedomPayCustomerAccountLookup = await _freewayCasContext.FreedomPayCustomerAccountLookups.FirstOrDefaultAsync(r => r.OrderNumber == record.OrderNumber);

        return result.Entity;
    }

    public async Task<FreedomPayCustomerAccountLookup> RetrieveAccountLookupRecordAsync(int orderNum, int storeId, uint terminalId)
    {
        var storeIdStr = storeId.ToString();
        var terminalIdStr = terminalId.ToString();

        var item = from a in _freewayCasContext.FreedomPayCustomerAccountLookups
            where a.StoreId.Trim() == storeIdStr
            where a.TerminalId.Trim() == terminalIdStr
            where a.OrderNum == orderNum
            orderby a.FreedomPayCustomerAccountLookupId descending
            select a;

        return await item.FirstOrDefaultAsync().ConfigureAwait(false);
    }

    public async Task<bool> RetrieveAccountLookupCountAsync(int orderNum, int storeId, uint terminalId)
    {
        var storeIdStr = storeId.ToString();
        var terminalIdStr = terminalId.ToString();

        var item = from a in _freewayCasContext.FreedomPayCustomerAccountLookups
            where a.StoreId.Trim() == storeIdStr
            where a.TerminalId.Trim() == terminalIdStr
            where a.OrderNum == orderNum
            orderby a.FreedomPayCustomerAccountLookupId descending
            select a;
        //TODO we should limit the number of attemps at looking up an account, but should we set for a number of hours? 3 attempts in 24 hours?
        return await item.CountAsync() > 3;
    }

    public async Task<FreedomPayCustomerAccountLookup> UpdateAccountLookupRecordAsync(FreedomPayCustomerAccountLookup freedomPayCustomerAccountLookup,
        AccountLookupResponse accountLookupResponse)
    {
        if (freedomPayCustomerAccountLookup is null) throw new ArgumentNullException(nameof(freedomPayCustomerAccountLookup));

        if (accountLookupResponse is null) throw new ArgumentNullException(nameof(accountLookupResponse));

        freedomPayCustomerAccountLookup.CasRequestLogId = accountLookupResponse.casRequestLogId.ToString();
        freedomPayCustomerAccountLookup.ServerResponsedtm = accountLookupResponse.serverResponseTime;
        freedomPayCustomerAccountLookup.IspFaultCode = accountLookupResponse.ispFaultCode;
        freedomPayCustomerAccountLookup.IspFaultMsg = accountLookupResponse.ispFaultMsg;
        freedomPayCustomerAccountLookup.IspFriendlyMsg = accountLookupResponse.ispFaultFriendlyMsg;

        var result = _freewayCasContext.FreedomPayCustomerAccountLookups.Update(freedomPayCustomerAccountLookup);

        await _freewayCasContext.SaveChangesAsync().ConfigureAwait(false);

        return result.Entity;
    }

    public async Task<FreedomPayCustomerAccountMoniker> InsertMonikerTokenRecordAsync(FreedomPayCustomerAccountMoniker freedomPayCustomerAccountMoniker)
    {
        if (freedomPayCustomerAccountMoniker is null) throw new ArgumentNullException(nameof(freedomPayCustomerAccountMoniker));

        var result = await _freewayCasContext.FreedomPayCustomerAccountMonikers.AddAsync(freedomPayCustomerAccountMoniker);

        await _freewayCasContext.SaveChangesAsync().ConfigureAwait(false);

        return result.Entity;
    }

    public async Task<FreedomPayCustomerAccountMoniker> RetrieveSavedMonikerTokenAsync(int freedomPayCustomerAccountLookupId)
    {
        return await _freewayCasContext.FreedomPayCustomerAccountMonikers.FirstOrDefaultAsync(m =>
            m.FreedomPayCustomerAccountLookupId == freedomPayCustomerAccountLookupId).ConfigureAwait(false);
    }
}