﻿using BelleTire.PaymentServices.Core.DataModels;

namespace BelleTire.PaymentServices.Infrastructure.Repository.FreedomPay;

public interface IFreedomPayTenderRepository
{
    IEnumerable<FreedomPayTender> GetByReferenceId(string referenceId);
    IEnumerable<QueryFilterField> GetQueryFilterFields();
    IEnumerable<FreedomPayTender> GetByFieldValue(string fieldName, object fieldValue);
    IEnumerable<FreedomPayTender> GetByDateRange(DateTime startDate, DateTime? endDate);
    Task<bool> Insert(FreedomPayTender tender);
    Task<bool> Update(FreedomPayTender tender);
}