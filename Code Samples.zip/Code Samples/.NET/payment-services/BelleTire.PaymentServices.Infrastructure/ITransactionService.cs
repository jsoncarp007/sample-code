﻿using BelleTire.PaymentServices.Core.Requests;
using BelleTire.PaymentServices.Core.Responses;
using BelleTire.PaymentServices.Infrastructure.TransactionProcessing;

namespace BelleTire.PaymentServices.Infrastructure;

public interface ITransactionService
{
    Task<TransactionResponse> ProcessAuthorizationTransactionAsync(AuthorizationTransaction transaction);
    Task<TransactionResponse> ProcessTransactionAsync(AuthorizationTransaction transaction);
    
    Task<TransactionResponse> ProcessSaleTransactionAsync(PromotionSaleTransaction transaction);
    Task<TransactionResponse> ProcessTransactionAsync(PromotionSaleTransaction transaction);
    
    Task<TransactionResponse> ProcessVoidTransactionAsync(VoidTransaction transaction);
    Task<TransactionResponse> ProcessTransactionAsync(VoidTransaction transaction);
    
    Task<TransactionResponse> ProcessRefundTransactionAsync(RefundTransaction transaction);
    Task<TransactionResponse> ProcessTransactionAsync(RefundTransaction transaction);

    Task<TransactionResponse> AccountLookupByAccountNumberAsync(AccountLookupByAccountNumberRequest accountLookupRequest);
    Task<TransactionResponse> ProcessTransactionAsync(AccountLookupByAccountNumberRequest accountLookupRequest);

    Task<TransactionFinalizeResponse> FinalizeTransaction(string referenceId, int orderNumber);
    Task<TransactionCancellationResponse> CancelTransaction(CancelSaleRequestDto cancelSaleRequestDto);
}
