﻿using BelleTire.Verifone.Core.Request;
using BelleTire.Verifone.Core.Response.Transactions;

namespace BelleTire.Verifone.Core;

public class VerifoneDeviceQuestionService
{
    public Response ResponseReceived;
    public delegate void Response(bool confirmed, string questionId);
    
    private readonly IVerifoneDeviceService _deviceService;
    private readonly VerifoneDeviceQuestionRequestFactory _deviceQuestionRequestFactory;

    public VerifoneDeviceQuestionService(IVerifoneDeviceService deviceService, 
        VerifoneDeviceQuestionRequestFactory deviceQuestionRequestFactory)
    {
        _deviceService = deviceService;
        _deviceQuestionRequestFactory = deviceQuestionRequestFactory;
    }

    public async Task DisplayYesNoQuestion(string questionText, string questionId)
    {
        var request =
            _deviceQuestionRequestFactory.GetQuestionDisplayRequest(questionText, "NO", "YES");

        var response = await _deviceService.ExecuteRequestAsync(request);
        var displayQuestionResponse = (VerifoneDeviceCustomerQuestionResponse) response.DeviceResponse!;

        ResponseReceived?.Invoke(response.Success && displayQuestionResponse.CustomerQuestionData == "YES", questionId);
    }

    public async Task ClearQuestionDisplay()
    {
        // clear the screen
        var clearRequest = _deviceQuestionRequestFactory.GetClearScreenRequest();
        await _deviceService.ExecuteRequestAsync(clearRequest);
    }
}