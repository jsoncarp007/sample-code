﻿using System.Xml.Serialization;
using BelleTire.Verifone.Core.Request.Admin;
using BelleTire.Verifone.Core.Request.LineItem;
using BelleTire.Verifone.Core.Request.Payment;
using BelleTire.Verifone.Core.Request.Report;
using BelleTire.Verifone.Core.Request.SecondaryPort;
using BelleTire.Verifone.Core.Request.Security;
using BelleTire.Verifone.Core.Request.SessionManagement;
using BelleTire.Verifone.Core.Request.Settlement;
using BelleTire.Verifone.Core.Request.Transactions;
using BelleTire.Verifone.Core.Response;

namespace BelleTire.Verifone.Core.Request;

public class VerifoneDeviceRequestFactory
{
    private DeviceCommandMatrix _commandMatrix;
    
    public VerifoneDeviceRequestFactory(DeviceCommandMatrix commandMatrix)
    {
        _commandMatrix = commandMatrix;
    }

    public T GetRequestForCommand<T>(DeviceCommand deviceCommand) where T : VerifoneDeviceRequest
    {
        return (T) Convert.ChangeType(GetRequestForCommand(deviceCommand), typeof(T));
    }

    public VerifoneDeviceRequest GetRequestForCommand(DeviceCommand deviceCommand) =>
        deviceCommand switch
        {
            DeviceCommand.CancelDisplayLeftPanel => new VerifoneDeviceCancelDisplayLeftPanelRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.CancelQrCode => new VerifoneDeviceCancelQrRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Charity => new VerifoneDeviceCharityDonationRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.TokenQuery => new VerifoneDeviceTokenQueryRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Checkbox => new VerifoneDeviceCheckboxRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.CustomerButton => new VerifoneDeviceCustomerButtonRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.CustomerQuestion => new VerifoneDeviceCustomerQuestionRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Survey10 => new VerifoneDeviceCustomerSurvey10Request()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Survey5 => new VerifoneDeviceCustomerSurvey5Request()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Survey => new VerifoneDeviceCustomerSurveyRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.DisplayImage => new VerifoneDeviceDisplayImageRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.DisplayLeftPanel => new VerifoneDeviceDisplayLeftPanelRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.DisplayMessage => new VerifoneDeviceDisplayMessageRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.EmailCapture => new VerifoneDeviceEmailCaptureRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.GetCardData => new VerifoneDeviceGetCardDataRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.GetDeviceName => new VerifoneDeviceGetDeviceNameRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.GetParameters => new VerifoneDeviceGetParametersRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.GetPaymentTypes => new VerifoneDeviceGetPaymentTypesRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Loyalty => new VerifoneDeviceLoyaltyCaptureRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.ProvisionPass => new VerifoneDeviceProvisionPassRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.QueryNfcIni => new VerifoneDeviceQueryNfcIniRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.CreditApplication => new VerifoneDeviceQuickCreditApplicationRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Version => new VerifoneDeviceRetrieveVersionRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.SetDeviceName => new VerifoneDeviceSetDeviceNameRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.SetParameter => new VerifoneDeviceSetParametersRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Signature => new VerifoneDeviceSignatureRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.SignatureExpanded => new VerifoneDeviceExpandedSignatureRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Add => new VerifoneDeviceAddLineItemRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Remove => new VerifoneDeviceRemoveLineItemRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.RemoveAll => new VerifoneDeviceRemoveAllLineItemsRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Show => new VerifoneDeviceShowLineItemsRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.ApplyUpdates => new VerifoneDeviceApplyUpdatesRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.GetCounter => new VerifoneDeviceGetCounterRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.LaneClosed => new VerifoneDeviceLaneClosedRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.SetTime => new VerifoneDeviceSetTimeRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.StoreAndForward => new VerifoneDeviceStoreAndForwardRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Authorize => new VerifoneDeviceAuthorizePaymentRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Capture => new VerifoneDeviceCapturePaymentRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Credit => new VerifoneDeviceCreditPaymentRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Void => new VerifoneDeviceVoidPaymentRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Token => new VerifoneDeviceTokenQueryRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.DailySummary => new VerifoneDeviceDailySettlementSummaryReportRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.PreSettlement => new VerifoneDevicePreSettlementReportRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.DuplicateCheck => new VerifoneDeviceDuplicateCheckRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.LastTransaction => new VerifoneDeviceLastTransactionRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.SettlementErrors => new VerifoneDeviceSettlementErrorReportRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.SettlementSummary => new VerifoneDeviceDailySettlementSummaryReportRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.TransactionSearch => new VerifoneDeviceTransactionSearchRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Cancel => new VerifoneDeviceCancelRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Reboot => new VerifoneDeviceRebootRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Status => new VerifoneDeviceStatusRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.AnyUpdates => new VerifoneDeviceUpdateQueryRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.UpdateStatus => new VerifoneDeviceUpdateStatusRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.RegisterEncryptionPos => new VerifoneDeviceRegisterEncryptionRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.RegisterPos => new VerifoneDeviceRegisterPosRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.TestMac => new VerifoneDeviceTestMacRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.UnregisterAllPos => new VerifoneDeviceUnregisterAllRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.UnregisterPos => new VerifoneDeviceUnregisterPosRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Finish => new VerifoneDeviceFinishSessionRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Start => new VerifoneDeviceStartSessionRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            DeviceCommand.Settle => new VerifoneDeviceScheduleSettlementRequest()
            {
                Command = _commandMatrix.GetCommandStringValueForDeviceCommand(deviceCommand),
                FunctionType = _commandMatrix.GetDeviceFunctionTypeNameForCommand(deviceCommand)
            },

            _ => throw new ArgumentOutOfRangeException(nameof(deviceCommand), deviceCommand, null)
        };

}