﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Report;

public class VerifoneDeviceSettlementErrorReportRequest : VerifoneDeviceRequest
{
    [XmlElement("MAX_NUM_RECORDS_RETURNED")]
    public int? MaxRecords { get; set; }  

    [XmlElement("SEARCHFIELDS")]
    public VerifoneDeviceReportSearchFields? SearchFields { get; set; }  

    [XmlElement("RESPONSEFIELDS")]
    public VerifoneDeviceSettlementErrorResponseFields? ResponseFields { get; set; }  
}