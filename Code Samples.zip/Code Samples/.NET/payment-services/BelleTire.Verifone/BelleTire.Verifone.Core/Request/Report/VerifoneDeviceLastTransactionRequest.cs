namespace BelleTire.Verifone.Core.Request.Report;

public class VerifoneDeviceLastTransactionRequest : VerifoneDeviceRequest {}