﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Report;

public class VerifoneDeviceTransactionSearchResponseFields
{
    [XmlElement("INTRN_SEQ_NUM")]
    public string? IntrnSeqNum { get; set; }  

    [XmlElement("PROCESSOR_ID")]
    public string? ProcessorId { get; set; }  

    [XmlElement("BATCH_SEQ_NUM")]
    public string? BatchSeqNum { get; set; }  

    [XmlElement("TRANS_SEQ_NUM")]
    public string? TransSeqNum { get; set; }  

    [XmlElement("INVOICE")]
    public string? Invoice { get; set; }  

    [XmlElement("COMMAND")]
    public string? Command { get; set; }  

    [XmlElement("ACCT_NUM")]
    public string? AcctNum { get; set; }  

    [XmlElement("EXP_MONTH")]
    public string? ExpMonth { get; set; }  

    [XmlElement("EXP_YEAR")]
    public string? ExpYear { get; set; }  

    [XmlElement("CARDHOLDER")]
    public string? Cardholder { get; set; }  

    [XmlElement("TRANS_AMOUNT")]
    public string? TransAmount { get; set; }  

    [XmlElement("REFERENCE")]
    public string? Reference { get; set; }  

    [XmlElement("TRANS_DATE")]
    public string? TransDate { get; set; }  

    [XmlElement("TRANS_TIME")]
    public string? TransTime { get; set; }  

    [XmlElement("CTROUTD")]
    public string? Ctroutd { get; set; }  

    [XmlElement("TROUTD")]
    public string? Troutd { get; set; }  

    [XmlElement("ORIG_SEQ_NUM")]
    public string? OrigSeqNum { get; set; }  

    [XmlElement("STATUS_CODE")]
    public string? StatusCode { get; set; }  
    
    [XmlElement("PAYMENT_TYPE")]
    public string? PaymentType { get; set; }  

    [XmlElement("PAYMENT_MEDIA")]
    public string? PaymentMedia { get; set; }  

    [XmlElement("RESULT_CODE")]
    public string? ResultCode { get; set; }  

    [XmlElement("AUTH_CODE")]
    public string? AuthCode { get; set; }  

    [XmlElement("TRACE_CODE")]
    public string? TraceCode { get; set; }  

    [XmlElement("AVS_CODE")]
    public string? AvsCode { get; set; }  

    [XmlElement("CVV2_CODE")]
    public string? Cvv2Code { get; set; }  

    [XmlElement("CASHBACK_AMOUNT")]
    public string? CashbackAmount { get; set; }  

    [XmlElement("TIP_AMOUNT")]
    public string? TipAmount { get; set; }  

    [XmlElement("RESPONSE_REFERENCE")]
    public string? ResponseReference { get; set; }  

    [XmlElement("R_AUTH_CODE")]
    public string? RAuthCode { get; set; }  
}