﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Report;

public class VerifoneDeviceSettlementSummaryReportResponseFields
{
    [XmlElement("BATCH_SEQ_NUM")]
    public string? BatchSequenceNumber { get; set; }  

    [XmlElement("ERR_TRANS_IN_BATCH")]
    public string? ErrorTransactionInBatch { get; set; }

    [XmlElement("SETTLE_DATE")]
    public string? SettlementDate { get; set; }

    [XmlElement("SETTLE_CODE")]
    public string? SettlementCode { get; set; }  

    [XmlElement("CRDT_SALE_AMT")]
    public string? CreditSaleAmt { get; set; }  

    [XmlElement("CRDT_SALE_CNT")]
    public string? CreditSaleCount { get; set; }  

    [XmlElement("CRDT_CRDT_AMT")]
    public string? CreditCardAmount { get; set; }

    [XmlElement("CRDT_CRDT_CNT")]
    public string? CreditCardCount { get; set; }  

    [XmlElement("CRDT_VOID_AMT")]
    public string? CreditVoidAmount { get; set; }

    [XmlElement("CRDT_VOID_CNT")]
    public string? CreditVoidCount { get; set; }  
}