﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Report;

public class VerifoneDeviceReportSearchFields
{
    [XmlElement("START_TRANS_DATE")] 
    public string? StartTransactionDate { get; set; }  // Format yyyy.MM.dd

    [XmlElement("START_TRANS_TIME")]
    public string? StartTransactionTime {get;set;} // Format HH:mm:ss

    [XmlElement("END_TRANS_DATE")]
    public string? EndTransactionDate { get; set; } // Format yyyy.MM.dd

    [XmlElement("END_TRANS_TIME")]
    public string? EndTransactionTime { get; set; }

    [XmlElement("PAYMENT_TYPE")]
    public string? PaymentType { get; set; }  

    [XmlElement("REQUEST_COMMAND")]
    public string? RequestCommand { get; set; } 

    [XmlElement("ACCT_NUM")]
    public string? AccountNumber { get; set; }  

    [XmlElement("INVOICE")]
    public string? Invoice { get; set; }  

    [XmlElement("BATCH_SEQ_NUM")]
    public int? BatchSequenceNumber { get; set; }  

    [XmlElement("START_TRANS_AMOUNT")]
    public decimal? StartTransactionAmount { get; set; } 

    [XmlElement("END_TRANS_AMOUNT")]
    public decimal? EndTransactionAmount { get; set; }  

    [XmlElement("START_TROUTD")]
    public long? StartTroutd { get; set; }  

    [XmlElement("END_TROUTD")]
    public long? EndTroutd { get; set; }  

    [XmlElement("STATUS_CODE")]
    public long? StatusCode { get; set; } 
}