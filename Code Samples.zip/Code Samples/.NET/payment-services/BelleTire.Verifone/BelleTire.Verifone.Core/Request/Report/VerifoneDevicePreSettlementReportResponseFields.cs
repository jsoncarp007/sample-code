﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Report;

public class VerifoneDevicePreSettlementReportResponseFields
{
    // all values are either string.empty or null 

    [XmlElement("COMMAND")] 
    public string? Command { get; set; }

    [XmlElement("TRANS_AMOUNT")]
    public string? TransactionAmount { get; set; }

    [XmlElement("TROUTD")]
    public string? Troutd { get; set; }

    [XmlElement("PAYMENT_TYPE")]
    public string? PaymentType { get; set; }

    [XmlElement("CTROUTD")]
    public string? Ctroutd { get; set; }

    [XmlElement("CASHBACK_AMNT")]
    public string? CashBackAmount { get; set; }

    [XmlElement("TIP_AMOUNT")]
    public string? TipAmount { get; set; }
}