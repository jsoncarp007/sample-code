﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Report;

public class VerifoneDevicePreSettlementReportRequest : VerifoneDeviceRequest
{
    [XmlElement("MAX_NUM_RECORDS_RETURNED")]
    public int? MaxRecords { get; set; }  

    [XmlElement("RESPONSEFIELDS")]
    public VerifoneDevicePreSettlementReportResponseFields? ResponseFields { get; set; }  

    [XmlElement("SEARCHFIELDS")]
    public VerifoneDeviceReportSearchFields? SearchFields { get; set; }  
}