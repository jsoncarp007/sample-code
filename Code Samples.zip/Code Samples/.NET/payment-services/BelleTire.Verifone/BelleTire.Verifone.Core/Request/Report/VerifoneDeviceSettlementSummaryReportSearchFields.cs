﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Report;

public class VerifoneDeviceSettlementSummaryReportSearchFields
{
    [XmlElement("START_SETTLE_DATE")]
    public string? StartSettlementDate { get; set; }  

    [XmlElement("END_SETTLE_DATE")]
    public string? EndSettlementDate { get; set; }  
}