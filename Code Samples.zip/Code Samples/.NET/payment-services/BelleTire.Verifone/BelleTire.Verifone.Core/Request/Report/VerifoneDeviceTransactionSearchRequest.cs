﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Report;

public class VerifoneDeviceTransactionSearchRequest : VerifoneDeviceRequest
{
    [XmlElement("MAX_NUM_RECORDS_RETURNED")]
    public int MaxRecords { get; set; }  

    [XmlElement("RESPONSEFIELDS")]
    public VerifoneDeviceTransactionSearchResponseFields? ResponseFields { get; set; }  

    [XmlElement("SEARCHFIELDS")]
    public VerifoneDeviceReportSearchFields? SearchFields { get; set; }  
}