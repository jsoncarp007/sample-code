﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Report;

public class VerifoneDeviceDuplicateCheckRequest : VerifoneDeviceRequest 
{
    [XmlElement("DUPCHECK_DATE")]
    public string? DuplicateCheckDate { get; set; }

    [XmlElement("DUPCHECK_FROMTIME")]
    public string? DuplicateCheckFromTime { get; set; }
   
    [XmlElement("DUPCHECK_TOTIME")]
    public string? DuplicateCheckToTime { get; set; }
}