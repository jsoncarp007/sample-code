﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.LineItem;

[XmlRoot("LINE_ITEMS")]
public class VerifoneDeviceLineItems
{
    [XmlElement("MERCHANDISE")]
    public List<VerifoneDeviceMerchandise>? MerchandiseList { get; set; }

    [XmlElement("OFFER")]
    public List<VerifoneDeviceOffer>? OfferList { get; set; }
}