﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.LineItem;

public class VerifoneDeviceRemoveLineItemRequest : VerifoneDeviceRequest
{
    [XmlElement("LINE_ITEM_ID")]
    public long? LineItemId { get; set; }  

    [XmlElement("RUNNING_SUB_TOTAL")]
    public decimal? RunningSubTotal { get; set; }  

    [XmlElement("RUNNING_TAX_TOTAL")]
    public decimal? RunningTaxTotal { get; set; }  

    [XmlElement("RUNNING_TRANS_AMOUNT")]
    public decimal? RunningTransactionAmount { get; set; }  
}