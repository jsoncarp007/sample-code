﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.LineItem;

[XmlRoot("OFFER")]
public class VerifoneDeviceOffer
{
    [XmlElement("TYPE")]
    public long? Type { get; set; }

    [XmlElement("LINE_ITEM_ID")]
    public long? LineItemId { get; set; }

    [XmlElement("SKU")]
    public string? Sku { get; set; } 

    [XmlElement("DESCRIPTION")]
    public string? Description { get; set; }

    [XmlElement("OFFER_AMOUNT")]
    public decimal? OfferAmount { get; set; }

    [XmlElement("OFFER_LINE_ITEM")]
    public int? OfferLineItem { get; set; }

    [XmlElement("FONT_COL_VALUE")]
    public int? FontColValue { get; set; }
}