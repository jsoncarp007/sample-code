﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.LineItem;

public class VerifoneDeviceAddLineItemRequest : VerifoneDeviceRequest
{
    [XmlElement("RUNNING_SUB_TOTAL")]
    public decimal? RunningSubTotal { get; set; }  

    [XmlElement("RUNNING_TAX_AMOUNT")]
    public decimal? RunningTaxAmount { get; set; }  

    [XmlElement("RUNNING_TRANS_AMOUNT")]
    public decimal? RunningTransactionAmount { get; set; }  

    [XmlElement(ElementName = "LINE_ITEMS")]
    public VerifoneDeviceLineItems? LineItems { get; set; }  
}