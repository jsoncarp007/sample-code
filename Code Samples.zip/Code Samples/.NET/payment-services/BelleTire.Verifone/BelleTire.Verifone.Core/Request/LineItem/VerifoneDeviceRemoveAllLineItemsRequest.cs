﻿namespace BelleTire.Verifone.Core.Request.LineItem;

public class VerifoneDeviceRemoveAllLineItemsRequest : VerifoneDeviceRequest { }