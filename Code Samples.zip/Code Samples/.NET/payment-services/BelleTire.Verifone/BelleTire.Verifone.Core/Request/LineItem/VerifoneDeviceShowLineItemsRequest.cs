﻿namespace BelleTire.Verifone.Core.Request.LineItem;

public class VerifoneDeviceShowLineItemsRequest : VerifoneDeviceRequest { }