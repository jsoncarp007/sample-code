﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.LineItem;

[XmlRoot("MERCHANDISE")]
public class VerifoneDeviceMerchandise
{
    [XmlElement("LINE_ITEM_ID")]
    public long? LineItemId { get; set; }  

    [XmlElement("SKU")]
    public string? Sku { get; set; }  

    [XmlElement("UPC")]
    public string? Upc { get; set; }  

    [XmlElement("DESCRIPTION")]
    public string? Description { get; set; }  

    [XmlElement("QUANTITY")]
    public int? Quantity { get; set; }  

    [XmlElement("UNIT_PRICE")]
    public decimal? UnitPrice { get; set; }  

    [XmlElement("EXTENDED_PRICE")]
    public decimal? ExtendedPrice { get; set; }  

    [XmlElement("FONT_COL_VALUE")]
    public string? FontColValue { get; set; }
}