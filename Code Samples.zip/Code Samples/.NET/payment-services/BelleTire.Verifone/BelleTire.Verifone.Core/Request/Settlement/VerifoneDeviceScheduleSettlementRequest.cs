﻿namespace BelleTire.Verifone.Core.Request.Settlement;

public class VerifoneDeviceScheduleSettlementRequest : VerifoneDeviceRequest
{
    
}