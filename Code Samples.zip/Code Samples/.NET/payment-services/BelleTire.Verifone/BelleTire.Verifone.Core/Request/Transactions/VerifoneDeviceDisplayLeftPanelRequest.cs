﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceDisplayLeftPanelRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("LEFTPANEL_TEXT")]
    public string? LeftPanelText { get; set; }

    [XmlElement("LEFTPANEL_IMG")]
    public string? LeftPanelImage { get; set; }

    [XmlElement("REQUEST_NUMERIC_INPUT")]
    public string? ManualEntry { get; set; }

    [XmlElement("REQUEST_BTNS")]
    public string? RequestButtons { get; set; }

    [XmlElement("BUTTON_LABEL1")]
    public string? ButtonLabel1 { get; set; }

    [XmlElement("BUTTON_LABEL2")]
    public string? ButtonLabel2 { get; set; }

    [XmlElement("NUMERIC_INPUT_FORMAT")]
    public string? NumericInputFormat { get; set; }
}