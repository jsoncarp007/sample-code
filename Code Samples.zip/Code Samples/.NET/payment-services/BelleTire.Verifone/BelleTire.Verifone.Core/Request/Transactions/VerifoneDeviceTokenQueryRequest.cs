namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceTokenQueryRequest : VerifoneDeviceTransactionRequest {}