﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceRetrieveVersionRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("DISPLAY_VERSION")]
    public int? DisplayVersion { get; set; }
}