﻿namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceQueryNfcIniRequest : VerifoneDeviceTransactionRequest {}