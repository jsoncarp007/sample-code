﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceLaneClosedRequest : VerifoneDeviceRequest
{
    [XmlElement("DISPLAY_TEXT")]
    public string? DisplayText { get; set; }  

    [XmlElement("FONT_COL_VALUE")]
    public string? FontColValue { get; set; }  

    [XmlElement("FONT_SIZE")]
    public int? FontSize { get; set; }
}