﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceExpandedSignatureRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("DISPLAY_TEXT")]
    public string? DisplayText { get; set; }

    [XmlElement("CHECKBOX_REQ")]
    public string? CheckboxRequired { get; set; }

    [XmlElement("CHECKBOX_LABEL")]
    public string? CheckboxLabel { get; set; }  

}