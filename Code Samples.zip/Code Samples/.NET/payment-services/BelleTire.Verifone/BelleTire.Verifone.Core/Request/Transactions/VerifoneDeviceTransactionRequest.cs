﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceTransactionRequest : VerifoneDeviceRequest
{
    [XmlElement("POS_RECON")]
    public string? PosRecon { get; set; }  
}