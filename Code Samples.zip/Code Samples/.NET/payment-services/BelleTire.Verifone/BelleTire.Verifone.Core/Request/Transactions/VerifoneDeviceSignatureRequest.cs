﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceSignatureRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("DISPLAY_TEXT")]
    public string? DisplayText { get; set; } 
}