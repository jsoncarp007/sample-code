﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceCustomerQuestionRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("DISPLAY_TEXT1")]
    public string? DisplayText1 { get; set; }  

    [XmlElement("DISPLAY_TEXT2")]
    public string? DisplayText2 { get; set; }  

    [XmlElement("DISPLAY_TEXT3")]
    public string? DisplayText3 { get; set; } 

    [XmlElement("DISPLAY_TEXT4")]
    public string? DisplayText4 { get; set; } 

    [XmlElement("DISPLAY_TEXT5")]
    public string? DisplayText5 { get; set; }  
    
    [XmlElement("DISPLAY_TEXT6")]
    public string? DisplayText6 { get; set; }  

    [XmlElement("DISPLAY_TEXT7")]
    public string? DisplayText7 { get; set; }  

    [XmlElement("DISPLAY_TEXT8")]
    public string? DisplayText8 { get; set; } 

    [XmlElement("DISPLAY_TEXT9")]
    public string? DisplayText9 { get; set; }  

    [XmlElement("DISPLAY_TEXT10")]
    public string? DisplayText10 { get; set; }  

    [XmlElement("DISPLAY_BULKDATA")]
    public string? DisplayBulkData { get; set; }  

    [XmlElement("BUTTON_INNER_TEXT_LEFT")]
    public string? ButtonInnerTextLeft { get; set; } 

    [XmlElement("BUTTON_INNER_TEXT_RIGHT")]
    public string? ButtonInnerTextRight { get; set; } 

    [XmlElement("BUTTON_TEXT_LEFT")]
    public string? ButtonTextLeft { get; set; }  

    [XmlElement("BUTTON_TEXT_RIGHT")]
    public string? ButtonTextRight { get; set; }  

    [XmlElement("RETURN_SCREEN")]
    public string? ReturnScreen { get; set; }  
}