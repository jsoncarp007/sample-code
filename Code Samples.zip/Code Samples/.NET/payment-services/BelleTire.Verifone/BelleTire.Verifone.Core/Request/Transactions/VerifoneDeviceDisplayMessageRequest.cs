﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceDisplayMessageRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("DISPLAY_TEXT")]
    public string? DisplayText { get; set; }

    [XmlElement("FULL_SCREEN")]
    public string? FullScreen { get; set; }

    [XmlElement("TIMEOUT_DATA")]
    public int? TimeoutData { get; set; }
}