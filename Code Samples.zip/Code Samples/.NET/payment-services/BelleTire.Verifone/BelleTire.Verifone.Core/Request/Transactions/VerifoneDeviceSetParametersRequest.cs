﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceSetParametersRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("PARAM")]
    public string? Parameter { get; set; }  

    [XmlElement("PARM_MID")]
    public string? ParameterMid { get; set; }  

    [XmlElement("PARM_ALTMERCHID")]
    public string? ParameterAlternateMerchantId { get; set; } 

    [XmlElement("PARM_TID")]
    public string? ParameterTId { get; set; }  // transaction id?  

    [XmlElement("PARM_USERNAME")]
    public string? ParameterUserName { get; set; } 

    [XmlElement("PARM_PASSWORD")]
    public string? ParameterPassword { get; set; } 

    [XmlElement("PARM_LANE")]
    public string? ParametrerLane { get; set; }

    [XmlElement("PARM_PARTNERID")]
    public string? ParameterPartnerId { get; set; } 

    [XmlElement("PARM_TRANSPORT_KEY")]
    public string? ParameterTransportKey { get; set; }  

    [XmlElement("PARM_HOST_IND")]
    public string? ParameterHostInd { get; set; }

    [XmlElement("PARM_ADMINURL")]
    public string? ParameterAdminUrl { get; set; } 

    [XmlElement("PARM_PRIMURL")]
    public string? ParameterPrimaryUrl { get; set; }  

    [XmlElement("PARM_SCNDURL")]
    public string? ParameterScanDurl { get; set; }

    [XmlElement("PARM_TIMEZONE")]
    public string? ParameterTimeZone { get; set; } 

    [XmlElement("PARM_TOKEN_TYPE")]
    public string? ParameterTokenType { get; set; }
}