﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceCustomerSurvey10Request : VerifoneDeviceTransactionRequest
{
    [XmlElement("DISPLAY_TEXT1")]
    public string? DisplayText1 { get; set; }  

    [XmlElement("DISPLAY_TEXT2")]
    public string? DisplayText2 { get; set; }  

    [XmlElement("DISPLAY_TEXT3")]
    public string? DisplayText3 { get; set; } 

    [XmlElement("DISPLAY_TEXT4")]
    public string? DisplayText4 { get; set; } 

    [XmlElement("DISPLAY_TEXT5")]
    public string? DisplayText5 { get; set; }
}