﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceCustomerSurveyRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("DISPLAY_TEXT1")]
    public string? DisplayText1 { get; set; }  

    [XmlElement("DISPLAY_TEXT2")]
    public string? DisplayText2 { get; set; }  

    [XmlElement("RADIO_BUTTON_TEXT1")]
    public string? RadioButtonText1 { get; set; } 

    [XmlElement("RADIO_BUTTON_TEXT2")]
    public string? RadioButtonText2 { get; set; }

    [XmlElement("RADIO_BUTTON_TEXT3")]
    public string? RadioButtonText3 { get; set; }

    [XmlElement("RADIO_BUTTON_TEXT4")]
    public string? RadioButtonText4 { get; set; }

    [XmlElement("RADIO_BUTTON_TEXT5")]
    public string? RadioButtonText5 { get; set; }

    [XmlElement("RADIO_BUTTON_TEXT6")]
    public string? RadioButtonText6 { get; set; }

    [XmlElement("RETURN_SCREEN")]
    public string? ReturnScreen { get; set; }
}