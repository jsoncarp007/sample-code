﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceGetParametersRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("PARAM")]
    public string? Param { get; set; }  
}