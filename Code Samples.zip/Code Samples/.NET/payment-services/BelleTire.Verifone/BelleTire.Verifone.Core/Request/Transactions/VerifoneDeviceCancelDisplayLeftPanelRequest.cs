namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceCancelDisplayLeftPanelRequest : VerifoneDeviceTransactionRequest{}