﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceQuickCreditApplicationRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("RETURN_SCREEN")]
    public string? ReturnScreen { get; set; }  

    [XmlElement("TRAINING_ACTION")]
    public string? TrainingAction { get; set; } 

    [XmlElement("FORWARD_PROXY")]
    public string? ForwardProxy { get; set; } 

    [XmlElement("PROXY_TIMEOUT")]
    public int? ProxyTimeout { get; set; }  

    [XmlElement("PROXY_REF")]
    public string? ProxyRef { get; set; }

    [XmlElement("PASS_THROUGH")]
    public string? PassThrough { get; set; }

    [XmlElement("PROMPT1")]
    public string? Prompt1 { get; set; }  

    [XmlElement("PROMPT1_DATA")]
    public string? Prompt1Data{ get; set; } 

    [XmlElement("PROMPT1_TYPE")]
    public string? Prompt1Type { get; set; } 

    [XmlElement("PROMPT1_MIN")]
    public int? Prompt1Min { get; set; } 

    [XmlElement("PROMPT1_MAX")]
    public int? Prompt1Max { get; set; }  

    [XmlElement("PROMPT1_FORMAT")]
    public string? Prompt1Format { get; set; } 

    [XmlElement("PROMPT1_MASK")]
    public string? Prompt1Mask { get; set; } 

    [XmlElement("BUTTON1_INNER_TEXT_LEFT")]
    public string? Button1InnerTextLeft { get; set; }  

    [XmlElement("BUTTON1_INNER_TEXT_RIGHT")]
    public string? Button1InnerTextRight { get; set; } 

    [XmlElement("BUTTON1_TEXT_LEFT")]
    public string? Button1TextLeft { get; set; }  

    [XmlElement("BUTTON1_TEXT_RIGHT")]
    public string? Button1TextRight { get; set; }  


    [XmlElement("PROMPT2")]
    public string? Prompt2 { get; set; }  

    [XmlElement("PROMPT2_DATA")]
    public string? Prompt2Data{ get; set; } 

    [XmlElement("PROMPT2_TYPE")]
    public string? Prompt2Type { get; set; } 

    [XmlElement("PROMPT2_MIN")]
    public int? Prompt2Min { get; set; } 

    [XmlElement("PROMPT2_MAX")]
    public int? Prompt2Max { get; set; }  

    [XmlElement("PROMPT2_FORMAT")]
    public string? Prompt2Format { get; set; } 

    [XmlElement("PROMPT2_MASK")]
    public string? Prompt2Mask { get; set; } 

    [XmlElement("BUTTON2_INNER_TEXT_LEFT")]
    public string? Button2InnerTextLeft { get; set; }  

    [XmlElement("BUTTON2_INNER_TEXT_RIGHT")]
    public string? Button2InnerTextRight { get; set; } 

    [XmlElement("BUTTON2_TEXT_LEFT")]
    public string? Button2TextLeft { get; set; }  

    [XmlElement("BUTTON2_TEXT_RIGHT")]
    public string? Button2TextRight { get; set; }  

    [XmlElement("PROMPT3")]
    public string? Prompt3 { get; set; }  

    [XmlElement("PROMPT3_DATA")]
    public string? Prompt3Data{ get; set; } 

    [XmlElement("PROMPT3_TYPE")]
    public string? Prompt3Type { get; set; } 

    [XmlElement("PROMPT3_MIN")]
    public int? Prompt3Min { get; set; } 

    [XmlElement("PROMPT3_MAX")]
    public int? Prompt3Max { get; set; }  

    [XmlElement("PROMPT3_FORMAT")]
    public string? Prompt3Format { get; set; } 

    [XmlElement("PROMPT3_MASK")]
    public string? Prompt3Mask { get; set; } 

    [XmlElement("BUTTON3_INNER_TEXT_LEFT")]
    public string? Button3InnerTextLeft { get; set; }  

    [XmlElement("BUTTON3_INNER_TEXT_RIGHT")]
    public string? Button3InnerTextRight { get; set; } 

    [XmlElement("BUTTON3_TEXT_LEFT")]
    public string? Button3TextLeft { get; set; }  

    [XmlElement("BUTTON3_TEXT_RIGHT")]
    public string? Button3TextRight { get; set; }  

    [XmlElement("PROMPT4")]
    public string? Prompt4 { get; set; }  

    [XmlElement("PROMPT4_DATA")]
    public string? Prompt4Data{ get; set; } 

    [XmlElement("PROMPT4_TYPE")]
    public string? Prompt4Type { get; set; } 

    [XmlElement("PROMPT4_MIN")]
    public int? Prompt4Min { get; set; } 

    [XmlElement("PROMPT4_MAX")]
    public int? Prompt4Max { get; set; }  

    [XmlElement("PROMPT4_FORMAT")]
    public string? Prompt4Format { get; set; } 

    [XmlElement("PROMPT4_MASK")]
    public string? Prompt4Mask { get; set; } 

    [XmlElement("BUTTON4_INNER_TEXT_LEFT")]
    public string? Button4InnerTextLeft { get; set; }  

    [XmlElement("BUTTON4_INNER_TEXT_RIGHT")]
    public string? Button4InnerTextRight { get; set; } 

    [XmlElement("BUTTON4_TEXT_LEFT")]
    public string? Button4TextLeft { get; set; }  

    [XmlElement("BUTTON4_TEXT_RIGHT")]
    public string? Button4TextRight { get; set; }  

    [XmlElement("PROMPT5")]
    public string? Prompt5 { get; set; }  

    [XmlElement("PROMPT5_DATA")]
    public string? Prompt5Data{ get; set; } 

    [XmlElement("PROMPT5_TYPE")]
    public string? Prompt5Type { get; set; } 

    [XmlElement("PROMPT5_MIN")]
    public int? Prompt5Min { get; set; } 

    [XmlElement("PROMPT5_MAX")]
    public int? Prompt5Max { get; set; }  

    [XmlElement("PROMPT5_FORMAT")]
    public string? Prompt5Format { get; set; } 

    [XmlElement("PROMPT5_MASK")]
    public string? Prompt5Mask { get; set; } 

    [XmlElement("BUTTON5_INNER_TEXT_LEFT")]
    public string? Button5InnerTextLeft { get; set; }  

    [XmlElement("BUTTON5_INNER_TEXT_RIGHT")]
    public string? Button5InnerTextRight { get; set; } 

    [XmlElement("BUTTON5_TEXT_LEFT")]
    public string? Button5TextLeft { get; set; }  

    [XmlElement("BUTTON5_TEXT_RIGHT")]
    public string? Button5TextRight { get; set; }  

    [XmlElement("PROMPT6")]
    public string? Prompt6 { get; set; }  

    [XmlElement("PROMPT6_DATA")]
    public string? Prompt6Data{ get; set; } 

    [XmlElement("PROMPT6_TYPE")]
    public string? Prompt6Type { get; set; } 

    [XmlElement("PROMPT6_MIN")]
    public int? Prompt6Min { get; set; } 

    [XmlElement("PROMPT6_MAX")]
    public int? Prompt6Max { get; set; }  

    [XmlElement("PROMPT6_FORMAT")]
    public string? Prompt6Format { get; set; } 

    [XmlElement("PROMPT6_MASK")]
    public string? Prompt6Mask { get; set; } 

    [XmlElement("BUTTON6_INNER_TEXT_LEFT")]
    public string? Button6InnerTextLeft { get; set; }  

    [XmlElement("BUTTON6_INNER_TEXT_RIGHT")]
    public string? Button6InnerTextRight { get; set; } 

    [XmlElement("BUTTON6_TEXT_LEFT")]
    public string? Button6TextLeft { get; set; }  

    [XmlElement("BUTTON6_TEXT_RIGHT")]
    public string? Button6TextRight { get; set; }  

    [XmlElement("PROMPT7")]
    public string? Prompt7 { get; set; }  

    [XmlElement("PROMPT7_DATA")]
    public string? Prompt7Data{ get; set; } 

    [XmlElement("PROMPT7_TYPE")]
    public string? Prompt7Type { get; set; } 

    [XmlElement("PROMPT7_MIN")]
    public int? Prompt7Min { get; set; } 

    [XmlElement("PROMPT7_MAX")]
    public int? Prompt7Max { get; set; }  

    [XmlElement("PROMPT7_FORMAT")]
    public string? Prompt7Format { get; set; } 

    [XmlElement("PROMPT7_MASK")]
    public string? Prompt7Mask { get; set; } 

    [XmlElement("BUTTON7_INNER_TEXT_LEFT")]
    public string? Button7InnerTextLeft { get; set; }  

    [XmlElement("BUTTON7_INNER_TEXT_RIGHT")]
    public string? Button7InnerTextRight { get; set; } 

    [XmlElement("BUTTON7_TEXT_LEFT")]
    public string? Button7TextLeft { get; set; }  

    [XmlElement("BUTTON7_TEXT_RIGHT")]
    public string? Button7TextRight { get; set; }  

    [XmlElement("PROMPT8")]
    public string? Prompt8 { get; set; }  

    [XmlElement("PROMPT8_DATA")]
    public string? Prompt8Data{ get; set; } 

    [XmlElement("PROMPT8_TYPE")]
    public string? Prompt8Type { get; set; } 

    [XmlElement("PROMPT8_MIN")]
    public int? Prompt8Min { get; set; } 

    [XmlElement("PROMPT8_MAX")]
    public int? Prompt8Max { get; set; }  

    [XmlElement("PROMPT8_FORMAT")]
    public string? Prompt8Format { get; set; } 

    [XmlElement("PROMPT8_MASK")]
    public string? Prompt8Mask { get; set; } 

    [XmlElement("BUTTON8_INNER_TEXT_LEFT")]
    public string? Button8InnerTextLeft { get; set; }  

    [XmlElement("BUTTON8_INNER_TEXT_RIGHT")]
    public string? Button8InnerTextRight { get; set; } 

    [XmlElement("BUTTON8_TEXT_LEFT")]
    public string? Button8TextLeft { get; set; }  

    [XmlElement("BUTTON8_TEXT_RIGHT")]
    public string? Button8TextRight { get; set; }  

    [XmlElement("PROMPT9")]
    public string? Prompt9 { get; set; }  

    [XmlElement("PROMPT9_DATA")]
    public string? Prompt9Data{ get; set; } 

    [XmlElement("PROMPT9_TYPE")]
    public string? Prompt9Type { get; set; } 

    [XmlElement("PROMPT9_MIN")]
    public int? Prompt9Min { get; set; } 

    [XmlElement("PROMPT9_MAX")]
    public int? Prompt9Max { get; set; }  

    [XmlElement("PROMPT9_FORMAT")]
    public string? Prompt9Format { get; set; } 

    [XmlElement("PROMPT9_MASK")]
    public string? Prompt9Mask { get; set; } 

    [XmlElement("BUTTON9_INNER_TEXT_LEFT")]
    public string? Button9InnerTextLeft { get; set; }  

    [XmlElement("BUTTON9_INNER_TEXT_RIGHT")]
    public string? Button9InnerTextRight { get; set; } 

    [XmlElement("BUTTON9_TEXT_LEFT")]
    public string? Button9TextLeft { get; set; }  

    [XmlElement("BUTTON9_TEXT_RIGHT")]
    public string? Button9TextRight { get; set; }  

    [XmlElement("PROMPT10")]
    public string? Prompt10 { get; set; }  

    [XmlElement("PROMPT10_DATA")]
    public string? Prompt10Data{ get; set; } 

    [XmlElement("PROMPT10_TYPE")]
    public string? Prompt10Type { get; set; } 

    [XmlElement("PROMPT10_MIN")]
    public int? Prompt10Min { get; set; } 

    [XmlElement("PROMPT10_MAX")]
    public int? Prompt10Max { get; set; }  

    [XmlElement("PROMPT10_FORMAT")]
    public string? Prompt10Format { get; set; } 

    [XmlElement("PROMPT10_MASK")]
    public string? Prompt10Mask { get; set; } 

    [XmlElement("BUTTON10_INNER_TEXT_LEFT")]
    public string? Button10InnerTextLeft { get; set; }  

    [XmlElement("BUTTON10_INNER_TEXT_RIGHT")]
    public string? Button10InnerTextRight { get; set; } 

    [XmlElement("BUTTON10_TEXT_LEFT")]
    public string? Button10TextLeft { get; set; }  

    [XmlElement("BUTTON10_TEXT_RIGHT")]
    public string? Button10TextRight { get; set; }  

}