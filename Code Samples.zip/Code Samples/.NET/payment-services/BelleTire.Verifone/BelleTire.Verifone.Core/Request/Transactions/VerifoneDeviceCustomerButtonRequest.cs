﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceCustomerButtonRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("DISPLAY_TEXT1")]
    public string? DisplayText1 { get; set; }  

    [XmlElement("DISPLAY_TEXT2")]
    public string? DisplayText2 { get; set; }  

    [XmlElement("DISPLAY_TEXT3")]
    public string? DisplayText3 { get; set; } 

    [XmlElement("DISPLAY_TEXT4")]
    public string? DisplayText4 { get; set; } 

    [XmlElement("DISPLAY_TEXT5")]
    public string? DisplayText5 { get; set; }  

    [XmlElement("BUTTON_LABEL1")]
    public string? ButtonLabel1 { get; set; } 

    [XmlElement("BUTTON_LABEL2")]
    public string? ButtonLabel2 { get; set; }  

    [XmlElement("BUTTON_LABEL3")]
    public string? ButtonLabel3 { get; set; }  

    [XmlElement("BUTTON_LABEL4")]
    public string? ButtonLabel4 { get; set; }  

    [XmlElement("BUTTON_LABEL5")]
    public string? ButtonLabel5 { get; set; }  

    [XmlElement("BUTTON_LABEL6")]
    public string? ButtonLabel6 { get; set; }  

    [XmlElement("RETURN_SCREEN")]
    public string? ReturnScreen { get; set; } 

}