﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceProvisionPassRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("MERCHANT_INDEX")]
    public string? MerchantIndex { get; set; } 

    [XmlElement("CUST_DATA")]
    public string? CustomerData { get; set; }  
}