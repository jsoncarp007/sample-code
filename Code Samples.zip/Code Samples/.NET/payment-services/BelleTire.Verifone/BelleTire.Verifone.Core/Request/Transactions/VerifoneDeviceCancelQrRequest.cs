namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceCancelQrRequest : VerifoneDeviceTransactionRequest {}