﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceLoyaltyCaptureRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("TYPE")]
    public string? Type { get; set; } 
}