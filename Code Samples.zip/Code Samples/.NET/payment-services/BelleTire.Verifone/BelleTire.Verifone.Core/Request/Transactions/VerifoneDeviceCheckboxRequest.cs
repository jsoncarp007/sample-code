﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceCheckboxRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("DISPLAY_TEXT")]
    public string? DisplayText { get; set; }  

    [XmlElement("CHECKBOX_LABEL1")]
    public string? CheckboxLabel1 { get; set; }  

    [XmlElement("CHECKBOX_LABEL2")]
    public string? CheckboxLabel2 { get; set; } 

    [XmlElement("CHECKBOX_LABEL3")]
    public string? CheckboxLabel3 { get; set; }  

    [XmlElement("CHECKBOX_LABEL4")]
    public string? CheckboxLabel4 { get; set; } 

    [XmlElement("CHECKBOX_LABEL5")]
    public string? CheckboxLabel5 { get; set; } 

    [XmlElement("CHECKBOX_LABEL6")]
    public string? CheckboxLabel6 { get; set; } 
}