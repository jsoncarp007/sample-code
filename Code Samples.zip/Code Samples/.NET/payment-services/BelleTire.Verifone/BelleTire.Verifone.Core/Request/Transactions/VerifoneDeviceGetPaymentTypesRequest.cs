﻿namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceGetPaymentTypesRequest : VerifoneDeviceTransactionRequest {}