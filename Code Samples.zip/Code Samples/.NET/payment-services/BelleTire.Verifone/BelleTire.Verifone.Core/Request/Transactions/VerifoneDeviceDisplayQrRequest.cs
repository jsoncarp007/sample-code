﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceDisplayQrRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("QRCODE_DATA")]
    public string? QrcodeData { get; set; } 

    [XmlElement("DISPLAY_TEXT")]
    public string? DisplayText { get; set; }

    [XmlElement("BUTTON_LABEL")]
    public string? ButtonLabel { get; set; }
}