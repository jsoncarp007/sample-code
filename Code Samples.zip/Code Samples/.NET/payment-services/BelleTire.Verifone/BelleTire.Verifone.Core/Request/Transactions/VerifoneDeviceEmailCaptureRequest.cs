﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceEmailCaptureRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("EMAILDATA")]
    public string? EmailData { get; set; } 
}