﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceDisplayImageRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("IMAGE_DATA")]
    public string? ImageData { get; set; }

    [XmlElement("IMAGE_TIMEOUT")]
    public long? ImageTimeout { get; set; }

    [XmlElement("DISPLAY_BUTTONS")]
    public string? DisplayButtons { get; set; }

    [XmlElement("BUTTON_LABEL1")]
    public string? ButtonLabel1 { get; set; }

    [XmlElement("BUTTON_LABEL2")]
    public string? ButtonLabel2 { get; set; }

    [XmlElement("HIDE_CANCEL_BUTTON")]
    public string? HideCancelButton { get; set; }

    [XmlElement("RETURN_SCREEN")]
    public string? ReturnScreen { get; set; }
}