﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Transactions;

public class VerifoneDeviceSetDeviceNameRequest : VerifoneDeviceTransactionRequest
{
    [XmlElement("DEVICENAME")]
    public string? DeviceName { get; set; }
}