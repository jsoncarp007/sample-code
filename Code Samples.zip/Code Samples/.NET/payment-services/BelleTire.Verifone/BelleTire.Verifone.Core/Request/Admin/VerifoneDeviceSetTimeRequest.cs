﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Admin;

public class VerifoneDeviceSetTimeRequest : VerifoneDeviceRequest
{
    [XmlElement("TIME")]
    public string? Time { get; set; }
}