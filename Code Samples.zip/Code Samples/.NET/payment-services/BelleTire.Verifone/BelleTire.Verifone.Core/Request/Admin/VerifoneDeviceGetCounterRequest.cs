﻿namespace BelleTire.Verifone.Core.Request.Admin;

public class VerifoneDeviceGetCounterRequest : VerifoneDeviceRequest { }