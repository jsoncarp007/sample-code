﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Admin;

public class VerifoneDeviceApplyUpdatesRequest : VerifoneDeviceRequest
{
    [XmlElement("FLAG")]
    public string? Flag { get; set; }
}