﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Admin;

public class VerifoneDeviceStoreAndForwardRequest : VerifoneDeviceRequest
{
    [XmlElement("FORCE_SAF")]
    public string? ForceStoreAndForward { get; set; }         

    [XmlElement("SAF_FLOORLIMIT")]
    public decimal? StoreAndForwardFloorLimit { get; set; } 

    [XmlElement("SAF_TOTAL_LIMIT")]
    public decimal? StoreAndForwardTotalLimit { get; set; } 
}