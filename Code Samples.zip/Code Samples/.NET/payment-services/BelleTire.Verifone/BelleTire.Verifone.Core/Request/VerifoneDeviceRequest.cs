using System.Security.Cryptography;
using System.Text;
using System.Xml.Serialization;
using BelleTire.Verifone.Core.Request.Admin;
using BelleTire.Verifone.Core.Request.LineItem;
using BelleTire.Verifone.Core.Request.Payment;
using BelleTire.Verifone.Core.Request.Report;
using BelleTire.Verifone.Core.Request.SecondaryPort;
using BelleTire.Verifone.Core.Request.Security;
using BelleTire.Verifone.Core.Request.SessionManagement;
using BelleTire.Verifone.Core.Request.Settlement;
using BelleTire.Verifone.Core.Request.Token;
using BelleTire.Verifone.Core.Request.Transactions;

namespace BelleTire.Verifone.Core.Request;

// Admin
[XmlInclude(typeof(VerifoneDeviceGetCounterRequest))]
[XmlInclude(typeof(VerifoneDeviceApplyUpdatesRequest))]
[XmlInclude(typeof(VerifoneDeviceSetTimeRequest))]
[XmlInclude(typeof(VerifoneDeviceStoreAndForwardRequest))]

// Secondary Port
[XmlInclude(typeof(VerifoneDeviceCancelRequest))]
[XmlInclude(typeof(VerifoneDeviceRebootRequest))]
[XmlInclude(typeof(VerifoneDeviceSecondaryPortRequest))]
[XmlInclude(typeof(VerifoneDeviceStatusRequest))]
[XmlInclude(typeof(VerifoneDeviceUpdateQueryRequest))]
[XmlInclude(typeof(VerifoneDeviceUpdateStatusRequest))]

// Line Item
[XmlInclude(typeof(VerifoneDeviceAddLineItemRequest))]
[XmlInclude(typeof(VerifoneDeviceLineItems))]
[XmlInclude(typeof(VerifoneDeviceMerchandise))]
[XmlInclude(typeof(VerifoneDeviceOffer))]
[XmlInclude(typeof(VerifoneDeviceRemoveAllLineItemsRequest))]
[XmlInclude(typeof(VerifoneDeviceRemoveLineItemRequest))]
[XmlInclude(typeof(VerifoneDeviceShowLineItemsRequest))]

// Payment 
[XmlInclude(typeof(VerifoneDeviceAuthorizePaymentRequest))]
[XmlInclude(typeof(VerifoneDeviceCapturePaymentRequest))]
[XmlInclude(typeof(VerifoneDeviceCreditPaymentRequest))]
[XmlInclude(typeof(VerifoneDevicePaymentRequest))]
[XmlInclude(typeof(VerifoneDeviceVoidPaymentRequest))]

// Report
[XmlInclude(typeof(VerifoneDeviceDailySettlementSummaryReportRequest))]
[XmlInclude(typeof(VerifoneDeviceDuplicateCheckRequest))]
[XmlInclude(typeof(VerifoneDeviceDuplicateCheckRequest))]
[XmlInclude(typeof(VerifoneDevicePreSettlementReportRequest))]
[XmlInclude(typeof(VerifoneDevicePreSettlementReportResponseFields))]
[XmlInclude(typeof(VerifoneDeviceReportSearchFields))]
[XmlInclude(typeof(VerifoneDeviceSettlementErrorReportRequest))]
[XmlInclude(typeof(VerifoneDeviceTransactionSearchRequest))]

// Transactions
[XmlInclude(typeof(VerifoneDeviceCancelDisplayLeftPanelRequest))]
[XmlInclude(typeof(VerifoneDeviceCancelQrRequest))]
[XmlInclude(typeof(VerifoneDeviceCharityDonationRequest))]
[XmlInclude(typeof(VerifoneDeviceCheckboxRequest))]
[XmlInclude(typeof(VerifoneDeviceCustomerButtonRequest))]
[XmlInclude(typeof(VerifoneDeviceCustomerQuestionRequest))]
[XmlInclude(typeof(VerifoneDeviceCustomerSurvey10Request))]
[XmlInclude(typeof(VerifoneDeviceCustomerSurvey5Request))]
[XmlInclude(typeof(VerifoneDeviceCustomerSurveyRequest))]
[XmlInclude(typeof(VerifoneDeviceDisplayImageRequest))]
[XmlInclude(typeof(VerifoneDeviceDisplayLeftPanelRequest))]
[XmlInclude(typeof(VerifoneDeviceDisplayMessageRequest))]
[XmlInclude(typeof(VerifoneDeviceDisplayQrRequest))]
[XmlInclude(typeof(VerifoneDeviceEmailCaptureRequest))]
[XmlInclude(typeof(VerifoneDeviceExpandedSignatureRequest))]
[XmlInclude(typeof(VerifoneDeviceGetCardDataRequest))]
[XmlInclude(typeof(VerifoneDeviceGetDeviceNameRequest))]
[XmlInclude(typeof(VerifoneDeviceGetParametersRequest))]
[XmlInclude(typeof(VerifoneDeviceGetPaymentTypesRequest))]
[XmlInclude(typeof(VerifoneDeviceLaneClosedRequest))]
[XmlInclude(typeof(VerifoneDeviceLoyaltyCaptureRequest))]
[XmlInclude(typeof(VerifoneDeviceProvisionPassRequest))]
[XmlInclude(typeof(VerifoneDeviceQueryNfcIniRequest))]
[XmlInclude(typeof(VerifoneDeviceQuickCreditApplicationRequest))]
[XmlInclude(typeof(VerifoneDeviceRetrieveVersionRequest))]
[XmlInclude(typeof(VerifoneDeviceSetDeviceNameRequest))]
[XmlInclude(typeof(VerifoneDeviceSetParametersRequest))]
[XmlInclude(typeof(VerifoneDeviceSignatureRequest))]
[XmlInclude(typeof(VerifoneDeviceTokenQueryRequest))]
[XmlInclude(typeof(VerifoneDeviceTransactionRequest))]

// Token
[XmlInclude(typeof(VerifoneDeviceTokenRequest))]

// Settlement
[XmlInclude(typeof(VerifoneDeviceScheduleSettlementRequest))]

// Session Management
[XmlInclude(typeof(VerifoneDeviceFinishSessionRequest))]
[XmlInclude(typeof(VerifoneDeviceStartSessionRequest))]

// Security
[XmlInclude(typeof(VerifoneDeviceRegisterEncryptionRequest))]
[XmlInclude(typeof(VerifoneDeviceRegisterPosRequest))]
[XmlInclude(typeof(VerifoneDeviceSecurityRequest))]
[XmlInclude(typeof(VerifoneDeviceTestMacRequest))]
[XmlInclude(typeof(VerifoneDeviceUnregisterAllRequest))]
[XmlInclude(typeof(VerifoneDeviceUnregisterPosRequest))]

[XmlRoot("TRANSACTION")]
public class VerifoneDeviceRequest
{
    [XmlElement("FUNCTION_TYPE")]
    public string? FunctionType { get; set; }
    
    [XmlElement("COMMAND")]
    public string? Command { get; set; }
    
    [XmlElement("COUNTER")]
    public string? Counter { get; set; }
    
    [XmlElement("MAC")]
    public string? Mac { get; set; }
    
    [XmlElement("MAC_LABEL")]
    public string? MacLabel { get; set; }

    public void SetMac(string counter, string macKey, string macLabel)
    {
        Counter = counter;
        MacLabel = macLabel;
        
        var counterByteArray = Encoding.UTF8.GetBytes(Counter.ToString());

        var macKeyByteArray = Convert.FromBase64String(macKey);
        var hMacSha256 = new HMACSHA256(macKeyByteArray);

        var macByteArray = hMacSha256.ComputeHash(counterByteArray);
        
        Mac = Convert.ToBase64String(macByteArray);
    }

}

