﻿using BelleTire.Verifone.Core.Request.SecondaryPort;
using BelleTire.Verifone.Core.Request.Transactions;

namespace BelleTire.Verifone.Core.Request;

public class VerifoneDeviceQuestionRequestFactory
{
    private readonly VerifoneDeviceRequestFactory _deviceRequestFactory;
    public VerifoneDeviceQuestionRequestFactory(VerifoneDeviceRequestFactory deviceRequestFactory)
    {
        _deviceRequestFactory = deviceRequestFactory;
    }
    
    public VerifoneDeviceCustomerQuestionRequest GetQuestionDisplayRequest(string disclosureText, string leftButtonText, string rightButtonText)
    {
        var request = _deviceRequestFactory.GetRequestForCommand<VerifoneDeviceCustomerQuestionRequest>(DeviceCommand.CustomerQuestion);

        request.ButtonTextLeft = leftButtonText;
        request.ButtonInnerTextLeft = leftButtonText;
        
        request.ButtonTextRight = rightButtonText;
        request.ButtonInnerTextRight = rightButtonText;
        
        request.DisplayBulkData = disclosureText;
        request.ReturnScreen = "STAY_CURRENT";
        request.PosRecon = "1234";

        return request;
    }

    public VerifoneDeviceDisplayMessageRequest GetClearScreenRequest()
    {
        var request = _deviceRequestFactory.GetRequestForCommand<VerifoneDeviceDisplayMessageRequest>(DeviceCommand.DisplayMessage);
        request.DisplayText = "Please wait...";
        request.FullScreen = "TRUE";
        request.TimeoutData = 1;
        request.PosRecon = string.Empty;
        return request;
    }
}