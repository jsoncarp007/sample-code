﻿namespace BelleTire.Verifone.Core.Request.SessionManagement;

public class VerifoneDeviceFinishSessionRequest : VerifoneDeviceRequest { }