﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.SessionManagement;

public class VerifoneDeviceStartSessionRequest : VerifoneDeviceRequest
{
    [XmlElement("INVOICE")]
    public string? Invoice { get; set; } 

    [XmlElement("STORE_NUM")]
    public string? StoreNumber { get; set; } 

    [XmlElement("LANE")]
    public int? Lane { get; set; } 

    [XmlElement("CASHIER_ID")]
    public string? CashierId { get; set; } 

    [XmlElement("SERVER_ID")]
    public int? ServerId { get; set; } 

    [XmlElement("SHIFT_ID")]
    public string? ShiftId { get; set; } 

    [XmlElement("TABLE_NUM")]
    public int? TableNumber { get; set; } 

    [XmlElement("POS_IP")]
    public string? PosIp { get; set; } 

    [XmlElement("POS_PORT")]
    public int? PosPort { get; set; } 

    [XmlElement("BUSINESSDATE")]
    public string? BusinessDate { get; set; } 

    [XmlElement("SWIPE_AHEAD")]
    public int? SwipeAhead { get; set; } 

    [XmlElement("PRESWIPE_EARLYRETURN")]
    public string? PreswipeEarlyreturn { get; set; }          

    [XmlElement("NOTIFY_SCA_EVENTS")]
    public string? NotifyScaEvents { get; set; }          

    [XmlElement("PURCHASE_ID")]
    public string? PurchaseId { get; set; }    

    [XmlElement("SCREEN_CHANGE")]
    public string? ScreenChange { get; set; }                   

    [XmlElement("TRAINING_MODE")]
    public string? TrainingMode { get; set; }    

    [XmlElement("MERCHANT_INDEX")]
    public string? MerchantIndex { get; set; }    

    [XmlElement("NFCVAS_MODE")]
    public string? NfcVasMode { get; set; }    
}