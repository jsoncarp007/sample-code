﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Token;

public class VerifoneDeviceTokenRequest : VerifoneDeviceRequest
{
    [XmlElement("MANUAL_ENTRY")]
    public string? ManualEntry { get; set; }

    [XmlElement("PAYMENT_TYPE")]
    public string? PaymentType { get; set; }

    [XmlElement("ACCT_NUM")]
    public string? AcctNum { get; set; }

    [XmlElement("CARD_EXP_MONTH")]
    public int? CardExpMonth { get; set; }

    [XmlElement("CARD_EXP_YEAR")]
    public int? CardExpYear { get; set; }

    [XmlElement("MANUAL_PROMPT_OPTIONS")]
    public string? ManualPromptOptions { get; set; }

}