namespace BelleTire.Verifone.Core.Request.Payment;

public class VerifoneDeviceCapturePaymentRequest : VerifoneDevicePaymentRequest {}