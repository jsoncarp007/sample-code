namespace BelleTire.Verifone.Core.Request.Payment;

public class VerifoneDeviceVoidPaymentRequest : VerifoneDevicePaymentRequest {}