namespace BelleTire.Verifone.Core.Request.Payment;

public class VerifoneDeviceCreditPaymentRequest : VerifoneDevicePaymentRequest {}