namespace BelleTire.Verifone.Core.Request.Payment;

public class VerifoneDeviceAuthorizePaymentRequest : VerifoneDevicePaymentRequest {}