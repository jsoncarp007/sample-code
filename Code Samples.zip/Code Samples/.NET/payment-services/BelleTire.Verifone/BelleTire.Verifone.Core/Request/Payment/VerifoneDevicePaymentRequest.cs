﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Payment;

public class VerifoneDevicePaymentRequest : VerifoneDeviceRequest
{
    [XmlElement("TRANS_AMOUNT")]
    public decimal? TransactionAmount { get; set; } 
    
    [XmlElement("EBTSNAP_ELIGIBLE_")]
    public string? EbtSnapEligible { get; set; } 

    [XmlElement("PAYMENT_TYPE")]
    public string? PaymentType { get; set; }  

    [XmlElement("PAYMENT_SUBTYPE")]
    public string? PaymentSubtype { get; set; }  

    [XmlElement("AUTH_CODE")]
    public string? AuthorizationCode { get; set; } 

    [XmlElement("MANUAL_ENTRY")]
    public string? ManualEntry { get; set; }  

    [XmlElement("CUSTOMER_STREET")]
    public string? CustomerStreet { get; set; }  

    [XmlElement("CUSTOMER_ZIP")]
    public string? CustomerZip { get; set; }  

    [XmlElement("MANUAL_PROMPT_OPTIONS")]
    public string? ManualPromptOptions { get; set; }  
 
    [XmlElement("SIGNATURE_CAPTURE")]
    public string? SignatureCapture { get; set; }

    [XmlElement("REF_TROUTD")]
    public string? RefTroutd { get; set; }

    [XmlElement("BILLPAY")] 
    public string? BillPay { get; set; }
    
    [XmlElement("CTROUTD")]
    public string? CTroutd { get; set; }
    
    [XmlElement("ORIG_ACCT_NUM")]
    public string? OriginalAccountNumber { get; set; }  

    [XmlElement("FORCE_FLAG")]
    public string? ForceFlag { get; set; }

    [XmlElement("CAPTURECARD_EARLYRETURN")]
    public string? CaptureCardEarlyReturn { get; set; }

    [XmlElement("POS_RECON")]
    public string? PosRecon { get; set; }  
    
    [XmlElement("TAX_AMOUNT")]
    public decimal? TaxAmount { get; set; }  

    [XmlElement("TAX_IND")]
    public string? TaxIndicator { get; set; }  

    [XmlElement("CMRCL_FLAG")]
    public string? CommercialFlag { get; set; }

    [XmlElement("ACCT_NUM")]
    public string? AccountNumber { get; set; }  

    [XmlElement("CARD_EXP_MONTH")]
    public int? CardExpirationMonth { get; set; } 

    [XmlElement("CARD_EXP_YEAR")]
    public int? CardExpirationYear { get; set; }

    [XmlElement("ENCRYPT")]
    public string? Encrypt { get; set; }

    [XmlElement("BARCODE")]
    public string? Barcode { get; set; }  

    [XmlElement("PIN_CODE")]
    public string? PinCode { get; set; }  

    [XmlElement("CVV2")]
    public string? Cvv2 { get; set; }

    [XmlElement("CREDIT_PLAN_NBR")]
    public int? CreditPlanNumber { get; set; }  

    [XmlElement("PURCHASE_APR")]
    public string? PurchaseApr { get; set; }  

    [XmlElement("APR_TYPE")]
    public string? AprType { get; set; }  

    [XmlElement("PROMO_CODE")]
    public string? PromotionCode { get; set; }

    [XmlElement("ORDER_DATETIME")]
    public string? OrderDate { get; set; }  // format "MM/dd/yyyy HH:mm:ss"

    [XmlElement("REFERENCE")]
    public string? Reference { get; set; }

    [XmlElement("CARD_TOKEN")]
    public string? CardToken { get; set; }

    [XmlElement("BANK_USERDATA")]
    public string? BankUserData { get; set; }

    [XmlElement("ALLOW_DUP_TRAN")]
    public string? AllowDuplicateTransaction { get; set; }  //Conditional, Type C, 1 / 10
 
    [XmlElement("NFCVAS_MODE")]
    public string? NfcVasMode { get; set; }  

    [XmlElement("MERCHANT_INDEX")]
    public string? MerchantIndex { get; set; }  
}