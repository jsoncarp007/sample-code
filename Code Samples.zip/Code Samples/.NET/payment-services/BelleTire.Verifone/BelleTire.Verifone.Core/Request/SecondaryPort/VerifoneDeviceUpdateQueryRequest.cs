namespace BelleTire.Verifone.Core.Request.SecondaryPort;

public class VerifoneDeviceUpdateQueryRequest : VerifoneDeviceSecondaryPortRequest {}