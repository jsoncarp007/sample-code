namespace BelleTire.Verifone.Core.Request.SecondaryPort;

public class VerifoneDeviceStatusRequest : VerifoneDeviceSecondaryPortRequest {}