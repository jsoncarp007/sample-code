﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.SecondaryPort;

public class VerifoneDeviceSecondaryPortRequest : VerifoneDeviceRequest
{
    [XmlElement("POS_RECON")]
    public string? PosRecon { get; set; }  
}