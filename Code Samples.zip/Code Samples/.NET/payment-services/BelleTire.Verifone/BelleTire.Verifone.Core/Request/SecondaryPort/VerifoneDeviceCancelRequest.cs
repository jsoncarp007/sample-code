namespace BelleTire.Verifone.Core.Request.SecondaryPort;

public class VerifoneDeviceCancelRequest : VerifoneDeviceSecondaryPortRequest {}