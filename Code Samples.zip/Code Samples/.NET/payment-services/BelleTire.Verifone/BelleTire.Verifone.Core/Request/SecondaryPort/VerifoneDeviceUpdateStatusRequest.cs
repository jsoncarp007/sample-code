namespace BelleTire.Verifone.Core.Request.SecondaryPort;

public class VerifoneDeviceUpdateStatusRequest : VerifoneDeviceSecondaryPortRequest {}