namespace BelleTire.Verifone.Core.Request.SecondaryPort;

public class VerifoneDeviceRebootRequest : VerifoneDeviceSecondaryPortRequest {}