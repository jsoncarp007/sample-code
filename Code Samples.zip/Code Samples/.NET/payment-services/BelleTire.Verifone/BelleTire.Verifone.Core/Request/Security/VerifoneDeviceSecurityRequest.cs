﻿namespace BelleTire.Verifone.Core.Request.Security;

public class VerifoneDeviceSecurityRequest : VerifoneDeviceRequest {}