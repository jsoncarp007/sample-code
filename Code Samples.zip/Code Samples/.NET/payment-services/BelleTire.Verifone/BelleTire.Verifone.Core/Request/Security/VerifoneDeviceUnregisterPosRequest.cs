namespace BelleTire.Verifone.Core.Request.Security;

public class VerifoneDeviceUnregisterPosRequest : VerifoneDeviceRequest {}