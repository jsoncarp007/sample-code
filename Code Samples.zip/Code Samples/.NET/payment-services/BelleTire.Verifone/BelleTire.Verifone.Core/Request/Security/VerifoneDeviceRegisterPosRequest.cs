﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Security;

public class VerifoneDeviceRegisterPosRequest : VerifoneDeviceRequest
{
    [XmlElement("ENTRY_CODE")]
    public string? EntryCode { get; set; }  

    [XmlElement("KEY")]
    public string? Key { get; set; }  

    [XmlElement("REG_VER")]
    public string? RegisterVersion { get; set; }  
}