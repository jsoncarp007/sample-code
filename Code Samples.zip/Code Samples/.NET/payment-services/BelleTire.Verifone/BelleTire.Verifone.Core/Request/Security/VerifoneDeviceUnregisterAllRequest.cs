namespace BelleTire.Verifone.Core.Request.Security;

public class VerifoneDeviceUnregisterAllRequest : VerifoneDeviceRequest {}