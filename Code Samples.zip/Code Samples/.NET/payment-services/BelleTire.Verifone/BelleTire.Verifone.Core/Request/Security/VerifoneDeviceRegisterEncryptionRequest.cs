﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Request.Security;

public class VerifoneDeviceRegisterEncryptionRequest : VerifoneDeviceRequest
{
    [XmlElement("KEY")]
    public string? Key { get; set; }  
}