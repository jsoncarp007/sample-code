using BelleTire.Verifone.Core.Request.Transactions;

namespace BelleTire.Verifone.Core.Request;

public class VerifoneDeviceSignatureRequestFactory
{
    private readonly VerifoneDeviceRequestFactory _deviceRequestFactory;
    public VerifoneDeviceSignatureRequestFactory(VerifoneDeviceRequestFactory deviceRequestFactory)
    {
        _deviceRequestFactory = deviceRequestFactory;
    }

    public VerifoneDeviceSignatureRequest GetSignatureRequest(string promptText)
    {
        var request =
            _deviceRequestFactory.GetRequestForCommand<VerifoneDeviceSignatureRequest>(DeviceCommand.Signature);

        request.DisplayText = promptText;
        request.PosRecon = string.Empty;

        return request;
    }
}