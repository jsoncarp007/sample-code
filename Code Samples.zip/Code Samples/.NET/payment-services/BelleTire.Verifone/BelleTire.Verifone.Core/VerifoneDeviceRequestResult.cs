using BelleTire.Verifone.Core.Response;

namespace BelleTire.Verifone.Core;

public class VerifoneDeviceRequestResult
{
    public bool Success { get; set; } = false;
    public string? XmlResponse { get; set; } = string.Empty;
    public dynamic? DeviceResponse { get; set; }
    public string? ErrorDetail { get; set; } = string.Empty;
}