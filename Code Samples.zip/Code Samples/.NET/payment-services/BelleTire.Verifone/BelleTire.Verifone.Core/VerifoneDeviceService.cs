﻿using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;
using BelleTire.Verifone.Core.Request;
using BelleTire.Verifone.Core.Request.Transactions;
using BelleTire.Verifone.Core.Response;

namespace BelleTire.Verifone.Core;

public class VerifoneDeviceService : IVerifoneDeviceService
{
    private readonly string _mac;
    private readonly string _macLabel;
    private VerifoneDeviceClient _client;
    private VerifoneDeviceClient _secondaryPortClient;
    private VerifoneDeviceRequestFactory _requestFactory;
    private VerifoneDeviceResponseFactory _responseFactory;

    public VerifoneDeviceService(string ipAddress, int port, string mac, string macLabel)
    {
        _mac = mac;
        _macLabel = macLabel;
        _client = new VerifoneDeviceClient(ipAddress, port);
        _secondaryPortClient = new VerifoneDeviceClient(ipAddress, 5016);
        
        var deviceCommandMatrix = new DeviceCommandMatrix();
        _requestFactory = new VerifoneDeviceRequestFactory(deviceCommandMatrix);
        _responseFactory = new VerifoneDeviceResponseFactory();
    }

    public async Task<VerifoneDeviceRequestResult> ExecuteSecondaryPortRequestAsync(VerifoneDeviceRequest request)
    {
        return await ExecuteRequestOnClientAsync(request, _secondaryPortClient, false).ConfigureAwait(false);
    }

    public async Task<VerifoneDeviceRequestResult> ExecuteRequestAsync(VerifoneDeviceRequest request)
    {
        return await ExecuteRequestOnClientAsync(request, _client).ConfigureAwait(false);
    }

    private async Task<VerifoneDeviceRequestResult> ExecuteRequestOnClientAsync(VerifoneDeviceRequest request, VerifoneDeviceClient client, bool setCounter = true) 
    {
        if (setCounter)
        {
            var setCounterResult = SetRequestCounterAndMac(request);
            if (!setCounterResult) 
                return new VerifoneDeviceRequestResult() {Success = false, ErrorDetail = "Card reader not responding"};
        }
        var serializedRequest = GetSerializedRequest(request);
        var resultString = await client.SendRequestAsync(serializedRequest).ConfigureAwait(false);
        
        return string.IsNullOrEmpty(resultString) 
            ? new VerifoneDeviceRequestResult() {Success = false} 
            : new VerifoneDeviceRequestResult() {Success = true, DeviceResponse = GetDeserializedResponse(resultString, _responseFactory.GetResponseTypeForRequest(request))};
    }

    private bool SetRequestCounterAndMac(VerifoneDeviceRequest request)
    {
        request.MacLabel = _macLabel;
        request.Mac = _mac;

        var counter = GetCounterFromDevice(request.MacLabel).ConfigureAwait(false).GetAwaiter().GetResult();
        if (counter == -1)
            return false;
        
        counter++;
        request.SetMac(counter.ToString(), request.Mac, request.MacLabel);
        request.Counter = counter.ToString();

        return true;
    }

    public async Task ResetDeviceConnection()
    {
        await Task.Run(() =>
        {
            _client.Disconnect();
            _secondaryPortClient.Disconnect();
        });
    }

    private async Task<long> GetCounterFromDevice(string macLabel)
    {
        var counterRequest = _requestFactory.GetRequestForCommand(DeviceCommand.GetCounter);
        counterRequest.MacLabel = macLabel;
        var serializedRequest = GetSerializedRequest(counterRequest);
        var resultString = await _client.SendRequestAsync(serializedRequest).ConfigureAwait(false);
        return GetDeserializedResponse(resultString)?.Counter ?? -1;
    }
    
    private VerifoneDeviceResponse GetDeserializedResponse(string responseXml, Type? responseObjectType = null)
    {
        responseObjectType ??= typeof(VerifoneDeviceResponse);
        var serializer = new XmlSerializer(responseObjectType);
        var stringReader = new StringReader(responseXml);
        var textReader = new XmlTextReader(stringReader);
        dynamic deserializedObject = serializer.Deserialize(textReader);

        return Convert.ChangeType(deserializedObject, responseObjectType);
    }

    private string GetSerializedRequest(VerifoneDeviceRequest request)
    {
        var serializer = new XmlSerializer(typeof(VerifoneDeviceRequest));
        var stringWriter = new StringWriter();
        serializer.Serialize(stringWriter, request);
        return CleanXmlString(stringWriter.ToString());
    }

    private string CleanXmlString(string xmlString)
    {
        xmlString = Regex.Replace(xmlString, @" xmlns:.*?"".*?""", "");
        xmlString = Regex.Replace(xmlString, @" xsi:.*?"".*?""", "");
        xmlString = xmlString.Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>", string.Empty);
        return xmlString;
    }
}