using BelleTire.Verifone.Core.Request;

namespace BelleTire.Verifone.Core;

public interface IVerifoneDeviceService
{
    Task<VerifoneDeviceRequestResult> ExecuteSecondaryPortRequestAsync(VerifoneDeviceRequest request);
    Task<VerifoneDeviceRequestResult> ExecuteRequestAsync(VerifoneDeviceRequest request);
    Task ResetDeviceConnection();
}