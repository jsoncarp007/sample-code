﻿using BelleTire.Verifone.Core.Request;
using BelleTire.Verifone.Core.Request.SecondaryPort;
using BelleTire.Verifone.Core.Request.Transactions;
using BelleTire.Verifone.Core.Response.Transactions;

namespace BelleTire.Verifone.Core;

public class VerifoneCardReader
{
    public CardScan? CardScanned;
    public delegate void CardScan(CardData cardData);

    public DeviceError? DeviceErrorOccurred;
    public delegate void DeviceError(string errorMessage);

    private bool _isAwaitingScan = false;
    
    private readonly IVerifoneDeviceService _verifoneDeviceService;
    private readonly VerifoneDeviceRequestFactory _requestFactory;

    public VerifoneCardReader(IVerifoneDeviceService verifoneDeviceService, VerifoneDeviceRequestFactory requestFactory)
    {
        _verifoneDeviceService = verifoneDeviceService;
        _requestFactory = requestFactory;
    }

    public void StartCardScan()
    {
        Task.Run(async () => await RequestCardData());
    }

    public void CancelCurrentRequest()
    {
        var cancelRequest = _requestFactory.GetRequestForCommand<VerifoneDeviceCancelRequest>(DeviceCommand.Cancel);
        Task.Run(async () => await _verifoneDeviceService.ExecuteSecondaryPortRequestAsync(cancelRequest));
        _isAwaitingScan = false;
    }

    private async Task RequestCardData()
    {
        _isAwaitingScan = true;

        var getCardDataRequest = (VerifoneDeviceGetCardDataRequest) _requestFactory.GetRequestForCommand(DeviceCommand.GetCardData);
        getCardDataRequest.CardInputMethod = "SWIPE";
        getCardDataRequest.DisplayText1 = "Swipe Goodyear Credit Card...";

        var result = await _verifoneDeviceService.ExecuteRequestAsync(getCardDataRequest);
        var response = (VerifoneDeviceGetCardDataResponse) result.DeviceResponse!;

        var cardData = new CardData()
        {
            AccountNumber = response?.AccountNumber,
            ExpirationMonth = response?.CardExpirationMonth,
            ExpirationYear = response?.CardExpirationYear,
            DataTrack1 = response?.CardTrack1,
            DataTrack2 = response?.CardTrack2,
            DataTrack3 = response?.CardTrack3
        };
        
        CardScanned?.Invoke(cardData);

        _isAwaitingScan = false;
    }
}