﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceDisplayMessageResponse : VerifoneDeviceTransactionResponse
{
    [XmlElement("TIMEOUT_RESULT")]
    public string? TimeoutResult { get; set; }
}