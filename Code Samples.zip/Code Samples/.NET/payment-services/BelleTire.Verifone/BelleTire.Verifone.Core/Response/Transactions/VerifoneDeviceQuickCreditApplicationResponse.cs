﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceQuickCreditApplicationResponse : VerifoneDeviceTransactionResponse
{
    [XmlElement("PROMPT1")]
    public string? Prompt1 { get; set; }  

    [XmlElement("PROMPT1_DATA")]
    public string? Prompt1Data { get; set; }  

    [XmlElement("PROMPT2")]
    public string? Prompt2 { get; set; }

    [XmlElement("PROMPT2_DATA")]
    public string? Prompt2Data { get; set; }

    [XmlElement("PROMPT3")]
    public string? Prompt3 { get; set; }

    [XmlElement("PROMPT3_DATA")]
    public string? Prompt3Data { get; set; }

    [XmlElement("PROMPT4")]
    public string? Prompt4 { get; set; }

    [XmlElement("PROMPT4_DATA")]
    public string? Prompt4Data { get; set; }

    [XmlElement("PROMPT5")]
    public string? Prompt5 { get; set; }

    [XmlElement("PROMPT5_DATA")]
    public string? Prompt5Data { get; set; }

    [XmlElement("PROMPT6")]
    public string? Prompt6 { get; set; }

    [XmlElement("PROMPT6_DATA")]
    public string? Prompt6Data { get; set; }

    [XmlElement("PROMPT7")]
    public string? Prompt7 { get; set; }

    [XmlElement("PROMPT7_DATA")]
    public string? Prompt7Data { get; set; }

    [XmlElement("PROMPT8")]
    public string? Prompt8 { get; set; }

    [XmlElement("PROMPT8_DATA")]
    public string? Prompt8Data { get; set; }

    [XmlElement("PROMPT9")]
    public string? Prompt9 { get; set; }

    [XmlElement("PROMPT9_DATA")]
    public string? Prompt9Data { get; set; }

    [XmlElement("PROMPT10")]
    public string? Prompt10 { get; set; }

    [XmlElement("PROMPT10_DATA")]
    public string? Prompt10Data { get; set; }
}