﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceSignatureResponse : VerifoneDeviceTransactionResponse
{
    [XmlElement("SIGNATUREDATA")]
    public string? SignatureData { get; set; } 

    [XmlElement("MIME_TYPE")]
    public string? MimeType { get; set; } 
}