﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceCharityDonationResponse : VerifoneDeviceTransactionResponse
{
    [XmlElement("AMOUNT_DATA")]
    public string? AmountData { get; set; }  
}