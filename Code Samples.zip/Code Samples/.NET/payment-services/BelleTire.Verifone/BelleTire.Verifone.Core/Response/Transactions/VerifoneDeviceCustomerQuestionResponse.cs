﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceCustomerQuestionResponse : VerifoneDeviceTransactionResponse
{
    [XmlElement("CUST_QUESTION_DATA")]
    public string? CustomerQuestionData { get; set; }
}