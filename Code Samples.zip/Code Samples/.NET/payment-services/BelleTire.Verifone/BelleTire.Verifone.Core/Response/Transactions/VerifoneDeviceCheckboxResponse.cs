﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceCheckboxResponse : VerifoneDeviceTransactionResponse
{
    [XmlElement("CHECKBOX_1")]
    public string? Checkbox1 { get; set; }  

    [XmlElement("CHECKBOX_2")]
    public string? Checkbox2 { get; set; }  

    [XmlElement("CHECKBOX_3")]
    public string? Checkbox3 { get; set; }  

    [XmlElement("CHECKBOX_4")]
    public string? Checkbox4 { get; set; }  

    [XmlElement("CHECKBOX_5")]
    public string? Checkbox5 { get; set; }  

    [XmlElement("CHECKBOX_6")]
    public string? Checkbox6 { get; set; }
}