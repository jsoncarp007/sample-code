﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("APPLEPAY")]
public class VerifoneDeviceApplyPayResponseData
{
    [XmlElement("NUM_MERCH_IDS")]
    public int? NumberOfMerchantIds { get; set; }
}