﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceGetCardDataResponse : VerifoneDeviceTransactionResponse
{
    [XmlElement("CARD_TRACK1")]
    public string? CardTrack1 { get; set; } 

    [XmlElement("CARD_TRACK2")]
    public string? CardTrack2 { get; set; } 

    [XmlElement("CARD_TRACK3")]
    public string? CardTrack3 { get; set; } 

    [XmlElement("ACCT_NUM")]
    public string? AccountNumber { get; set; } 

    [XmlElement("CARD_EXP_MONTH")]
    public int? CardExpirationMonth { get; set; }

    [XmlElement("CARD_EXP_YEAR")]
    public int? CardExpirationYear { get; set; }

    [XmlElement("CARD_ENTRY_MODE")]
    public string? CardEntryMode { get; set; }
}