﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceGetParametersResponse : VerifoneDeviceTransactionResponse
{
    [XmlElement("PARAM")]
    public string? Parameter { get; set; }  
}