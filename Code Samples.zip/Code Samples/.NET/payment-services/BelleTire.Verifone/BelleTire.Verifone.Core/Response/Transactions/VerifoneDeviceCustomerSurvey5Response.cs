﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceCustomerSurvey5Response : VerifoneDeviceTransactionResponse
{
    [XmlElement("SURVEY5_DATA")]
    public string? SurveyData { get; set; }
}