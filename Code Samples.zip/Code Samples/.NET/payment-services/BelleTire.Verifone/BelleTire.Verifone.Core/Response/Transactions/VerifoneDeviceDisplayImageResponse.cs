﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceDisplayImageResponse : VerifoneDeviceTransactionResponse
{
    [XmlElement("CUST_BUTTON_DATA")]
    public string? CustomerButtonData { get; set; }
}