﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceEmailCaptureResponse : VerifoneDeviceTransactionResponse
{
    [XmlElement("EMAILDATA")]
    public string? EmailData { get; set; }
}