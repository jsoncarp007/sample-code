﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceCustomerSurveyResponse : VerifoneDeviceTransactionResponse
{
    [XmlElement("SURVEY_DATA")]
    public string? SurveyData { get; set; }
}