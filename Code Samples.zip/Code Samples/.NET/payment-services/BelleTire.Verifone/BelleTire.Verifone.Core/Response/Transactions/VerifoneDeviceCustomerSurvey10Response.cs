﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceCustomerSurvey10Response : VerifoneDeviceTransactionResponse
{
    [XmlElement("SURVEY10_DATA")]
    public string? SurveyData { get; set; } 
}