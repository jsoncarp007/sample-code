﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceRetrieveVersionResponse : VerifoneDeviceTransactionResponse
{
    [XmlElement("VERSION_INFO")]
    public string? VersionInfo { get; set; }
}