﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceDisplayLeftPanelResponse : VerifoneDeviceTransactionResponse
{
    [XmlElement("CUST_BUTTON_DATA")]
    public string? CustomerButtonData { get; set; }

    [XmlElement("CUST_NUMERIC_DATA")]
    public string? CustomerNumericData { get; set; }
}