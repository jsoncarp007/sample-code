﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceLoyaltyCaptureResponse : VerifoneDeviceTransactionResponse
{
    [XmlElement("LOYALTY_DATA")]
    public string? LoyaltyData { get; set; }

    [XmlElement("LOYALTY_VAS")]
    public string? LoyaltyVas { get; set; } 
}