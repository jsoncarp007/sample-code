﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Transactions;

[XmlRoot("RESPONSE")]
public abstract class VerifoneDeviceTransactionResponse : VerifoneDeviceResponse
{
    [XmlElement("POS_RECON")]
    public string? PosRecon { get; set; } 
}