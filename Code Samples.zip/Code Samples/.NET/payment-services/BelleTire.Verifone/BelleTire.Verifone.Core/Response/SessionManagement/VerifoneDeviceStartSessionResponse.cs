﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.SessionManagement;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceStartSessionResponse : VerifoneDeviceSessionManagementResponse {}