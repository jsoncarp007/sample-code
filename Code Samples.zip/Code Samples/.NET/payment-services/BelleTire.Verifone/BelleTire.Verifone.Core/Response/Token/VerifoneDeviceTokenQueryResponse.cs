﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Token;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceTokenQueryResponse : VerifoneDeviceResponse
{
    [XmlElement("TRANS_SEQ_NUM")]
    public int? TransactionSequenceNumber { get; set; }  

    [XmlElement("INTRN_SEQ_NUM")]
    public int? InternalSequenceNumber { get; set; }  

    [XmlElement("TROUTD")]
    public long? Troutd { get; set; }

    [XmlElement("CTROUTD")]
    public long? CTroutd { get; set; }
 
    [XmlElement("CARD_TOKEN")]
    public string? CardToken { get; set; } 

    [XmlElement("ACCT_NUM")]
    public string? AcctNum { get; set; }

    [XmlElement("CARDHOLDER")]
    public string? Cardholder { get; set; }

    [XmlElement("CARD_EXP_MONTH")]
    public int? CardExpirationMonth { get; set; }

    [XmlElement("CARD_EXP_YEAR")]
    public int? CardExpirationYear { get; set; }

    [XmlElement("CUSTOMER_ZIP")]
    public string? CustomerZip { get; set; }

    [XmlElement("BANK_USERDATA")]
    public string? BankUserData { get; set; }

    [XmlElement("CARD_ENTRY_MODE")]
    public string? CardEntryMode { get; set; }

    [XmlElement("PRESWIPED")]
    public int? PreSwiped { get; set; } 

    [XmlElement("EMV_TAG_4F")]
    public string? EmvTag4F { get; set; }

    [XmlElement("EMV_TAG_50")]
    public string? EmvTag50 { get; set; }

    [XmlElement("EMV_TAG_5F34")]
    public string? EmvTag5F34 { get; set; }

    [XmlElement("EMV_TAG_9F12")]
    public string? EmvTag9F12 { get; set; } 

    [XmlElement("EMV_CHIP_INDICATOR")]
    public string? EmvChipIndicator { get; set; } 
}