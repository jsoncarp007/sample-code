﻿using System.Xml.Serialization;
using BelleTire.Verifone.Core.Request.LineItem;
using BelleTire.Verifone.Core.Request.Report;
using BelleTire.Verifone.Core.Response.Admin;
using BelleTire.Verifone.Core.Response.LineItem;
using BelleTire.Verifone.Core.Response.Payment;
using BelleTire.Verifone.Core.Response.Reports;
using BelleTire.Verifone.Core.Response.SecondaryPort;
using BelleTire.Verifone.Core.Response.Security;
using BelleTire.Verifone.Core.Response.SessionManagement;
using BelleTire.Verifone.Core.Response.Settlement;
using BelleTire.Verifone.Core.Response.Token;
using BelleTire.Verifone.Core.Response.Transactions;

namespace BelleTire.Verifone.Core.Response;

// Admin
[XmlInclude(typeof(VerifoneDeviceGetCounterResponse))]
[XmlInclude(typeof(VerifoneDeviceApplyUpdatesResponse))]
[XmlInclude(typeof(VerifoneDeviceSetTimeResponse))]
[XmlInclude(typeof(VerifoneDeviceStoreAndForwardResponse))]

// Secondary Port
[XmlInclude(typeof(VerifoneDeviceCancelResponse))]
[XmlInclude(typeof(VerifoneDeviceRebootResponse))]
[XmlInclude(typeof(VerifoneDeviceSecondaryPortResponse))]
[XmlInclude(typeof(VerifoneDeviceStatusResponse))]
[XmlInclude(typeof(VerifoneDeviceUpdateQueryResponse))]
[XmlInclude(typeof(VerifoneDeviceUpdateStatusResponse))]

// Line Item
[XmlInclude(typeof(VerifoneDeviceAddLineItemResponse))]
[XmlInclude(typeof(VerifoneDeviceLineItems))]
[XmlInclude(typeof(VerifoneDeviceMerchandise))]
[XmlInclude(typeof(VerifoneDeviceOffer))]
[XmlInclude(typeof(VerifoneDeviceRemoveAllLineItemsResponse))]
[XmlInclude(typeof(VerifoneDeviceRemoveLineItemResponse))]
[XmlInclude(typeof(VerifoneDeviceShowLineItemsResponse))]

// Payment 
[XmlInclude(typeof(VerifoneDeviceAuthorizePaymentResponse))]
[XmlInclude(typeof(VerifoneDeviceCapturePaymentResponse))]
[XmlInclude(typeof(VerifoneDeviceCreditPaymentResponse))]
[XmlInclude(typeof(VerifoneDeviceVoidPaymentResponse))]

// Report
[XmlInclude(typeof(VerifoneDeviceDailySettlementSummaryReportResponse))]
[XmlInclude(typeof(VerifoneDeviceDuplicateCheckResponse))]
[XmlInclude(typeof(VerifoneDeviceDuplicateCheckResponse))]
[XmlInclude(typeof(VerifoneDevicePreSettlementReportResponse))]
[XmlInclude(typeof(VerifoneDevicePreSettlementReportResponseFields))]
[XmlInclude(typeof(VerifoneDeviceReportSearchFields))]
[XmlInclude(typeof(VerifoneDeviceSettlementErrorReportResponse))]
[XmlInclude(typeof(VerifoneDeviceTransactionSearchResponse))]

// Transactions
[XmlInclude(typeof(VerifoneDeviceCancelDisplayLeftPanelResponse))]
[XmlInclude(typeof(VerifoneDeviceCancelQrResponse))]
[XmlInclude(typeof(VerifoneDeviceCharityDonationResponse))]
[XmlInclude(typeof(VerifoneDeviceCheckboxResponse))]
[XmlInclude(typeof(VerifoneDeviceCustomerButtonResponse))]
[XmlInclude(typeof(VerifoneDeviceCustomerQuestionResponse))]
[XmlInclude(typeof(VerifoneDeviceCustomerSurvey10Response))]
[XmlInclude(typeof(VerifoneDeviceCustomerSurvey5Response))]
[XmlInclude(typeof(VerifoneDeviceCustomerSurveyResponse))]
[XmlInclude(typeof(VerifoneDeviceDisplayImageResponse))]
[XmlInclude(typeof(VerifoneDeviceDisplayLeftPanelResponse))]
[XmlInclude(typeof(VerifoneDeviceDisplayMessageResponse))]
[XmlInclude(typeof(VerifoneDeviceDisplayQrResponse))]
[XmlInclude(typeof(VerifoneDeviceEmailCaptureResponse))]
[XmlInclude(typeof(VerifoneDeviceExpandedSignatureResponse))]
[XmlInclude(typeof(VerifoneDeviceGetCardDataResponse))]
[XmlInclude(typeof(VerifoneDeviceGetDeviceNameResponse))]
[XmlInclude(typeof(VerifoneDeviceGetParametersResponse))]
[XmlInclude(typeof(VerifoneDeviceGetPaymentTypesResponse))]
[XmlInclude(typeof(VerifoneDeviceLaneClosedResponse))]
[XmlInclude(typeof(VerifoneDeviceLoyaltyCaptureResponse))]
[XmlInclude(typeof(VerifoneDeviceProvisionPassResponse))]
[XmlInclude(typeof(VerifoneDeviceQueryNfcIniResponse))]
[XmlInclude(typeof(VerifoneDeviceQuickCreditApplicationResponse))]
[XmlInclude(typeof(VerifoneDeviceRetrieveVersionResponse))]
[XmlInclude(typeof(VerifoneDeviceSetDeviceNameResponse))]
[XmlInclude(typeof(VerifoneDeviceSetParametersResponse))]
[XmlInclude(typeof(VerifoneDeviceSignatureResponse))]
[XmlInclude(typeof(VerifoneDeviceTokenQueryResponse))]
[XmlInclude(typeof(VerifoneDeviceTransactionResponse))]

// Token
[XmlInclude(typeof(VerifoneDeviceTokenQueryResponse))]

// Settlement
[XmlInclude(typeof(VerifoneDeviceScheduleSettlementResponse))]

// Session Management
[XmlInclude(typeof(VerifoneDeviceFinishSessionResponse))]
[XmlInclude(typeof(VerifoneDeviceStartSessionResponse))]

// Security
[XmlInclude(typeof(VerifoneDeviceRegisterEncryptionResponse))]
[XmlInclude(typeof(VerifoneDeviceRegisterPosResponse))]
[XmlInclude(typeof(VerifoneDeviceSecurityResponse))]
[XmlInclude(typeof(VerifoneDeviceTestMacResponse))]
[XmlInclude(typeof(VerifoneDeviceUnregisterAllResponse))]
[XmlInclude(typeof(VerifoneDeviceUnregisterPosResponse))]

[XmlRoot("RESPONSE")]
public class VerifoneDeviceResponse
{
    [XmlElement("RESPONSE_TEXT")]
    public string? ResponseText { get; set; }  

    [XmlElement("RESULT")]
    public string? Result { get; set; }  

    [XmlElement("RESULT_CODE")]
    public int? ResultCode { get; set; }  

    [XmlElement("TERMINATION_STATUS")]
    public string? TerminationStatus { get; set; } 

    [XmlElement("COUNTER")]
    public long? Counter { get; set; }  
}