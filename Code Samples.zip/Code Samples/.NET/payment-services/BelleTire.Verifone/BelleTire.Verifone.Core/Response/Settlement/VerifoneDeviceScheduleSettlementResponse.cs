﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Settlement;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceScheduleSettlementResponse : VerifoneDeviceResponse
{
    
}