using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.LineItem;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceOverrideLineItemResponse : VerifoneDeviceLineItemResponse {}