﻿using System.Xml.Serialization;
using BelleTire.Verifone.Core.Request;
using BelleTire.Verifone.Core.Request.Admin;
using BelleTire.Verifone.Core.Request.LineItem;
using BelleTire.Verifone.Core.Request.Payment;
using BelleTire.Verifone.Core.Request.Report;
using BelleTire.Verifone.Core.Request.SecondaryPort;
using BelleTire.Verifone.Core.Request.Security;
using BelleTire.Verifone.Core.Request.SessionManagement;
using BelleTire.Verifone.Core.Request.Settlement;
using BelleTire.Verifone.Core.Request.Token;
using BelleTire.Verifone.Core.Request.Transactions;
using BelleTire.Verifone.Core.Response.Admin;
using BelleTire.Verifone.Core.Response.LineItem;
using BelleTire.Verifone.Core.Response.Payment;
using BelleTire.Verifone.Core.Response.Reports;
using BelleTire.Verifone.Core.Response.SecondaryPort;
using BelleTire.Verifone.Core.Response.Security;
using BelleTire.Verifone.Core.Response.SessionManagement;
using BelleTire.Verifone.Core.Response.Settlement;
using BelleTire.Verifone.Core.Response.Token;
using BelleTire.Verifone.Core.Response.Transactions;

namespace BelleTire.Verifone.Core.Response;

public class VerifoneDeviceResponseFactory
{
    public VerifoneDeviceResponse DeserializeCommandResponse(DeviceCommand deviceCommand, string responseXml)
    {
        var convertToType = GetResponseTypeForCommand(deviceCommand);

        var serializer = new XmlSerializer(convertToType);
        var responseStringReader = new StringReader(responseXml);
        var deserializedResponse = serializer.Deserialize(responseStringReader);

        return deserializedResponse != null 
            ? GetTypedResponse(deviceCommand, deserializedResponse) 
            : new VerifoneDeviceResponse() { ResponseText = "Error deserializing response"};
    }

    private VerifoneDeviceResponse GetTypedResponse(DeviceCommand deviceCommand, object response) =>
        deviceCommand switch
        {
            DeviceCommand.CancelDisplayLeftPanel => (VerifoneDeviceCancelDisplayLeftPanelResponse) response,
            DeviceCommand.CancelQrCode => (VerifoneDeviceCancelQrResponse) response,
            DeviceCommand.Charity => (VerifoneDeviceCharityDonationResponse) response,
            DeviceCommand.TokenQuery => (VerifoneDeviceTokenQueryResponse) response,
            DeviceCommand.Checkbox => (VerifoneDeviceCheckboxResponse) response,
            DeviceCommand.CustomerButton => (VerifoneDeviceCustomerButtonResponse) response,
            DeviceCommand.CustomerQuestion => (VerifoneDeviceCustomerQuestionResponse) response,
            DeviceCommand.Survey10 => (VerifoneDeviceCustomerSurvey10Response) response,
            DeviceCommand.Survey5 => (VerifoneDeviceCustomerSurvey5Response) response,
            DeviceCommand.Survey => (VerifoneDeviceCustomerSurveyResponse) response,
            DeviceCommand.DisplayImage => (VerifoneDeviceDisplayImageResponse) response,
            DeviceCommand.DisplayLeftPanel => (VerifoneDeviceDisplayLeftPanelResponse) response,
            DeviceCommand.DisplayMessage => (VerifoneDeviceDisplayMessageResponse) response,
            DeviceCommand.EmailCapture => (VerifoneDeviceEmailCaptureResponse) response,
            DeviceCommand.GetCardData => (VerifoneDeviceGetCardDataResponse) response,
            DeviceCommand.GetDeviceName => (VerifoneDeviceGetDeviceNameResponse) response,
            DeviceCommand.GetParameters => (VerifoneDeviceGetParametersResponse) response,
            DeviceCommand.GetPaymentTypes => (VerifoneDeviceGetPaymentTypesResponse) response,
            DeviceCommand.Loyalty => (VerifoneDeviceLoyaltyCaptureResponse) response,
            DeviceCommand.ProvisionPass => (VerifoneDeviceProvisionPassResponse) response,
            DeviceCommand.QueryNfcIni => (VerifoneDeviceQueryNfcIniResponse) response,
            DeviceCommand.CreditApplication => (VerifoneDeviceQuickCreditApplicationResponse) response,
            DeviceCommand.Version => (VerifoneDeviceRetrieveVersionResponse) response,
            DeviceCommand.SetDeviceName => (VerifoneDeviceSetDeviceNameResponse) response,
            DeviceCommand.SetParameter => (VerifoneDeviceSetParametersResponse) response,
            DeviceCommand.Signature => (VerifoneDeviceSignatureResponse) response,
            DeviceCommand.SignatureExpanded => (VerifoneDeviceExpandedSignatureResponse) response,
            DeviceCommand.Add => (VerifoneDeviceAddLineItemResponse) response,
            DeviceCommand.Remove => (VerifoneDeviceRemoveLineItemResponse) response,
            DeviceCommand.RemoveAll => (VerifoneDeviceRemoveAllLineItemsResponse) response,
            DeviceCommand.Show => (VerifoneDeviceShowLineItemsResponse) response,
            DeviceCommand.ApplyUpdates => (VerifoneDeviceApplyUpdatesResponse) response,
            DeviceCommand.GetCounter => (VerifoneDeviceGetCounterResponse) response,
            DeviceCommand.LaneClosed => (VerifoneDeviceLaneClosedResponse) response,
            DeviceCommand.SetTime => (VerifoneDeviceSetTimeResponse) response,
            DeviceCommand.StoreAndForward => (VerifoneDeviceStoreAndForwardResponse) response,
            DeviceCommand.Authorize => (VerifoneDeviceAuthorizePaymentResponse) response,
            DeviceCommand.Capture => (VerifoneDeviceCapturePaymentResponse) response,
            DeviceCommand.Credit => (VerifoneDeviceCreditPaymentResponse) response,
            DeviceCommand.Void => (VerifoneDeviceVoidPaymentResponse) response,
            DeviceCommand.Token => (VerifoneDeviceTokenQueryResponse) response,
            DeviceCommand.DailySummary => (VerifoneDeviceDailySettlementSummaryReportResponse) response,
            DeviceCommand.PreSettlement => (VerifoneDevicePreSettlementReportResponse) response,
            DeviceCommand.DuplicateCheck => (VerifoneDeviceDuplicateCheckResponse) response,
            DeviceCommand.LastTransaction => (VerifoneDeviceLastTransactionResponse) response,
            DeviceCommand.SettlementErrors => (VerifoneDeviceSettlementErrorReportResponse) response,
            DeviceCommand.SettlementSummary => (VerifoneDeviceDailySettlementSummaryReportResponse) response,
            DeviceCommand.TransactionSearch => (VerifoneDeviceTransactionSearchResponse) response,
            DeviceCommand.Cancel => (VerifoneDeviceCancelResponse) response,
            DeviceCommand.Reboot => (VerifoneDeviceRebootResponse) response,
            DeviceCommand.Status => (VerifoneDeviceStatusResponse) response,
            DeviceCommand.AnyUpdates => (VerifoneDeviceUpdateQueryResponse) response,
            DeviceCommand.UpdateStatus => (VerifoneDeviceUpdateStatusResponse) response,
            DeviceCommand.RegisterEncryptionPos => (VerifoneDeviceRegisterEncryptionResponse) response,
            DeviceCommand.RegisterPos => (VerifoneDeviceRegisterPosResponse) response,
            DeviceCommand.TestMac => (VerifoneDeviceTestMacResponse) response,
            DeviceCommand.UnregisterAllPos => (VerifoneDeviceUnregisterAllResponse) response,
            DeviceCommand.UnregisterPos => (VerifoneDeviceUnregisterPosResponse) response,
            DeviceCommand.Finish => (VerifoneDeviceFinishSessionResponse) response,
            DeviceCommand.Start => (VerifoneDeviceStartSessionResponse) response,
            DeviceCommand.Settle => (VerifoneDeviceScheduleSettlementResponse) response,
            _ => throw new ArgumentOutOfRangeException(nameof(deviceCommand), deviceCommand, null)
        };
    
    private Type GetResponseTypeForCommand(DeviceCommand deviceCommand) =>
        deviceCommand switch
        {
            DeviceCommand.CancelDisplayLeftPanel => typeof(VerifoneDeviceCancelDisplayLeftPanelResponse),
            DeviceCommand.CancelQrCode => typeof(VerifoneDeviceCancelQrResponse),
            DeviceCommand.Charity => typeof(VerifoneDeviceCharityDonationResponse),
            DeviceCommand.TokenQuery => typeof(VerifoneDeviceTokenQueryResponse),
            DeviceCommand.Checkbox => typeof(VerifoneDeviceCheckboxResponse),
            DeviceCommand.CustomerButton => typeof(VerifoneDeviceCustomerButtonResponse),
            DeviceCommand.CustomerQuestion => typeof(VerifoneDeviceCustomerQuestionResponse),
            DeviceCommand.Survey10 => typeof(VerifoneDeviceCustomerSurvey10Response),
            DeviceCommand.Survey5 => typeof(VerifoneDeviceCustomerSurvey5Response),
            DeviceCommand.Survey => typeof(VerifoneDeviceCustomerSurveyResponse),
            DeviceCommand.DisplayImage => typeof(VerifoneDeviceDisplayImageResponse),
            DeviceCommand.DisplayLeftPanel => typeof(VerifoneDeviceDisplayLeftPanelResponse),
            DeviceCommand.DisplayMessage => typeof(VerifoneDeviceDisplayMessageResponse),
            DeviceCommand.EmailCapture => typeof(VerifoneDeviceEmailCaptureResponse),
            DeviceCommand.GetCardData => typeof(VerifoneDeviceGetCardDataResponse),
            DeviceCommand.GetDeviceName => typeof(VerifoneDeviceGetDeviceNameResponse),
            DeviceCommand.GetParameters => typeof(VerifoneDeviceGetParametersResponse),
            DeviceCommand.GetPaymentTypes => typeof(VerifoneDeviceGetPaymentTypesResponse),
            DeviceCommand.Loyalty => typeof(VerifoneDeviceLoyaltyCaptureResponse),
            DeviceCommand.ProvisionPass => typeof(VerifoneDeviceProvisionPassResponse),
            DeviceCommand.QueryNfcIni => typeof(VerifoneDeviceQueryNfcIniResponse),
            DeviceCommand.CreditApplication => typeof(VerifoneDeviceQuickCreditApplicationResponse),
            DeviceCommand.Version => typeof(VerifoneDeviceRetrieveVersionResponse),
            DeviceCommand.SetDeviceName => typeof(VerifoneDeviceSetDeviceNameResponse),
            DeviceCommand.SetParameter => typeof(VerifoneDeviceSetParametersResponse),
            DeviceCommand.Signature => typeof(VerifoneDeviceSignatureResponse),
            DeviceCommand.SignatureExpanded => typeof(VerifoneDeviceExpandedSignatureResponse),
            DeviceCommand.Add => typeof(VerifoneDeviceAddLineItemResponse),
            DeviceCommand.Remove => typeof(VerifoneDeviceRemoveLineItemResponse),
            DeviceCommand.RemoveAll => typeof(VerifoneDeviceRemoveAllLineItemsResponse),
            DeviceCommand.Show => typeof(VerifoneDeviceShowLineItemsResponse),
            DeviceCommand.ApplyUpdates => typeof(VerifoneDeviceApplyUpdatesResponse),
            DeviceCommand.GetCounter => typeof(VerifoneDeviceGetCounterResponse),
            DeviceCommand.LaneClosed => typeof(VerifoneDeviceLaneClosedResponse),
            DeviceCommand.SetTime => typeof(VerifoneDeviceSetTimeResponse),
            DeviceCommand.StoreAndForward => typeof(VerifoneDeviceStoreAndForwardResponse),
            DeviceCommand.Authorize => typeof(VerifoneDeviceAuthorizePaymentResponse),
            DeviceCommand.Capture => typeof(VerifoneDeviceCapturePaymentResponse),
            DeviceCommand.Credit => typeof(VerifoneDeviceCreditPaymentResponse),
            DeviceCommand.Void => typeof(VerifoneDeviceVoidPaymentResponse),
            DeviceCommand.Token => typeof(VerifoneDeviceTokenQueryResponse),
            DeviceCommand.DailySummary => typeof(VerifoneDeviceDailySettlementSummaryReportResponse),
            DeviceCommand.PreSettlement => typeof(VerifoneDevicePreSettlementReportResponse),
            DeviceCommand.DuplicateCheck => typeof(VerifoneDeviceDuplicateCheckResponse),
            DeviceCommand.LastTransaction => typeof(VerifoneDeviceLastTransactionResponse),
            DeviceCommand.SettlementErrors => typeof(VerifoneDeviceSettlementErrorReportResponse),
            DeviceCommand.SettlementSummary => typeof(VerifoneDeviceDailySettlementSummaryReportResponse),
            DeviceCommand.TransactionSearch => typeof(VerifoneDeviceTransactionSearchResponse),
            DeviceCommand.Cancel => typeof(VerifoneDeviceCancelResponse),
            DeviceCommand.Reboot => typeof(VerifoneDeviceRebootResponse),
            DeviceCommand.Status => typeof(VerifoneDeviceStatusResponse),
            DeviceCommand.AnyUpdates => typeof(VerifoneDeviceUpdateQueryResponse),
            DeviceCommand.UpdateStatus => typeof(VerifoneDeviceUpdateStatusResponse),
            DeviceCommand.RegisterEncryptionPos => typeof(VerifoneDeviceRegisterEncryptionResponse),
            DeviceCommand.RegisterPos => typeof(VerifoneDeviceRegisterPosResponse),
            DeviceCommand.TestMac => typeof(VerifoneDeviceTestMacResponse),
            DeviceCommand.UnregisterAllPos => typeof(VerifoneDeviceUnregisterAllResponse),
            DeviceCommand.UnregisterPos => typeof(VerifoneDeviceUnregisterPosResponse),
            DeviceCommand.Finish => typeof(VerifoneDeviceFinishSessionResponse),
            DeviceCommand.Start => typeof(VerifoneDeviceStartSessionResponse),
            DeviceCommand.Settle => typeof(VerifoneDeviceScheduleSettlementResponse),
            _ => throw new ArgumentOutOfRangeException(nameof(deviceCommand), deviceCommand, null)
        };

    public Type GetResponseTypeForRequest(VerifoneDeviceRequest request) => request switch
    {
        VerifoneDeviceApplyUpdatesRequest verifoneDeviceApplyUpdatesRequest => typeof(VerifoneDeviceApplyUpdatesResponse),
        VerifoneDeviceGetCounterRequest verifoneDeviceGetCounterRequest => typeof(VerifoneDeviceGetCounterResponse),
        VerifoneDeviceSetTimeRequest verifoneDeviceSetTimeRequest => typeof(VerifoneDeviceSetTimeResponse),
        VerifoneDeviceStoreAndForwardRequest verifoneDeviceStoreAndForwardRequest => typeof(VerifoneDeviceStoreAndForwardResponse),
        VerifoneDeviceAddLineItemRequest verifoneDeviceAddLineItemRequest => typeof(VerifoneDeviceAddLineItemResponse),
        VerifoneDeviceRemoveAllLineItemsRequest verifoneDeviceRemoveAllLineItemsRequest => typeof(VerifoneDeviceRemoveAllLineItemsResponse),
        VerifoneDeviceRemoveLineItemRequest verifoneDeviceRemoveLineItemRequest => typeof(VerifoneDeviceRemoveLineItemResponse),
        VerifoneDeviceShowLineItemsRequest verifoneDeviceShowLineItemsRequest => typeof(VerifoneDeviceShowLineItemsResponse),
        VerifoneDeviceAuthorizePaymentRequest verifoneDeviceAuthorizePaymentRequest => typeof(VerifoneDeviceAuthorizePaymentResponse),
        VerifoneDeviceCapturePaymentRequest verifoneDeviceCapturePaymentRequest => typeof(VerifoneDeviceCapturePaymentResponse),
        VerifoneDeviceCreditPaymentRequest verifoneDeviceCreditPaymentRequest => typeof(VerifoneDeviceCreditPaymentResponse),
        VerifoneDeviceVoidPaymentRequest verifoneDeviceVoidPaymentRequest => typeof(VerifoneDeviceVoidPaymentResponse),
        VerifoneDeviceDailySettlementSummaryReportRequest verifoneDeviceDailySettlementSummaryReportRequest => typeof(VerifoneDeviceDailySettlementSummaryReportResponse),
        VerifoneDeviceDuplicateCheckRequest verifoneDeviceDuplicateCheckRequest => typeof(VerifoneDeviceDuplicateCheckResponse),
        VerifoneDeviceLastTransactionRequest verifoneDeviceLastTransactionRequest => typeof(VerifoneDeviceLastTransactionResponse),
        VerifoneDevicePreSettlementReportRequest verifoneDevicePreSettlementReportRequest => typeof(VerifoneDevicePreSettlementReportResponse),
        VerifoneDeviceSettlementErrorReportRequest verifoneDeviceSettlementErrorReportRequest => typeof(VerifoneDeviceSettlementErrorReportResponse),
        VerifoneDeviceTransactionSearchRequest verifoneDeviceTransactionSearchRequest => typeof(VerifoneDeviceTransactionSearchResponse),
        VerifoneDeviceCancelRequest verifoneDeviceCancelRequest => typeof(VerifoneDeviceCancelResponse),
        VerifoneDeviceRebootRequest verifoneDeviceRebootRequest => typeof(VerifoneDeviceRebootResponse),
        VerifoneDeviceStatusRequest verifoneDeviceStatusRequest => typeof(VerifoneDeviceStatusResponse),
        VerifoneDeviceUpdateQueryRequest verifoneDeviceUpdateQueryRequest => typeof(VerifoneDeviceUpdateQueryResponse),
        VerifoneDeviceUpdateStatusRequest verifoneDeviceUpdateStatusRequest => typeof(VerifoneDeviceUpdateStatusResponse),
        VerifoneDeviceRegisterEncryptionRequest verifoneDeviceRegisterEncryptionRequest => typeof(VerifoneDeviceRegisterEncryptionResponse),
        VerifoneDeviceRegisterPosRequest verifoneDeviceRegisterPosRequest => typeof(VerifoneDeviceRegisterPosResponse),
        VerifoneDeviceSecurityRequest verifoneDeviceSecurityRequest => typeof(VerifoneDeviceSecurityResponse),
        VerifoneDeviceTestMacRequest verifoneDeviceTestMacRequest => typeof(VerifoneDeviceTestMacResponse),
        VerifoneDeviceUnregisterAllRequest verifoneDeviceUnregisterAllRequest => typeof(VerifoneDeviceUnregisterAllResponse),
        VerifoneDeviceUnregisterPosRequest verifoneDeviceUnregisterPosRequest => typeof(VerifoneDeviceUnregisterPosResponse),
        VerifoneDeviceFinishSessionRequest verifoneDeviceFinishSessionRequest => typeof(VerifoneDeviceFinishSessionResponse),
        VerifoneDeviceStartSessionRequest verifoneDeviceStartSessionRequest => typeof(VerifoneDeviceStartSessionResponse),
        VerifoneDeviceScheduleSettlementRequest verifoneDeviceScheduleSettlementRequest => typeof(VerifoneDeviceScheduleSettlementResponse),
        VerifoneDeviceTokenRequest verifoneDeviceTokenRequest => typeof(VerifoneDeviceTokenQueryResponse),
        VerifoneDeviceCancelDisplayLeftPanelRequest verifoneDeviceCancelDisplayLeftPanelRequest => typeof(VerifoneDeviceCancelDisplayLeftPanelResponse),
        VerifoneDeviceCancelQrRequest verifoneDeviceCancelQrRequest => typeof(VerifoneDeviceCancelQrResponse),
        VerifoneDeviceCharityDonationRequest verifoneDeviceCharityDonationRequest => typeof(VerifoneDeviceCharityDonationResponse),
        VerifoneDeviceCheckboxRequest verifoneDeviceCheckboxRequest => typeof(VerifoneDeviceCheckboxResponse),
        VerifoneDeviceCustomerButtonRequest verifoneDeviceCustomerButtonRequest => typeof(VerifoneDeviceCustomerButtonResponse),
        VerifoneDeviceCustomerQuestionRequest verifoneDeviceCustomerQuestionRequest => typeof(VerifoneDeviceCustomerQuestionResponse),
        VerifoneDeviceCustomerSurvey10Request verifoneDeviceCustomerSurvey10Request => typeof(VerifoneDeviceCustomerSurvey10Response),
        VerifoneDeviceCustomerSurvey5Request verifoneDeviceCustomerSurvey5Request => typeof(VerifoneDeviceCustomerSurvey5Response),
        VerifoneDeviceCustomerSurveyRequest verifoneDeviceCustomerSurveyRequest => typeof(VerifoneDeviceCustomerSurveyResponse),
        VerifoneDeviceDisplayImageRequest verifoneDeviceDisplayImageRequest => typeof(VerifoneDeviceDisplayImageResponse),
        VerifoneDeviceDisplayLeftPanelRequest verifoneDeviceDisplayLeftPanelRequest => typeof(VerifoneDeviceDisplayLeftPanelResponse),
        VerifoneDeviceDisplayMessageRequest verifoneDeviceDisplayMessageRequest => typeof(VerifoneDeviceDisplayMessageResponse),
        VerifoneDeviceDisplayQrRequest verifoneDeviceDisplayQrRequest => typeof(VerifoneDeviceDisplayQrResponse),
        VerifoneDeviceEmailCaptureRequest verifoneDeviceEmailCaptureRequest => typeof(VerifoneDeviceEmailCaptureResponse),
        VerifoneDeviceExpandedSignatureRequest verifoneDeviceExpandedSignatureRequest => typeof(VerifoneDeviceExpandedSignatureResponse),
        VerifoneDeviceGetCardDataRequest verifoneDeviceGetCardDataRequest => typeof(VerifoneDeviceGetCardDataResponse),
        VerifoneDeviceGetDeviceNameRequest verifoneDeviceGetDeviceNameRequest => typeof(VerifoneDeviceGetDeviceNameResponse),
        VerifoneDeviceGetParametersRequest verifoneDeviceGetParametersRequest => typeof(VerifoneDeviceGetParametersResponse),
        VerifoneDeviceGetPaymentTypesRequest verifoneDeviceGetPaymentTypesRequest => typeof(VerifoneDeviceGetPaymentTypesResponse),
        VerifoneDeviceLaneClosedRequest verifoneDeviceLaneClosedRequest => typeof(VerifoneDeviceLaneClosedResponse),
        VerifoneDeviceLoyaltyCaptureRequest verifoneDeviceLoyaltyCaptureRequest => typeof(VerifoneDeviceLoyaltyCaptureResponse),
        VerifoneDeviceProvisionPassRequest verifoneDeviceProvisionPassRequest => typeof(VerifoneDeviceProvisionPassResponse),
        VerifoneDeviceQueryNfcIniRequest verifoneDeviceQueryNfcIniRequest => typeof(VerifoneDeviceQueryNfcIniResponse),
        VerifoneDeviceQuickCreditApplicationRequest verifoneDeviceQuickCreditApplicationRequest => typeof(VerifoneDeviceQuickCreditApplicationResponse),
        VerifoneDeviceRetrieveVersionRequest verifoneDeviceRetrieveVersionRequest => typeof(VerifoneDeviceRetrieveVersionResponse),
        VerifoneDeviceSetDeviceNameRequest verifoneDeviceSetDeviceNameRequest => typeof(VerifoneDeviceSetDeviceNameResponse),
        VerifoneDeviceSetParametersRequest verifoneDeviceSetParametersRequest => typeof(VerifoneDeviceSetParametersResponse),
        VerifoneDeviceSignatureRequest verifoneDeviceSignatureRequest => typeof(VerifoneDeviceSignatureResponse),
        VerifoneDeviceTokenQueryRequest verifoneDeviceTokenQueryRequest => typeof(VerifoneDeviceTokenQueryResponse),
        VerifoneDevicePaymentRequest verifoneDevicePaymentRequest => typeof(VerifoneDeviceCreditPaymentResponse),
        VerifoneDeviceSecondaryPortRequest verifoneDeviceSecondaryPortRequest => typeof(VerifoneDeviceSecondaryPortResponse),
        VerifoneDeviceTransactionRequest verifoneDeviceTransactionRequest => typeof(VerifoneDeviceTransactionResponse),
        _ => throw new ArgumentOutOfRangeException(nameof(request))
    };
    
}