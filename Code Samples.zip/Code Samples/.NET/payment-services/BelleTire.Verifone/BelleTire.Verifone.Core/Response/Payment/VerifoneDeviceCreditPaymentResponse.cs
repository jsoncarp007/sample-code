using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Payment;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceCreditPaymentResponse : VerifoneDeviceResponse
{
    [XmlElement("TRAINING_MODE")]
    public string? TrainingMode { get; set; }

    [XmlElement("TRANS_SEQ_NUM")]
    public int? TransactionSequenceNumber { get; set; }  

    [XmlElement("INTRN_SEQ_NUM")]
    public int? InternalSequenceNumber { get; set; }  

    [XmlElement("TROUTD")]
    public string? Troutd { get; set; }  

    [XmlElement("CTROUTD")]
    public string? Ctroutd { get; set; }  

    [XmlElement("AUTH_CODE")]
    public string? AuthCode { get; set; }  

    [XmlElement("LPTOKEN")]
    public int? LpToken { get; set; }  

    [XmlElement("ACCT_NUM")]
    public string? AccountNumber { get; set; }  

    [XmlElement("CARD_EXP_MONTH")]
    public int? CardExpirationMonth { get; set; }  

    [XmlElement("CARD_EXP_YEAR")]
    public int? CardExpirationYear { get; set; }  

    [XmlElement("CARD_ENTRY_MODE")]
    public string? CardEntryMode { get; set; }  

    [XmlElement("EMV_REVERSAL_TYPE")]
    public int? EmvReversalType { get; set; }  

    [XmlElement("CARDHOLDER")]
    public string? Cardholder { get; set; }  

    [XmlElement("APPROVED_AMOUNT")]
    public decimal? ApprovedAmount { get; set; } 

    [XmlElement("AVAILABLE_BALANCE")]
    public decimal? AvailableBalance { get; set; } 

    [XmlElement("FS_AVAIL_BALANCE")]
    public decimal? FsAvailBalance { get; set; } 

    [XmlElement("CB_AVAIL_BALANCE")]
    public decimal? CbAvailBalance { get; set; } 

    [XmlElement("PAYMENT_MEDIA")]
    public string? PaymentMedia { get; set; }  

    [XmlElement("CARD_ABBRV")]
    public string? CardAbbreviation { get; set; }  

    [XmlElement("PAYMENT_TYPE")]
    public string? PaymentType { get; set; }  

    [XmlElement("PPCV")]
    public string? Ppcv { get; set; }  

    [XmlElement("EBT_TYPE")]
    public string? EbtType { get; set; }  

    [XmlElement("AUTH_RESP_CODE")]
    public string? AuthRespCode { get; set; }  

    [XmlElement("HOST_RESPCODE")]
    public string? HostRespCode { get; set; }  

    [XmlElement("RESPONSE_CODE")]
    public string? ResponseCode { get; set; }  

    [XmlElement("AUTHNWID")]
    public string? AuthNwId { get; set; }  

    [XmlElement("AUTHNWNAME")]
    public string? AuthNwName { get; set; }  

    [XmlElement("BANK_USERDATA")]
    public string? BankUserData { get; set; }  

    [XmlElement("SAF_NUM")]
    public string? SafNum { get; set; }  

    [XmlElement("MERCHID")]
    public string? MerchantId { get; set; }  

    [XmlElement("TERMID")]
    public string? TerminalId { get; set; }  

    [XmlElement("RECEIPT_DATA")]
    public string? ReceiptData { get; set; }  

    [XmlElement("TRANS_DATE")]
    public string? TransDate { get; set; }  

    [XmlElement("TRANS_TIME")]
    public string?TransTime { get; set; }  

    [XmlElement("BATCH_TRACE_ID")]
    public string? BatchTraceId { get; set; }  

    [XmlElement("TRACE_NUM")]
    public string? TraceNum { get; set; }  

    [XmlElement("REFERENCE")]
    public string? Reference { get; set; }  

    [XmlElement("POS_RECON")]
    public string? PosRecon { get; set; }  

    [XmlElement("VSP_CODE")]
    public string? VspCode { get; set; }  

    [XmlElement("VSP_RESULTDESC")]
    public string? VspResultDesc { get; set; }  

    [XmlElement("VSP_TRXID")]
    public string? VspTrxId { get; set; }  

    [XmlElement("STATUS_FLAG")]
    public string? StatusFlag { get; set; }  

    [XmlElement("ACTION_CODE")]
    public string? ActionCode { get; set; }  

    [XmlElement("SVC_PHONE")]
    public string? SvcPhone { get; set; }  

    [XmlElement("CREDIT_PLAN_NBR")]
    public string? CreditPlanNbr { get; set; }  

    [XmlElement("CARD_TOKEN")]
    public string? CardToken { get; set; }  

    [XmlElement("INVOICE")]
    public string? Invoice { get; set; }  
    
    [XmlElement("EMV_TAG_4F")]
    public string? EmvTag4F { get; set; }  
    
    [XmlElement("EMV_TAG_50")]
    public string? EmvTag50 { get; set; }  
    
    [XmlElement("EMV_TAG_5F2A")]
    public string? EmvTag5F2A { get; set; }  
    
    [XmlElement("EMV_TAG_5F34")]
    public string? EmvTag5F34 { get; set; }  
    
    [XmlElement("EMV_TAG_82")]
    public string? EmvTag82 { get; set; }  
    
    [XmlElement("EMV_TAG_8A")]
    public string? EmvTag8A { get; set; }  
    
    [XmlElement("EMV_TAG_95")]
    public string? EmvTag95 { get; set; }  
    
    [XmlElement("EMV_TAG_9A")]
    public string? EmvTag9A { get; set; }  
    
    [XmlElement("EMV_TAG_9B")]
    public string? EmvTag9B { get; set; }  
    
    [XmlElement("EMV_TAG_9C")]
    public string? EmvTag9C { get; set; }  
    
    [XmlElement("EMV_TAG_9F02")]
    public string? EmvTag9F02 { get; set; }  
    
    [XmlElement("EMV_TAG_9F03")]
    public string? EmvTag9F03 { get; set; }  
    
    [XmlElement("EMV_TAG_9F07")]
    public string? EmvTag9F07 { get; set; }  
    
    [XmlElement("EMV_TAG_9F0D")]
    public string? EmvTag9F0D { get; set; }  
    
    [XmlElement("EMV_TAG_9F0E")]
    public string? EmvTag9F0E { get; set; }  
    
    [XmlElement("EMV_TAG_9F0F")]
    public string? EmvTag9F0F { get; set; }  
    
    [XmlElement("EMV_TAG_9F10")]
    public string? EmvTag9F10 { get; set; }  
    
    [XmlElement("EMV_TAG_9F1A")]
    public string? EmvTag9F1A { get; set; }  
    
    [XmlElement("EMV_TAG_9F26")]
    public string? EmvTag9F26 { get; set; }  
    
    [XmlElement("EMV_TAG_9F27")]
    public string? EmvTag9F27 { get; set; }  
    
    [XmlElement("EMV_TAG_9F34")]
    public string? EmvTag9F34 { get; set; }  
    
    [XmlElement("EMV_TAG_9F36")]
    public string? EmvTag9F36 { get; set; }  
    
    [XmlElement("EMV_TAG_9F37")]
    public string? EmvTag9F37 { get; set; }  
    
    [XmlElement("EMV_MODE")]
    public string? EmvMode { get; set; }  
    
    [XmlElement("EMV_CVM")]
    public string? EmvCvm { get; set; }  
    
    [XmlElement("EMV_CHIP_INDICATOR")]
    public string? EmvChipIndicator { get; set; }  
    
    [XmlElement("TAC_DEFAULT")]
    public string? TacDefault { get; set; }  
    
    [XmlElement("TAC_DENIAL")]
    public string? TacDenial { get; set; }  
    
    [XmlElement("TAC_ONLINE")]
    public string? TacOnline { get; set; }  
    
    [XmlElement("EMV_TAG_84")]
    public string? EmvTag84 { get; set; }  
    
    [XmlElement("EMV_TAG_9F21")]
    public string? EmvTag9F21 { get; set; }  
    
    [XmlElement("EMV_TAG_9F08")]
    public string? EmvTag9F08 { get; set; }  
    
    [XmlElement("EMV_TAG_9F09")]
    public string? EmvTag9F09 { get; set; }  
    
    [XmlElement("EMV_TAG_9F33")]
    public string? EmvTag9F33 { get; set; }  
    
    [XmlElement("EMV_TAG_9F35")]
    public string? EmvTag9F35 { get; set; }  
    
    [XmlElement("EMV_TAG_8E")]
    public string? EmvTag8E { get; set; }  

}