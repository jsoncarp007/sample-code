﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Payment;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceCapturePaymentResponse : VerifoneDeviceResponse
{
    [XmlElement("TRANS_SEQ_NUM")]
    public int? TransSeqNum { get; set; } 

    [XmlElement("INTRN_SEQ_NUM")]
    public int? InternalSequenceNumber { get; set; } 

    [XmlElement("TROUTD")]
    public string? Troutd { get; set; }  

    [XmlElement("CTROUTD")]
    public string? CTroutd { get; set; }  

    [XmlElement("PAYMENT_TYPE")]
    public string? PaymentType { get; set; } 
    
    [XmlElement("PAYMENT_MEDIA")]
    public string? PaymentMedia { get; set; } 

    [XmlElement("PINLESSDEBIT")]
    public string? PinlessDebit { get; set; } 

    [XmlElement("EBT_TYPE")]
    public string? EbtType { get; set; } 

    [XmlElement("ACCT_NUM")]
    public string? AcctNum { get; set; }

    [XmlElement("AUTH_CODE")]
    public string? AuthCode { get; set; } 

    [XmlElement("AVALABLE_BALANCE")]
    public decimal? AvailableBalance { get; set; }  

    [XmlElement("APPROVED_AMOUNT")]
    public decimal? ApprovedAmount { get; set; }  

    [XmlElement("DIFF_AMOUNT_DUE")]
    public decimal? DiffAmountDue { get; set; }  

    [XmlElement("FSA_AMOUNT")]
    public decimal? FsaAmount { get; set; }  

    [XmlElement("CASHBACK_AMOUNT")]
    public decimal? CashbackAmount { get; set; }  

    [XmlElement("TIP_AMOUNT")]
    public decimal? TipAmount { get; set; }  

    [XmlElement("FS_AVAIL_BALANCE")]
    public decimal? FsAvailBalance { get; set; }  

    [XmlElement("CB_AVAIL_BALANCE")]
    public decimal? CbAvailBalance { get; set; }  

    [XmlElement("CARD_ENTRY_MODE")]
    public string? CardEntryMode { get; set; } 

    [XmlElement("CARDHOLDER")]
    public string? Cardholder { get; set; } 

    [XmlElement("CARD_EXP_MONTH")]
    public int? CardExpirationMonth { get; set; }  

    [XmlElement("CARD_EXP_YEAR")]
    public int? CardExpirationYear { get; set; }  

    [XmlElement("AVS_CODE")]
    public string? AvsCode { get; set; } 

    [XmlElement("CVV2_CODE")]
    public string? Cvv2Code { get; set; } 

    [XmlElement("CUSTOMER_ZIP")]
    public string? CustomerZip { get; set; }  

    [XmlElement("PRESWIPED")]
    public int? Preswiped { get; set; }  

    [XmlElement("AUTH_RESP_CODE")]
    public string? AuthRespCode { get; set; } 

    [XmlElement("BANK_USERDATA")]
    public string? BankUserData { get; set; } 

    [XmlElement("EMBOSSED_ACCT_NUM")]
    public string? EmbossedAccountNumber { get; set; }  

    [XmlElement("SAF_NUM")]
    public string? SafNum { get; set; }

    [XmlElement("TRANS_DATE")]
    public string? TransactionDate { get; set; } 

    [XmlElement("TRANS_TIME")]
    public string? TransactionTime { get; set; } 

    [XmlElement("AUTHNWID")]
    public string? AuthNwId { get; set; } 

    [XmlElement("AUTHNWNAME")]
    public string? AuthNwName { get; set; } 

    [XmlElement("BATCH_TRACE_ID")]
    public string? BatchTraceId { get; set; } 

    [XmlElement("TRAINING_MODE")]
    public string? TrainingMode { get; set; } 

    [XmlElement("POS_RECON")]
    public string? PosRecon { get; set; }

    [XmlElement("SIGNATUREDATA")]
    public string? SignatureData { get; set; }  

    [XmlElement("MIME_TYPE")]
    public string? MimeType { get; set; } 

    [XmlElement("SIGNATUREREF")]
    public string? SignatureRef { get; set; } 
   
    [XmlElement("POS_TENDER1_DATA")]
    public string? PosTender1Data { get; set; } 

    [XmlElement("POS_TENDER2_DATA")]
    public string? PosTender2Data { get; set; } 

    [XmlElement("POS_TENDER3_DATA")]
    public string? PosTender3Data { get; set; } 
 
    [XmlElement("CARD_TOKEN")]
    public string? CardToken { get; set; } 
  
    [XmlElement("HOST_RESPCODE")]
    public string? HostRespcode { get; set; } 

    [XmlElement("RESPONSE_CODE")]
    public string? ResponseCode { get; set; } 

    [XmlElement("MERCHID")]
    public string? MerchantId { get; set; }  

    [XmlElement("TERMID")]
    public string? TerminalId { get; set; }  

    [XmlElement("LANE")]
    public string? Lane { get; set; } 

    [XmlElement("TXN_POSENTRYMODE")]
    public string? TransactionPosEntryMode { get; set; }  

    [XmlElement("ROUTING_INDICATOR")]
    public string? RoutingIndicator { get; set; } 
  
    [XmlElement("PROMO_NEEDED")]
    public string? PromoNeeded { get; set; } 

    [XmlElement("PROMO_APR_FLAG")]
    public string? PromoAprFlag { get; set; } 

    [XmlElement("AFTER_PROMO_FLAG")]
    public string? AfterPromoFlag { get; set; } 

    [XmlElement("DURING_PROMO_APR")]
    public string? DuringPromoApr { get; set; } 

    [XmlElement("AFTER_PROMO_APR")]
    public string? AfterPromoApr { get; set; } 

    [XmlElement("PROMO_DURATION")]
    public string? PromoDuration { get; set; } 

    [XmlElement("PROMO_DESCRIPTION")]
    public string? PromoDescription { get; set; }

    [XmlElement("DCC_TRAN_AMOUNT")]
    public string? DccTranAmount { get; set; } 

    [XmlElement("DCC_EXCHANGE_RATE")]
    public string? DccExchangeRate { get; set; } 

    [XmlElement("DCC_ALPHA_CURR_CODE")]
    public string? DccAlphaCurrCode { get; set; }

    [XmlElement("DENIAL_REC_NUM")]
    public int? DenialRecNum { get; set; }  

    [XmlElement("RETURN_CHECK_FEE")]
    public decimal? ReturnCheckFee { get; set; }  

    [XmlElement("RETURN_CHECK_NOTE")]
    public string? ReturnCheckNote { get; set; }

    [XmlElement("INVOICE")]
    public string? Invoice { get; set; } 

    [XmlElement("CARD_ABBRV")]
    public string? CardAbbrv { get; set; }

    [XmlElement("EMV_TAG_4F")]
    public string? EmvTag4F { get; set; } 
    
    [XmlElement("EMV_TAG_50")]
    public string? EmvTag50 { get; set; } 
    
    [XmlElement("EMV_TAG_5F2A")]
    public string? EmvTag5F2A { get; set; } 
    
    [XmlElement("EMV_TAG_5F34")]
    public string? EmvTag5F34 { get; set; } 
    
    [XmlElement("EMV_TAG_82")]
    public string? EmvTag82 { get; set; } 
    
    [XmlElement("EMV_TAG_8A")]
    public string? EmvTag8A { get; set; } 
    
    [XmlElement("EMV_TAG_95")]
    public string? EmvTag95 { get; set; } 
    
    [XmlElement("EMV_TAG_9A")]
    public string? EmvTag9A { get; set; } 
    
    [XmlElement("EMV_TAG_9B")]
    public string? EmvTag9B { get; set; } 
    
    [XmlElement("EMV_TAG_9C")]
    public string? EmvTag9C { get; set; } 
    
    [XmlElement("EMV_TAG_9F02")]
    public string? EmvTag9F02 { get; set; } 
    
    [XmlElement("EMV_TAG_9F03")]
    public string? EmvTag9F03 { get; set; } 
    
    [XmlElement("EMV_TAG_9F07")]
    public string? EmvTag9F07 { get; set; } 
    
    [XmlElement("EMV_TAG_9F0D")]
    public string? EmvTag9F0D { get; set; } 
    
    [XmlElement("EMV_TAG_9F0E")]
    public string? EmvTag9F0E { get; set; } 
    
    [XmlElement("EMV_TAG_9F0F")]
    public string? EmvTag9F0F { get; set; } 
    
    [XmlElement("EMV_TAG_9F10")]
    public string? EmvTag9F10 { get; set; } 
    
    [XmlElement("EMV_TAG_9F1A")]
    public string? EmvTag9F1A { get; set; } 
    
    [XmlElement("EMV_TAG_9F26")]
    public string? EmvTag9F26 { get; set; } 
    
    [XmlElement("EMV_TAG_9F27")]
    public string? EmvTag9F27 { get; set; } 
    
    [XmlElement("EMV_TAG_9F34")]
    public string? EmvTag9F34 { get; set; } 
    
    [XmlElement("EMV_TAG_9F36")]
    public string? EmvTag9F36 { get; set; } 
    
    [XmlElement("EMV_TAG_9F37")]
    public string? EmvTag9F37 { get; set; } 
    
    [XmlElement("EMV_MODE")]
    public string? EmvMode { get; set; } 
    
    [XmlElement("EMV_CVM")]
    public string? EmvCvm { get; set; } 
    
    [XmlElement("EMV_CHIP_INDICATOR")]
    public string? EmvChipIndicator { get; set; } 
    
    [XmlElement("TAC_DEFAULT")]
    public string? TacDefault { get; set; } 
    
    [XmlElement("TAC_DENIAL")]
    public string? TacDenial { get; set; } 
    
    [XmlElement("TAC_ONLINE")]
    public string? TacOnline { get; set; } 
    
    [XmlElement("EMV_TAG_84")]
    public string? EmvTag84 { get; set; } 
    
    [XmlElement("EMV_TAG_9F21")]
    public string? EmvTag9F21 { get; set; } 
    
    [XmlElement("EMV_TAG_9F08")]
    public string? EmvTag9F08 { get; set; } 
    
    [XmlElement("EMV_TAG_9F09")]
    public string? EmvTag9F09 { get; set; } 
    
    [XmlElement("EMV_TAG_9F33")]
    public string? EmvTag9F33 { get; set; } 
    
    [XmlElement("EMV_TAG_9F35")]
    public string? EmvTag9F35 { get; set; } 
    
    [XmlElement("EMV_TAG_8E")]
    public string? EmvTag8E { get; set; } 
}