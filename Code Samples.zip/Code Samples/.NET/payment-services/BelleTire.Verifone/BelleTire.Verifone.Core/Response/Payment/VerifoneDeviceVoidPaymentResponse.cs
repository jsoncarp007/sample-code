using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Payment;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceVoidPaymentResponse : VerifoneDeviceResponse
{
    [XmlElement("TRAINING_MODE")]
    public string? TrainingMode { get; set; }

    [XmlElement("TRANS_SEQ_NUM")]
    public int? TransactionSequenceNumber { get; set; }  

    [XmlElement("INTRN_SEQ_NUM")]
    public int? InternalSequenceNumber { get; set; }  

    [XmlElement("TROUTD")]
    public string? Troutd { get; set; }  

    [XmlElement("CTROUTD")]
    public string? Ctroutd { get; set; }  

    [XmlElement("AUTH_CODE")]
    public string? AuthCode { get; set; }  

    [XmlElement("LPTOKEN")]
    public int? LpToken { get; set; }  

    [XmlElement("ACCT_NUM")]
    public string? AccountNumber { get; set; }  

    [XmlElement("CARD_EXP_MONTH")]
    public int? CardExpirationMonth { get; set; }  

    [XmlElement("CARD_EXP_YEAR")]
    public int? CardExpirationYear { get; set; }  

    [XmlElement("CARD_ENTRY_MODE")]
    public string? CardEntryMode { get; set; }  

    [XmlElement("EMV_REVERSAL_TYPE")]
    public int? EmvReversalType { get; set; }  

    [XmlElement("CARDHOLDER")]
    public string? Cardholder { get; set; }  

    [XmlElement("APPROVED_AMOUNT")]
    public decimal? ApprovedAmount { get; set; } 

    [XmlElement("AVAILABLE_BALANCE")]
    public decimal? AvailableBalance { get; set; } 

    [XmlElement("FS_AVAIL_BALANCE")]
    public decimal? FsAvailBalance { get; set; } 

    [XmlElement("CB_AVAIL_BALANCE")]
    public decimal? CbAvailBalance { get; set; } 

    [XmlElement("PAYMENT_MEDIA")]
    public string? PaymentMedia { get; set; }  

    [XmlElement("CARD_ABBRV")]
    public string? CardAbbreviation { get; set; }  

    [XmlElement("PAYMENT_TYPE")]
    public string? PaymentType { get; set; }  

    [XmlElement("PPCV")]
    public string? Ppcv { get; set; }  

    [XmlElement("EBT_TYPE")]
    public string? EbtType { get; set; }  

    [XmlElement("AUTH_RESP_CODE")]
    public string? AuthRespCode { get; set; }  

    [XmlElement("HOST_RESPCODE")]
    public string? HostRespCode { get; set; }  

    [XmlElement("RESPONSE_CODE")]
    public string? ResponseCode { get; set; }  

    [XmlElement("AUTHNWID")]
    public string? AuthNwId { get; set; }  

    [XmlElement("AUTHNWNAME")]
    public string? AuthNwName { get; set; }  

    [XmlElement("BANK_USERDATA")]
    public string? BankUserData { get; set; }  

    [XmlElement("SAF_NUM")]
    public string? SafNum { get; set; }  

    [XmlElement("MERCHID")]
    public string? MerchantId { get; set; }  

    [XmlElement("TERMID")]
    public string? TerminalId { get; set; }  

    [XmlElement("RECEIPT_DATA")]
    public string? ReceiptData { get; set; }  

    [XmlElement("TRANS_DATE")]
    public string? TransDate { get; set; }  

    [XmlElement("TRANS_TIME")]
    public string?TransTime { get; set; }  

    [XmlElement("BATCH_TRACE_ID")]
    public string? BatchTraceId { get; set; }  

    [XmlElement("TRACE_NUM")]
    public string? TraceNum { get; set; }  

    [XmlElement("REFERENCE")]
    public string? Reference { get; set; }  

    [XmlElement("POS_RECON")]
    public string? PosRecon { get; set; }  

    [XmlElement("VSP_CODE")]
    public string? VspCode { get; set; }  

    [XmlElement("VSP_RESULTDESC")]
    public string? VspResultDesc { get; set; }  

    [XmlElement("VSP_TRXID")]
    public string? VspTrxId { get; set; }  

    [XmlElement("STATUS_FLAG")]
    public string? StatusFlag { get; set; }  

    [XmlElement("ACTION_CODE")]
    public string? ActionCode { get; set; }  

    [XmlElement("SVC_PHONE")]
    public string? SvcPhone { get; set; }  

    [XmlElement("CREDIT_PLAN_NBR")]
    public string? CreditPlanNbr { get; set; }  

    [XmlElement("CARD_TOKEN")]
    public string? CardToken { get; set; }  

    [XmlElement("INVOICE")]
    public string? Invoice { get; set; }
    
}