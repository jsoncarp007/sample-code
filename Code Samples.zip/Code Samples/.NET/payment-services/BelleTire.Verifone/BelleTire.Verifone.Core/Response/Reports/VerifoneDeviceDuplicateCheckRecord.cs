﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Reports;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceDuplicateCheckRecord
{
    [XmlElement("Trans_Date")]
    public string? TransactionDate { get; set; }  //Type D, treat as string, 02.01.2017

    [XmlElement("Trans_Time")]
    public string? TransactionTime { get; set; }  //Type T, treat as string, 15:20:00

    [XmlElement("Client_ID")]
    public string? ClientId { get; set; }  //Type N, treat as string, 100010001

    [XmlElement("INTRN_SEQ_NUM")]
    public int? InternalSequenceNumber { get; set; }  //Type N

    [XmlElement("Acct_Num")]
    public string? AccountNumber { get; set; }  //Type N, treat as string, 400555******0019

    [XmlElement("Trans_Amount")]
    public int? TransactionAmount { get; set; }  //Type F, treat as N2, i.e. 100 = 1.00

    [XmlElement("Status_Code")]
    public int? StatusCode { get; set; }  //Type ?, treat as int, 4

    [XmlElement("Payment_Type")]
    public string? PaymentType { get; set; }  //Type C

    [XmlElement("Command")]
    public string? Command { get; set; }  //Type C

    [XmlElement("Invoice")]
    public string? Invoice { get; set; }  //Type C

    [XmlElement("BusName")]
    public string? BusinessName { get; set; }  //Type C
}