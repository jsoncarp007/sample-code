﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Reports;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceSettlementSummaryRecord
{
    [XmlElement("BATCH_SEQ_NUM")]
    public int? BatchSeqNum { get; set; } 

    [XmlElement("ERR_TRANS_IN_BATCH")]
    public int? ErrTransInBatch { get; set; }  

    [XmlElement("SETTLE_DATE")]
    public string? SettlementDate { get; set; }  

    [XmlElement("SETTLE_CODE")]
    public string? SettlementCode { get; set; }  

    [XmlElement("CRDT_SALE_AMT")]
    public decimal? CreditSaleAmount { get; set; }  

    [XmlElement("CRDT_SALE_CNT")]
    public int? CreditSaleCount { get; set; }  

    [XmlElement("CRDT_CRDT_AMT")]
    public decimal? CreditCreditAmount { get; set; } 

    [XmlElement("CRDT_CRDT_CNT")]
    public int? CreditCreditCount { get; set; }  

    [XmlElement("CRDT_VOID_AMT")]
    public decimal? CreditVoidAmount { get; set; }  

    [XmlElement("CRDT_VOID_CNT")]
    public int? CreditVoidCount { get; set; }
}