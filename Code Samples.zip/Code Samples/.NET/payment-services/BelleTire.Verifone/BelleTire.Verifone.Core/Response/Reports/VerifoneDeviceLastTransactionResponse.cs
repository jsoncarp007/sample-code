﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Reports;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceLastTransactionResponse : VerifoneDeviceResponse
{
    [XmlElement("TRANS_SEQ_NUM")]
    public int? TransactionSequenceNumber { get; set; }  

    [XmlElement("AUTH_CODE")]
    public string? AuthorizationCode { get; set; }

    [XmlElement("CTROUTD")]
    public long? Ctroutd { get; set; } 

    [XmlElement("POS_RECON")]
    public string? PosRecon { get; set; }  

    [XmlElement("PAYMENT_TYPE")]
    public string? PaymentType { get; set; } 

    [XmlElement("CARD_TOKEN")]
    public string? CardToken { get; set; } 

    [XmlElement("MERCHID")]
    public string? MerchantId { get; set; } 

    [XmlElement("TERMID")]
    public string? TerminalId { get; set; }

    [XmlElement("CLIENT_ID")]
    public string? ClientId { get; set; } 

    [XmlElement("APPROVED_AMOUNT")]
    public decimal? ApprovedAmount { get; set; } 

    [XmlElement("TRANS_AMOUNT")]
    public decimal? TransAmount { get; set; }  

    [XmlElement("PAYMENT_MEDIA")]
    public string? PaymentMedia { get; set; }  

    [XmlElement("ACCT_NUM")]
    public string? AcctNum { get; set; }  

    [XmlElement("CARDHOLDER")]
    public string? Cardholder { get; set; }  

    [XmlElement("CARD_EXP_MONTH")]
    public int? CardExpirationMonth { get; set; } 

    [XmlElement("CARD_EXP_YEAR")]
    public int? CardExpirationYear { get; set; }  

    [XmlElement("INVOICE")]
    public string? Invoice { get; set; }  

    [XmlElement("CARD_ENTRY_MODE")]
    public string? CardEntryMode { get; set; }  //Type C

    [XmlElement("CARD_ABBRV")]
    public string? CardAbbreviation { get; set; }  //Type C

    [XmlElement("COMMAND")]
    public string? Command { get; set; }  //Type C

    [XmlElement("INTRN_SEQ_NUM")]
    public int? InternalSequenceNumber { get; set; }  //Type N

    [XmlElement("TROUTD")]
    public long? Troutd { get; set; }  //Type N

    [XmlElement("TRANS_DATE")]
    public string? TransDate { get; set; }  //Type C

    [XmlElement("TRANS_TIME")]
    public string? TransTime { get; set; }  //Type C

    [XmlElement("STATUS_CODE")]
    public int? StatusCode { get; set; }  //Type N

    [XmlElement("REFERENCE")]
    public string? Reference { get; set; }  //Type C

    [XmlElement("SERVER_ID")]
    public string? ServerId { get; set; }  //Type C

    [XmlElement("VSP_TRXID")]
    public string? VspTrxid { get; set; }  //Type C

    [XmlElement()]
    public string? VspCode { get; set; }  //Type C

    [XmlElement("VSP_CODE")]
    public string? VspResultDesc { get; set; }  //Type C

    [XmlElement("SIGNATUREDATA")]
    public string? Signaturedata { get; set; }  //Type E, Base 64 encoded data

    [XmlElement("MIME_TYPE")]
    public string? MimeType { get; set; }  //Type C

    [XmlElement("RECEIPT_DATA")]
    public string? ReceiptData { get; set; }  //Type C

    [XmlElement("EMV_TAG_4F")]
    public string? EmvTag4F { get; set; }  //Type C

    [XmlElement("EMV_TAG_50")]
    public string? EmvTag50 { get; set; }  //Type C

    [XmlElement("EMV_TAG_5F2A")]
    public string? EmvTag5F2A { get; set; }  //Type C

    [XmlElement("EMV_TAG_5F34")]
    public string? EmvTag5F34 { get; set; }  //Type C

    [XmlElement("EMV_TAG_82")]
    public string? EmvTag82 { get; set; }  //Type C

    [XmlElement("EMV_TAG_8A")]
    public string? EmvTag8A { get; set; }  //Type C

    [XmlElement("EMV_TAG_95")]
    public string? EmvTag95 { get; set; }  //Type C

    [XmlElement("EMV_TAG_9A")]
    public string? EmvTag9A { get; set; }  //Type C

    [XmlElement("EMV_TAG_9B")]
    public string? EmvTag9B { get; set; }  //Type C

    [XmlElement("EMV_TAG_9C")]
    public string? EmvTag9C { get; set; }  //Type C

    [XmlElement("EMV_TAG_9F02")]
    public string? EmvTag9F02 { get; set; }  //Type C

    [XmlElement("EMV_TAG_9F03")]
    public string? EmvTag9F03 { get; set; }  //Type C

    [XmlElement("EMV_TAG_9F07")]
    public string? EmvTag9F07 { get; set; }  //Type C

    [XmlElement("EMV_TAG_9F0D")]
    public string? EmvTag9F0D { get; set; }  //Type C

    [XmlElement("EMV_TAG_9F0E")]
    public string? EmvTag9F0E { get; set; }  //Type C

    [XmlElement("EMV_TAG_9F0F")]
    public string? EmvTag9F0F { get; set; }  //Type C

    [XmlElement("EMV_TAG_9F10")]
    public string? EmvTag9F10 { get; set; }  //Type C

    [XmlElement("EMV_TAG_9F12")]
    public string? EmvTag9F12 { get; set; }  //Type C

    [XmlElement("EMV_TAG_9F1A")]
    public string? EmvTag9F1A { get; set; }  //Type C

    [XmlElement("EMV_TAG_9F26")]
    public string? EmvTag9F26 { get; set; }  //Type C

    [XmlElement("EMV_TAG_9F27")]
    public string? EmvTag9F27 { get; set; }  //Type C

    [XmlElement("EMV_TAG_9F34")]
    public string? EmvTag9F34 { get; set; }  //Type C

    [XmlElement("EMV_TAG_9F36")]
    public string? EmvTag9F36 { get; set; }  //Type C

    [XmlElement("EMV_TAG_9F37")]
    public string? EmvTag9F37 { get; set; }  //Type C

    [XmlElement("EMV_MODE")]
    public string? EmvMode { get; set; }  //Type C

    [XmlElement("EMV_CVM")]
    public string? EmvCvm { get; set; }  //Type C

    [XmlElement("EMV_CHIP_INDICATOR")]
    public string? EmvChipIndicator { get; set; }  //Type C

    [XmlElement("EMV_REVERSAL_TYPE")]
    public int? EmvReversalType { get; set; }  //Type N
}