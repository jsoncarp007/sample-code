﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Reports;

[XmlRoot("RECORD")]
public class VerifoneDeviceSummaryReportRecord
{
    [XmlElement("COMMAND")]
    public string? Command { get; set; } 

    [XmlElement("SALE_AMOUNT")]
    public decimal? SaleAmount { get; set; } 

    [XmlElement("TROUTD")]
    public long? Troutd { get; set; }

    [XmlElement("PAYMENT_TYPE")]
    public string? PaymentType { get; set; }

    [XmlElement("CASHBACK_AMNT")]
    public decimal? CashbackAmonunt { get; set; }

    [XmlElement("TIP_AMOUNT")]
    public decimal? TipAmount { get; set; }

    [XmlElement("CTROUTD")]
    public long? CTroutd { get; set; }

    [XmlElement("CHARGE_TOTAL")]
    public decimal? ChargeTotal { get; set; }

    [XmlElement("ITEMCOUNT")]
    public int? ItemCount { get; set; }
    
}