﻿using System.Xml.Serialization;
using BelleTire.Verifone.Core.Request.Report;

namespace BelleTire.Verifone.Core.Response.Reports;

[XmlRoot("RESPONSE")]
public class VerifoneDevicePreSettlementReportResponse : VerifoneDeviceResponse
{
    [XmlElement("CLIENT_ID")]
    public string? ClientId { get; set; } 

    [XmlElement("RETURN_FLD_HDRS")]
    public int? ReturnFldHdrs { get; set; }

    [XmlElement("FORMAT")]
    public string? Format { get; set; }

    [XmlElement("SERIAL_NUM")]
    public string? SerialNumber { get; set; }

    [XmlElement("COMMAND")]
    public string? Command { get; set; }

    [XmlElement("MAX_NUM_RECORDS_RETURNED")]
    public int? MaxNumberOfRecordsReturned { get; set; }

    [XmlElement("DEVICEKEY")]
    public string? DeviceKey { get; set; }

    [XmlElement("DEVTYPE")]
    public string? DevType { get; set; }

    [XmlElement("NUM_RECORDS_FOUND")]
    public int? NumberOfRecordsFound { get; set; }

    [XmlElement("SEARCHFIELDS")]
    public VerifoneDeviceReportSearchFields? SearchFields { get; set; }

    [XmlArray("RECORDS"), XmlArrayItem("RECORD", typeof(VerifoneDeviceSummaryReportRecord))]
    public List<VerifoneDeviceSummaryReportRecord>? RecordList { get; set; }
    
    [XmlElement("BATCH_TRACE_ID")]
    public string? BatchTraceId { get; set; }
}

public class VerifoneDeviceTransactionSearchRecord
    {
        [XmlElement("INTRN_SEQ_NUM")]
        public int? IntrnSeqNum { get; set; } 

        [XmlElement("PROCESSOR_ID")]
        public string? ProcessorId { get; set; } 

        [XmlElement("BATCH_SEQ_NUM")]
        public int? BatchSeqNum { get; set; } 

        [XmlElement("TRANS_SEQ_NUM")]
        public string? TransSeqNum { get; set; } 

        [XmlElement("INVOICE")]
        public string? Invoice { get; set; }

        [XmlElement("COMMAND")]
        public string? Command { get; set; } 

        [XmlElement("ACCT_NUM")]
        public string? AcctNum { get; set; } 

        [XmlElement("EXP_MONTH")]
        public int? ExpMonth { get; set; } 

        [XmlElement("EXP_YEAR")]
        public int? ExpYear { get; set; }

        [XmlElement("CARDHOLDER")]
        public string? Cardholder { get; set; } 

        [XmlElement("TRANS_AMOUNT")]
        public decimal? TransAmount { get; set; } 

        [XmlElement("REFERENCE")]
        public string? Reference { get; set; } 

        [XmlElement("TRANS_DATE")]
        public string? TransDate { get; set; } 

        [XmlElement("TRANS_TIME")]
        public string? TransTime { get; set; }

        [XmlElement("ORIG_SEQ_NUM")]
        public int? OrigSeqNum { get; set; }

        [XmlElement("STATUS_CODE")]
        public int? StatusCode { get; set; }

        [XmlElement("TROUTD")]
        public long? Troutd { get; set; } 

        [XmlElement("CTROUTD")]
        public long? Ctroutd { get; set; }

        [XmlElement("PAYMENT_TYPE")]
        public string? PaymentType { get; set; }

        [XmlElement("PAYMENT_MEDIA")]
        public string? PaymentMedia { get; set; }

        [XmlElement("RESULT_CODE")]
        public int? ResultCode { get; set; }

        [XmlElement("AUTH_CODE")]
        public string? AuthCode { get; set; }

        [XmlElement("AVS_CODE")]
        public string? AvsCode { get; set; }

        [XmlElement("CVV2_CODE")]
        public string? Cvv2Code { get; set; }

        [XmlElement("TRACE_CODE")]
        public string? TraceCode { get; set; } 

        [XmlElement("CASHBACK_AMNT")]
        public decimal? CashbackAmnt { get; set; }

        [XmlElement("TIP_AMOUNT")]
        public decimal? TipAmount { get; set; }

        [XmlElement("RESPONSE_REFERENCE")]
        public string? ResponseReference { get; set; } 

        [XmlElement("R_AUTH_CODE")]
        public string? RAuthCode { get; set; } 
    }