﻿using System.Xml.Serialization;
using BelleTire.Verifone.Core.Request.Report;

namespace BelleTire.Verifone.Core.Response.Reports;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceDailySettlementSummaryReportResponse : VerifoneDeviceResponse
{
    [XmlElement("CLIENT_ID")]
    public string? ClientId { get; set; }  

    [XmlElement("RETURN_FLD_HDRS")]
    public int? ReturnFldHdrs { get; set; }  

    [XmlElement("FORMAT")]
    public string? Format { get; set; }  

    [XmlElement("SERIAL_NUM")]
    public string? SerialNum { get; set; }  

    [XmlElement("COMMAND")]
    public string? Command { get; set; } 

    [XmlElement("MAX_NUM_RECORDS_RETURNED")]
    public int? MaxNumberOfRecordsReturned { get; set; }  

    [XmlElement("DEVICEKEY")]
    public string? DeviceKey { get; set; } 

    [XmlElement("DEVTYPE")]
    public string? DevType { get; set; } 

    [XmlElement("NUM_RECORDS_FOUND")]
    public int? NumberOfRecordsFound { get; set; } 

    [XmlElement("START_SETTLE_DATE")]
    public string? StartSettleDate { get; set; }  

    [XmlElement("END_SETTLE_DATE")]
    public string? EndSettleDate { get; set; }  

    [XmlElement("SEARCHFIELDS")]
    public VerifoneDeviceReportSearchFields? SearchFields { get; set; } 
    
    [XmlArray("RECORDS"), XmlArrayItem("RECORD", typeof(VerifoneDeviceSettlementSummaryRecord))]
    public List<VerifoneDeviceSettlementSummaryRecord>? RecordList { get; set; }
}