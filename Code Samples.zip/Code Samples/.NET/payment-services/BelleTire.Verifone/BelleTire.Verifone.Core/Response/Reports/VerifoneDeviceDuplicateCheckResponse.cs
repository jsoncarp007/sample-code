﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Reports;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceDuplicateCheckResponse : VerifoneDeviceResponse
{
    [XmlElement("CLIENT_ID")]
    public string? ClientId { get; set; }

    [XmlElement("DUPCHECK_DATE")]
    public string? DuplicateCheckDate { get; set; }

    [XmlElement("DUPCHECK_FROMTIME")]
    public string? DuplicateCheckFromTime { get; set; }

    [XmlElement("DUPCHECK_TOTIME")]
    public string? DuplicateCheckToTime { get; set; } 
    
    [XmlArray("RECORDS"), XmlArrayItem("RECORD", typeof(VerifoneDeviceDuplicateCheckRecord))]
    public List<VerifoneDeviceDuplicateCheckRecord>? RecordList { get; set; }
}