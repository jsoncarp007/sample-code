﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Reports;

[XmlRoot("RESPONSE")]
public class VerisignDeviceSettlementErrorRecord
{
    [XmlElement("INTRN_SEQ_NUM")]
    public int? InternalSequenceNumber { get; set; }

    [XmlElement("PROCESSOR_ID")]
    public string? ProcessorId { get; set; } 

    [XmlElement("BATCH_SEQ_NUM")]
    public int? BatchSequenceNumber { get; set; } 

    [XmlElement("TRANS_SEQ_NUM")]
    public string? TransactionSequenceNumber { get; set; }  

    [XmlElement("INVOICE")]
    public string? Invoice { get; set; } 

    [XmlElement("COMMAND")]
    public string? Command { get; set; } 

    [XmlElement("ACCT_NUM")]
    public string? AccountNumber { get; set; }  

    [XmlElement("EXP_MONTH")]
    public int? ExpirationMonth { get; set; } 

    [XmlElement("EXP_YEAR")]
    public int? ExpirationYear { get; set; } 

    [XmlElement("CARDHOLDER")]
    public string? Cardholder { get; set; }  

    [XmlElement("TRANS_AMOUNT")]
    public decimal? TransactionAmount { get; set; }  

    [XmlElement("REFERENCE")]
    public string? Reference { get; set; } 

    [XmlElement("TRANS_DATE")]
    public string? TransactionDate { get; set; }

    [XmlElement("TRANS_TIME")]
    public string? TransactionTime { get; set; }

    [XmlElement("ORIG_SEQ_NUM")]
    public int? OriginalSequenceNumber { get; set; } 

    [XmlElement("STATUS_CODE")]
    public int? StatusCode { get; set; }

    [XmlElement("TROUTD")]
    public long? Troutd { get; set; }

    [XmlElement("CTROUTD")]
    public long? CTroutd { get; set; }

    [XmlElement("PAYMENT_TYPE")]
    public string? PaymentType { get; set; } 

    [XmlElement("PAYMENT_MEDIA")]
    public string? PaymentMedia { get; set; } 

    [XmlElement("RESULT_CODE")]
    public int? ResultCode { get; set; } 

    [XmlElement("AUTH_CODE")]
    public string? AuthorizationCode { get; set; }  

    [XmlElement("AVS_CODE")]
    public string? AvsCode { get; set; }  

    [XmlElement("CVV2_CODE")]
    public string? Cvv2Code { get; set; }  

    [XmlElement("TRACE_CODE")]
    public string? TraceCode { get; set; }  

    [XmlElement("RESPONSE_REFERENCE")]
    public string? ResponseReference { get; set; }

    [XmlElement("R_AUTH_CODE")]
    public string? RAuthCode { get; set; }
}