﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.SecondaryPort;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceCancelResponse : VerifoneDeviceSecondaryPortResponse
{
    [XmlElement("DETAILED_STATUS")]
    public int? DetailedStatus { get; set; }
}