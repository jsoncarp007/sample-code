﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.SecondaryPort;

[XmlRoot("RESPONSE")]
public abstract class VerifoneDeviceSecondaryPortResponse : VerifoneDeviceResponse
{
    [XmlElement("SECONDARY_DATA")]
    public int? SecondaryData { get; set; }

    [XmlElement("POS_RECON")]
    public string? PosRecon { get; set; }
}