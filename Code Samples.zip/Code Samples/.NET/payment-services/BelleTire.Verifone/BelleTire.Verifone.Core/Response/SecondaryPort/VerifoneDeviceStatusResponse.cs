﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.SecondaryPort;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceStatusResponse : VerifoneDeviceSecondaryPortResponse
{
    [XmlElement("DETAILED_STATUS")]
    public int? DetailedStatus { get; set; }        //Type N

    [XmlElement("MACLABEL_IN_SESSION")]
    public string? MacLabelInSession { get; set; }   //Type C

    [XmlElement("SESSION_DURATION")]
    public string? SessionDuration { get; set; }     //Type C

    [XmlElement("INVOICE_SESSION")]
    public string? InvoiceSession { get; set; }      //Type C

    [XmlElement("DEVICENAME")]
    public string? DeviceName { get; set; }           //Type C

    [XmlElement("SERIAL_NUMBER")]
    public string? SerialNumber { get; set; }        //Type C
}