﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.SecondaryPort;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceRebootResponse : VerifoneDeviceSecondaryPortResponse
{
}