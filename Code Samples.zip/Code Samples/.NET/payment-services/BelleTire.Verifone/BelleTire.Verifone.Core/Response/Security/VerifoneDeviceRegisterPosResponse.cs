﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Security;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceRegisterPosResponse : VerifoneDeviceResponse
{
    [XmlElement("MAC_KEY")]
    public string? MacKey { get; set; } 

    [XmlElement("MAC_LABEL")]
    public string? MacLabel { get; set; }

    [XmlElement("ENTRY_CODE")]
    public string? EntryCode { get; set; }
}