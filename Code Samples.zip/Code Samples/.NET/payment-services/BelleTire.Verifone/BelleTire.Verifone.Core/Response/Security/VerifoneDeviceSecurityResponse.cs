using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Security;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceSecurityResponse : VerifoneDeviceResponse {}