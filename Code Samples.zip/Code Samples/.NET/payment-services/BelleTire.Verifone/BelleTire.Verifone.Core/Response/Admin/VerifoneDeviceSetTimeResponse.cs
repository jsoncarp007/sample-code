﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Admin;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceSetTimeResponse : VerifoneDeviceResponse
{
    [XmlElement("TIME")]
    public string? Time { get; set; }
}