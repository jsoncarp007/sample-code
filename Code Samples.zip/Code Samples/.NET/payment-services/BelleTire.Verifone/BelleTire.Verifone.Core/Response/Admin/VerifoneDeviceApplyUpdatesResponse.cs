﻿using System.Xml.Serialization;

namespace BelleTire.Verifone.Core.Response.Admin;

[XmlRoot("RESPONSE")]
public class VerifoneDeviceApplyUpdatesResponse : VerifoneDeviceResponse { }