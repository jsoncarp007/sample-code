namespace BelleTire.Verifone.Core;

public class CardData
{
    public string? DataTrack1 { get; set; }
    public string? DataTrack2 { get; set; }
    public string? DataTrack3 { get; set; }
    public string? AccountNumber { get; set; }
   
    public int? ExpirationMonth { get; set; }
    public int? ExpirationYear { get; set; }
}