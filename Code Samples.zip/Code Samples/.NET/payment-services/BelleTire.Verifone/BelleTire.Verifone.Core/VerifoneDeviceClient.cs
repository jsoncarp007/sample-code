﻿using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;

namespace BelleTire.Verifone.Core;

public class VerifoneDeviceClient : IDisposable
{
    public string DeviceIp { get; }
    public int Port { get; }

    private TcpClient _tcpClient;

    /// <summary>
    /// TCP Client Wrapper for communicating with Verifone credit card devices 
    /// </summary>
    /// <param name="deviceIp">IP Address</param>
    /// <param name="port">Port - default primary = 5015, secondary = 5016</param>
    public VerifoneDeviceClient(string deviceIp, int port = 5015)
    {
        DeviceIp = deviceIp;
        Port = port;
    }

    /// <summary>
    /// Sends an XML document string to the device and returns the XML string response
    /// </summary>
    /// <param name="requestXml">Request XML string</param>
    /// <returns>XML string response</returns>
    public async Task<string> SendRequestAsync(string requestXml)
    {
        _tcpClient = new TcpClient();
        await _tcpClient.ConnectAsync(DeviceIp, Port);
        
        var stream = _tcpClient.GetStream();
        
        var sendBuffer = Encoding.UTF8.GetBytes(requestXml);
        stream.Write(sendBuffer,0, sendBuffer.Length);

        var receiveBuffer = new byte[8000];
        while (!stream.DataAvailable)
            Thread.Sleep(100);
        
        var bytesReceived = await stream.ReadAsync(receiveBuffer, 0, 8000).ConfigureAwait(false);
        
        _tcpClient.Dispose();

        return Encoding.Default.GetString(receiveBuffer, 0, bytesReceived);
    }

    public void Disconnect()
    {
        _tcpClient.Client.Disconnect(true);
    }

    public void Dispose()
    {
        Disconnect();
        _tcpClient.Dispose();
    }
}