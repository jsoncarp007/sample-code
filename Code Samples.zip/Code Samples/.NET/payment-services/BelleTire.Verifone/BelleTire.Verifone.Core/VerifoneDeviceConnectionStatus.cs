namespace BelleTire.Verifone.Core;

public enum VerifoneDeviceConnectionStatus
{
    ReadyToReceiveRequests,
    Busy,
    Unreachable,
    NotReady,
    Disconnected
}