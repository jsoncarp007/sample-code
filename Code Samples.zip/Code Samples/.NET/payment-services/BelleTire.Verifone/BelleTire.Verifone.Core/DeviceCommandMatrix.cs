﻿using Microsoft.VisualBasic;

namespace BelleTire.Verifone.Core;

public class DeviceCommandMatrix
{
    public IEnumerable<DeviceFunctionType> DeviceFunctionTypes =>
        Enum.GetValues(typeof(DeviceFunctionType)).Cast<DeviceFunctionType>();

    public IEnumerable<DeviceCommand> GetDeviceCommands(DeviceFunctionType functionType) => functionType switch
    {
        DeviceFunctionType.Device => new[]
        {
            DeviceCommand.CancelDisplayLeftPanel, DeviceCommand.CancelQrCode, DeviceCommand.Charity,
            DeviceCommand.TokenQuery, DeviceCommand.Checkbox, DeviceCommand.CustomerButton,
            DeviceCommand.CustomerQuestion,
            DeviceCommand.Survey10, DeviceCommand.Survey5, DeviceCommand.Survey, DeviceCommand.DisplayImage,
            DeviceCommand.DisplayLeftPanel,
            DeviceCommand.DisplayMessage, DeviceCommand.EmailCapture, DeviceCommand.GetCardData,
            DeviceCommand.GetDeviceName, DeviceCommand.GetParameters,
            DeviceCommand.GetPaymentTypes, DeviceCommand.Loyalty, DeviceCommand.ProvisionPass,
            DeviceCommand.QueryNfcIni, DeviceCommand.CreditApplication,
            DeviceCommand.Version, DeviceCommand.SetDeviceName, DeviceCommand.SetParameter, DeviceCommand.Signature,
            DeviceCommand.SignatureExpanded
        },
        DeviceFunctionType.LineItem => new[]
            {DeviceCommand.Add, DeviceCommand.Remove, DeviceCommand.RemoveAll, DeviceCommand.Show},
        DeviceFunctionType.Admin => new[]
        {
            DeviceCommand.ApplyUpdates, DeviceCommand.GetCounter, DeviceCommand.LaneClosed, DeviceCommand.SetTime,
            DeviceCommand.StoreAndForward
        },
        DeviceFunctionType.Payment => new[]
        {
            DeviceCommand.Authorize, DeviceCommand.Capture, DeviceCommand.Credit, DeviceCommand.Void,
            DeviceCommand.Token
        },
        DeviceFunctionType.Report => new[]
        {
            DeviceCommand.DailySummary, DeviceCommand.PreSettlement, DeviceCommand.DuplicateCheck,
            DeviceCommand.LastTransaction,
            DeviceCommand.SettlementErrors, DeviceCommand.SettlementSummary, DeviceCommand.TransactionSearch
        },
        DeviceFunctionType.SecondaryPort => new[]
        {
            DeviceCommand.Cancel, DeviceCommand.Reboot, DeviceCommand.Status, DeviceCommand.AnyUpdates,
            DeviceCommand.UpdateStatus
        },
        DeviceFunctionType.Security => new[]
        {
            DeviceCommand.RegisterEncryptionPos, DeviceCommand.RegisterPos, DeviceCommand.TestMac,
            DeviceCommand.UnregisterAllPos, DeviceCommand.UnregisterPos
        },
        DeviceFunctionType.Session => new[] {DeviceCommand.Finish, DeviceCommand.Start},
        DeviceFunctionType.Batch => new[] {DeviceCommand.Settle},
        _ => throw new ArgumentOutOfRangeException(nameof(functionType), functionType, null)
    };

    public string GetCommandStringValueForDeviceCommand(DeviceCommand deviceCommand) => deviceCommand switch
    {
        DeviceCommand.CancelDisplayLeftPanel => "CANCELDISPLP",
        DeviceCommand.CancelQrCode => "CANCEL_QRCODE",
        DeviceCommand.Charity => "CHARITY",
        DeviceCommand.TokenQuery => "TOKEN_QUERY",
        DeviceCommand.Checkbox => "CHECKBOX",
        DeviceCommand.CustomerButton => "CUST_BUTTON",
        DeviceCommand.CustomerQuestion => "CUST_QUESTION",
        DeviceCommand.Survey10 => "SURVEY10",
        DeviceCommand.Survey5 => "SURVEY5",
        DeviceCommand.Survey => "SURVEY",
        DeviceCommand.DisplayImage => "DISPLAY_IMAGE",
        DeviceCommand.DisplayLeftPanel => "DISPLAY_LEFTPANEL",
        DeviceCommand.DisplayMessage => "DISPLAY_MESSAGE",
        DeviceCommand.EmailCapture => "EMAIL",
        DeviceCommand.GetCardData => "GET_CARD_DATA",
        DeviceCommand.GetDeviceName => "GET_DEVICENAME",
        DeviceCommand.GetParameters => "GET_PARAM",
        DeviceCommand.GetPaymentTypes => "GET_PAYMENT_TYPES",
        DeviceCommand.Loyalty => "LOYALTY",
        DeviceCommand.ProvisionPass => "PROVISION_PASS",
        DeviceCommand.QueryNfcIni => "QUERY_NFCINI",
        DeviceCommand.CreditApplication => "CREDIT_APP",
        DeviceCommand.Version => "VERSION",
        DeviceCommand.SetDeviceName => "SET_DEVICENAME",
        DeviceCommand.SetParameter => "SET_PARAM",
        DeviceCommand.Signature => "SIGNATURE",
        DeviceCommand.SignatureExpanded => "SIGNATURE_EX",
        DeviceCommand.Add => "ADD",
        DeviceCommand.Remove => "REMOVE",
        DeviceCommand.RemoveAll => "REMOVEALL",
        DeviceCommand.Show => "SHOW",
        DeviceCommand.ApplyUpdates => "APPLYUPDATES",
        DeviceCommand.GetCounter => "GET_COUNTER",
        DeviceCommand.LaneClosed => "LANE_CLOSED",
        DeviceCommand.SetTime => "SETTIME",
        DeviceCommand.StoreAndForward => "SAF",
        DeviceCommand.Authorize => "AUTH",
        DeviceCommand.Capture => "CAPTURE",
        DeviceCommand.Credit => "CREDIT",
        DeviceCommand.Void => "VOID",
        DeviceCommand.Token => "TOKEN_QUERY",
        DeviceCommand.DailySummary => "DAYSUMMARY",
        DeviceCommand.PreSettlement => "PRESETTLEMENT",
        DeviceCommand.DuplicateCheck => "DUPCHECK",
        DeviceCommand.LastTransaction => "LAST_TRAN",
        DeviceCommand.SettlementErrors => "SETTLEERROR",
        DeviceCommand.SettlementSummary => "SETTLESUMMARY",
        DeviceCommand.TransactionSearch => "TRANSEARCH",
        DeviceCommand.Cancel => "CANCEL",
        DeviceCommand.Reboot => "REBOOT",
        DeviceCommand.Status => "STATUS",
        DeviceCommand.AnyUpdates => "ANY_UPDATES",
        DeviceCommand.UpdateStatus => "UPDATE_STATUS",
        DeviceCommand.RegisterEncryptionPos => "REGISTER_ENCRYPTION",
        DeviceCommand.RegisterPos => "REGISTER",
        DeviceCommand.TestMac => "TEST_MAC",
        DeviceCommand.UnregisterAllPos => "UNREGISTERALL",
        DeviceCommand.UnregisterPos => "UNREGISTER",
        DeviceCommand.Finish => "FINISH",
        DeviceCommand.Start => "START",
        DeviceCommand.Settle => "SETTLE",
        _ => throw new ArgumentOutOfRangeException(nameof(deviceCommand), deviceCommand, null)
    };

    public string GetCommandStringValueForFunctionType(DeviceFunctionType functionType) => functionType switch
    {
        DeviceFunctionType.Device => "DEVICE",
        DeviceFunctionType.LineItem => "LINE_ITEM",
        DeviceFunctionType.Admin => "ADMIN",
        DeviceFunctionType.Payment => "PAYMENT",
        DeviceFunctionType.Report => "REPORT",
        DeviceFunctionType.SecondaryPort => "SECONDARYPORT",
        DeviceFunctionType.Security => "SECURITY",
        DeviceFunctionType.Session => "SESSION",
        DeviceFunctionType.Batch => "BATCH",
        _ => throw new ArgumentOutOfRangeException(nameof(functionType), functionType, null)
    };

    public string GetDeviceFunctionTypeNameForCommand(DeviceCommand deviceCommand)
    {
        var functionType = GetDeviceFunctionTypeForCommand(deviceCommand);
        return GetCommandStringValueForFunctionType(functionType);
    }
    
    public DeviceFunctionType GetDeviceFunctionTypeForCommand(DeviceCommand deviceCommand)
    {
        foreach (var functionType in DeviceFunctionTypes)
        {
            if (GetDeviceCommands(functionType).Contains(deviceCommand))
                return functionType;
        }

        return DeviceFunctionType.Admin;
    }




}