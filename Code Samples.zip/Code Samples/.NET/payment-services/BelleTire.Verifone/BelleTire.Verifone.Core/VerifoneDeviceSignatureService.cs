﻿using BelleTire.Verifone.Core.Request;
using BelleTire.Verifone.Core.Response.Transactions;

namespace BelleTire.Verifone.Core;

public class VerifoneDeviceSignatureService
{
    public SignatureComplete SignatureCompleted;
    public delegate void SignatureComplete(bool confirmed, string signatureData);
    
    private readonly IVerifoneDeviceService _deviceService;
    private readonly VerifoneDeviceSignatureRequestFactory _deviceSignatureRequestFactory;
    
    public VerifoneDeviceSignatureService(IVerifoneDeviceService deviceService, 
        VerifoneDeviceSignatureRequestFactory deviceSignatureRequestFactory)
    {
        _deviceService = deviceService;
        _deviceSignatureRequestFactory = deviceSignatureRequestFactory;
    }
    
    public async Task RequestSignature(string promptText)
    {
        var request =
            _deviceSignatureRequestFactory.GetSignatureRequest(promptText);

        var response = await _deviceService.ExecuteRequestAsync(request).ConfigureAwait(false);
        var displayQuestionResponse = (VerifoneDeviceSignatureResponse) response.DeviceResponse!;

        SignatureCompleted?.Invoke(response.Success,displayQuestionResponse.SignatureData);
    }
}