﻿namespace BelleTire.Verifone.Core;

public enum DeviceCommand
{

    // Device
    CancelDisplayLeftPanel, // CANCELDISPLP
    CancelQrCode, // CANCEL_QRCODE
    Charity, // CHARITY
    TokenQuery, // TOKEN_QUERY
    Checkbox, // CHECKBOX
    CustomerButton, // CUST_BUTTON
    CustomerQuestion, // CUST_QUESTION
    Survey10, // SURVEY10
    Survey5, // SURVEY5
    Survey, // SURVEY
    DisplayImage, // DISPLAY_IMAGE
    DisplayLeftPanel, // DISPLAY_LEFTPANEL
    DisplayMessage, // DISPLAY_MESSAGE
    EmailCapture, // EMAIL
    GetCardData, // GET_CARD_DATA
    GetDeviceName, // GET_DEVICENAME
    GetParameters, // GET_PARM
    GetPaymentTypes, // GET_PAYMENT_TYPES
    Loyalty, // LOYALTY
    ProvisionPass, // PROVISION_PASS
    QueryNfcIni, // QUERY_NFCINI
    CreditApplication, // CREDIT_APP
    Version, // VERSION
    SetDeviceName, // SET_DEVICENAME
    SetParameter, // SET_PARM
    Signature, // SIGNATURE
    SignatureExpanded, // SIGNATURE_EX
    
    // Line Item
    Add, // ADD
    Remove, // REMOVE
    RemoveAll, // REMOVEALL
    Show, // SHOW
    
    // Admin
    ApplyUpdates, // APPLYUPDATES
    GetCounter, // GET_COUNTER
    LaneClosed, // LANE_CLOSED
    SetTime, // SETTIME
    StoreAndForward, // SAF
    
    // Payment
    Authorize, // AUTH
    Capture, // CAPTURE
    Credit, // CREDIT
    Void, // VOID
    Token, // TOKEN_QUERY
    
    // Reports
    DailySummary, // DAYSUMMARY
    PreSettlement, // PRESETTLEMENT
    DuplicateCheck, // DUPCHECK
    LastTransaction, // LAST_TRAN
    SettlementErrors, // SETTLEERROR
    SettlementSummary, // SETTLESUMMARY
    TransactionSearch, //TRANSEARCH
    
    // Secondary Port
    Cancel, // CANCEL
    Reboot, // REBOOT
    Status, // STATUS
    AnyUpdates, // ANY_UPDATES
    UpdateStatus, // UPDATE_STATUS
    
    // Security
    RegisterEncryptionPos, // REGISTER_ENCRYPTION
    RegisterPos, // REGISTER
    TestMac, // TEST_MAC
    UnregisterAllPos, // UNREGISTERALL
    UnregisterPos, // UNREGISTER
    
    // Session
    Finish, // FINISH
    Start, // START
    
    // Batch    
    Settle, // SETTLE

}