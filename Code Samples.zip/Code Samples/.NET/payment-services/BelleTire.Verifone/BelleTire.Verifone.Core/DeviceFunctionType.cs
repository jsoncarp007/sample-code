﻿namespace BelleTire.Verifone.Core;

public enum DeviceFunctionType 
{
    Device,
    LineItem,
    Admin,
    Payment,
    Report,
    SecondaryPort,
    Security,
    Session,
    Batch
}