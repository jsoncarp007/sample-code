﻿using BelleTire.FreedomPay.CustomerAccount.Core.Services;
using BelleTire.PaymentServices.Core.Requests;
using BelleTire.PaymentServices.Core.Responses;
using BelleTire.PaymentServices.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BelleTire.PaymentServices.Api.Controllers
{
    [Route("[controller]"), Authorize]
    [ApiController]
    public class AccountLookupController : ControllerBase
    {
        private readonly ICustomerAccountService _customerAccountService;
        private readonly ITransactionService _transactionService;

        public AccountLookupController(ICustomerAccountService customerAccountService,
            ITransactionService transactionService)
        {
            _customerAccountService = customerAccountService;
            _transactionService = transactionService;
        }

        [HttpPost("by-account-number")]
        public async Task<AccountLookupResponse> ExecuteAccountLookup(AccountLookupByAccountNumberRequest accountLookupRequest)
        {
            var lookupResult = await
                _transactionService.AccountLookupByAccountNumberAsync(accountLookupRequest).ConfigureAwait(false);

            return new AccountLookupResponse(lookupResult.TransactionResult,
                lookupResult.RequestUniqueId, lookupResult.AccountToken,
                lookupResult.ResultDetails);
        }

        [HttpPost("by-ssn-phone")]
        public async Task<AccountLookupResponse> ExecuteAccountLookup(AccountLookupBySsnAndPhoneRequest accountLookupRequest)
        {
            var transactionSource = accountLookupRequest.TransactionSource;
            var phoneAsLong = Convert.ToInt64(new string(accountLookupRequest.phone.Where(char.IsNumber).ToArray()));
            var lookupResult = await _customerAccountService.AccountLookupAsync(
                    Convert.ToInt32(transactionSource.StoreId),
                    Convert.ToUInt32(transactionSource.TerminalId), phoneAsLong,
                    Convert.ToInt16(accountLookupRequest.ssn4), accountLookupRequest.zipCode, 0, "USA",
                    transactionSource.UserId)
                .ConfigureAwait(false);

            var id = lookupResult.SearchRecordRefNbr;

            return new AccountLookupResponse(TransactionResult.Success, id, string.Empty);
        }
    }
}
