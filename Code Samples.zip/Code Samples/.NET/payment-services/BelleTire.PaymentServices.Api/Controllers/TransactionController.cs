using BelleTire.PaymentServices.Core.Requests;
using BelleTire.PaymentServices.Core.Responses;
using BelleTire.PaymentServices.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BelleTire.PaymentServices.Api.Controllers
{
    [ApiController, Route("[controller]"), Authorize]
    public class TransactionController : ControllerBase
    {
        private readonly ITransactionService _transactionService;
        
        public TransactionController(ITransactionService transactionService)
        {
            _transactionService = transactionService;
        }

        [HttpPost("process-sale")]
        public async Task<TransactionResponse> ProcessSale(PromotionSaleTransaction promotionSaleTransaction)
        {
            return await _transactionService.ProcessTransactionAsync(promotionSaleTransaction);
        }

        [HttpGet("process-sale-complete/{referenceId}/{orderNumber}")]
        public async Task<TransactionFinalizeResponse> FinalizeSale(string referenceId, int orderNumber)
        {
            return await _transactionService.FinalizeTransaction(referenceId, orderNumber);
        }
        
        [HttpPost("cancel-sale")]
        public async Task<TransactionCancellationResponse> CancelSale(CancelSaleRequestDto cancelSaleRequestDto)
        {
            return await _transactionService.CancelTransaction(cancelSaleRequestDto);
        }

    }
}