using BelleTire.PaymentServices.Core.Requests;
using BelleTire.PaymentServices.Core.Responses;
using BelleTire.PaymentServices.Infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BelleTire.PaymentServices.Api.Controllers;

[ApiController]
[Route("[controller]"), Authorize]
public class PromotionLookupController : ControllerBase
{
    private readonly IPromotionLookupService _promotionLookupService;
    private readonly ILogger<PromotionLookupController> _logger;

    public PromotionLookupController(IPromotionLookupService promotionLookupService, ILogger<PromotionLookupController> logger)
    {
        _promotionLookupService = promotionLookupService;
        _logger = logger;
    }
    
    [HttpPost("get-available-promotions")]
    public async Task<PromotionOptionsLookupResponse> GetAvailablePromotions(PromotionOptionsLookupRequest promotionOptionsLookupRequest)
    {
        _logger.LogInformation("GetAvailablePromotions: Request from {IpAddress}, Request: {RequestData} ", Request.HttpContext.Connection.RemoteIpAddress, promotionOptionsLookupRequest);
        var response = await _promotionLookupService.GetPromotionOptionsAsync(promotionOptionsLookupRequest);

        return response;
    }
}