using BelleTire.FreedomPay.Core;
using BelleTire.FreedomPay.CustomerAccount.Core.Interfaces;
using BelleTire.FreedomPay.CustomerAccount.Core.Services;
using BelleTire.PaymentServices.Infrastructure;
using BelleTire.PaymentServices.Infrastructure.TransactionProcessing.FreedomPay;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using BelleTire.Logging;
using BelleTire.PaymentServices.Infrastructure.Repository;
using BelleTire.PaymentServices.Infrastructure.Repository.FreedomPay;
using BelleTire.PaymentServices.Infrastructure.Repository.FreedomPay.DbContext;
using IBM.Data.Db2;
using IBM.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Serilog.Events;
using Serilog;

BTLog.InitializeSplunkLogging("PaymentServicesApi");
BTLog.Logger.Write(LogEventLevel.Debug, $"Payment Services API starting on {Environment.MachineName}");

var certificateId = "00b2ac46698e922a6a";

var builder = WebApplication.CreateBuilder(args);

BTLog.InitializeSplunkLogging(
    applicationName: "Payment Services API", 
    minimumLogLevel: default,
    environmentName: builder.Environment.EnvironmentName);

BTLog.Logger.Debug("Payment Services API starting on {MachineName}", Environment.MachineName);

builder.Host.UseSerilog();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var connection = builder.Configuration["DbConnectionString"];
builder.Services.AddDbContext<InformixDbContext>(options => 
options.UseDb2(connection, d => d.SetServerInfo(IBMDBServerType.IDS)));
builder.Services.AddTransient<Serilog.ILogger>(l => BTLog.Logger);
builder.Services.AddTransient<InformixDbContext>();
builder.Services.AddTransient<ISqlQueryFactory, SqlQueryFactory>();
builder.Services.AddTransient<IFreedomPayTenderRepository, FreedomPayTenderRepository>();

// Transaction Service Http Client
builder.Services.AddHttpClient<ITransactionService, FreedomPayTransactionService>(client => client.BaseAddress = new Uri("https://cs.uat.freedompay.com/"))
    .ConfigurePrimaryHttpMessageHandler(() => new FreedomPayHttpClientFactory().GetFreedomPayHttpClientHandler(certificateId));

// Credit Account Service Http Client
builder.Services.AddHttpClient("CreditAccountServicesClient", client => client.BaseAddress = new Uri("https://creditaccountservices.uat.freedompay.com/api/"))
    .ConfigurePrimaryHttpMessageHandler(() => new FreedomPayHttpClientFactory().GetFreedomPayHttpClientHandler(certificateId));

builder.Services.AddTransient<ICustomerAccountService, CustomerAccountService>(ctx =>
{
    var clientFactory = ctx.GetRequiredService<IHttpClientFactory>();
    var httpClient = clientFactory.CreateClient("CreditAccountServicesClient");
    var contextOptionsBuilder = new DbContextOptionsBuilder<FreewayContext>();
    contextOptionsBuilder.UseDb2(connection, d => d.SetServerInfo(IBMDBServerType.IDS));
    var freewayContext = new FreewayContext(contextOptionsBuilder.Options);
   
    var repo = new CustomerAccountRepository(freewayContext);
    return new CustomerAccountService(httpClient, certificateId, repo);
});

// Promotion Lookup Service Client
builder.Services.AddHttpClient("PromotionLookupServiceClient", client => client.BaseAddress = new Uri("https://cs.uat.freedompay.com/"))
    .ConfigurePrimaryHttpMessageHandler(() => new FreedomPayHttpClientFactory().GetFreedomPayHttpClientHandler(certificateId));

builder.Services.AddTransient<IPromotionLookupService, FreedomPayPromotionLookupService>(lookupService =>
{
    var clientFactory = lookupService.GetRequiredService<IHttpClientFactory>();
    var httpClient = clientFactory.CreateClient("PromotionLookupServiceClient");
    return new FreedomPayPromotionLookupService(httpClient);
});

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(options =>
{
    options.Authority = "https://belletire.us.auth0.com/";
    options.Audience = "paymentservices.belletire.com";
});

builder.Services.AddCors(options =>
{
    options.AddPolicy("DefaultCorsPolicy", policy =>
    {
        policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader();
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors("DefaultCorsPolicy");
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

BTLog.Logger.Debug("Payment Services Startup Complete on {MAchineName}", Environment.MachineName);

app.Run();
