window.setDocTitle = () => {
    var pageTitle = document.getElementById("page-title")
    pageTitle.innerText = document.title;
    console.log(document.title)
};