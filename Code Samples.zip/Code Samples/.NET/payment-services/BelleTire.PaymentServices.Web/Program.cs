using BelleTire.PaymentServices.Client;
using BelleTire.PaymentServices.Infrastructure.Repository;
using BelleTire.PaymentServices.Infrastructure.Repository.CardDevices;
using BelleTire.PaymentServices.Infrastructure.Repository.FreedomPay;
using BelleTire.PaymentServices.Infrastructure.Repository.PosTender;
using BelleTire.Verifone.Core;
using BelleTire.Verifone.Core.Request;
using BelleTire.Verifone.Core.Response;
using Microsoft.AspNetCore.Authentication.Negotiate;
using IBM.EntityFrameworkCore;
using IdentityModel.Client;
using Radzen;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme)
    .AddNegotiate();

builder.Services.AddAuthorization(options =>
{
    // By default, all incoming requests will be authorized according to the default policy.
    options.FallbackPolicy = options.DefaultPolicy;
});

builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

var prodMode = false;
var connection = prodMode ? "Server=nelle.belletire.com:48510;User ID=winpos;password=belle;Database=co_01;" : "Server=trainer.belletire.com:48509;User ID=winpos;password=belle;Database=co_01;";

var services = builder.Services;
services.AddAccessTokenManagement(options =>
{
    options.Client.Clients.Add("payment_services_auth0", new ClientCredentialsTokenRequest
    {
        Address = $"https://belletire.us.auth0.com/oauth/token",
        ClientId = "iXF9V5nlC7wJGaxgfHnCAWK6Mkx8lQcG",
        ClientSecret = "QgfUXIDaP_qWpjtFZyZKV-uYTxTGJAyYTfehVwV5QN5_2t_xlk_-OJ5LPCwVoeTF",
        GrantType = "client_credentials",
        ClientCredentialStyle = ClientCredentialStyle.PostBody,
        Parameters = { { "audience", "paymentservices.belletire.com" } }
    });
});

builder.Services.AddHttpClient<IPaymentServicesClient, PaymentServicesClient>(client => client.BaseAddress = new Uri("https://testpaymentservices.belletire.com"))
    .AddClientAccessTokenHandler("payment_services_auth0");

builder.Services.AddDbContext<InformixDbContext>(options => options.UseDb2(connection, d => d.SetServerInfo(IBMDBServerType.IDS)));
builder.Services.AddTransient<ISqlQueryFactory, SqlQueryFactory>();

builder.Services.AddTransient<IPosTenderRepository, PosTenderRepository>();
builder.Services.AddTransient<IFreedomPayTenderRepository, FreedomPayTenderRepository>();
builder.Services.AddTransient<ICreditCardDeviceRepository, CreditCardDeviceRepository>();

builder.Services.AddScoped<NotificationService>();
builder.Services.AddScoped<DialogService>();
builder.Services.AddScoped<ContextMenuService>();
builder.Services.AddScoped<DeviceCommandMatrix>();
builder.Services.AddScoped<VerifoneDeviceRequestFactory>();
builder.Services.AddScoped<VerifoneDeviceResponseFactory>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();