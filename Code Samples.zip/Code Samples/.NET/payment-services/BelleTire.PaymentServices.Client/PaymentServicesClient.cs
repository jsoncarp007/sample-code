﻿using BelleTire.Microservice.Client;
using BelleTire.PaymentServices.Core.Requests;
using BelleTire.PaymentServices.Core.Responses;

namespace BelleTire.PaymentServices.Client;

public class PaymentServicesClient : IPaymentServicesClient
{
    private readonly RefreshTokenMicroserviceClient _client;
    private TransactionSource? _transactionSource;
    public bool TransactionSourceSet => _transactionSource != null;

    public PaymentServicesClient(RefreshTokenMicroserviceClient client)
    {
        _client = client;
    }

    public void SetTransactionSource(TransactionSource transactionSource)
    {
        _transactionSource = transactionSource;
    }

    public void SetTransactionSource(string terminalId, string storeId, int storeNumber, string userId)
    {
        _transactionSource = new TransactionSource(storeNumber, storeId, Environment.MachineName, terminalId, userId);
    }

    public async Task<PromotionOptionsLookupResponse> GetPromotionOptionsAsync(AccountDataSource accountDataSource, string accountNumber, string cvv, decimal transactionAmount)
    {
        var account = new CreditCardAccountData(accountDataSource, accountNumber, 12, 49, cvv, string.Empty);
        return await GetPromotionOptionsAsync(accountDataSource, account, transactionAmount);
    }

    public async Task<PromotionOptionsLookupResponse> GetPromotionOptionsAsync(AccountDataSource accountDataSource, CreditCardAccountData creditCardAccountData, decimal transactionAmount)
    {
        var promotionOptionsRequest = new PromotionOptionsLookupRequest(_transactionSource, creditCardAccountData, transactionAmount);
        
        using var response = await _client.PostAsJsonAsync("promotionlookup/get-available-promotions", promotionOptionsRequest).ConfigureAwait(false);
        response.EnsureSuccessStatusCode();

        return await response.Content.ReadAsAsync<PromotionOptionsLookupResponse>();
    }

    public async Task<TransactionResponse> ProcessSaleTransactionAsync(CreditCardAccountData creditCardAccountData, AccountDataSource accountDataSource, CustomerData customerData, decimal transactionAmount, string orderNumber, string promotionId)
    {
        var saleTransaction = new PromotionSaleTransaction(_transactionSource, accountDataSource, creditCardAccountData, customerData, transactionAmount, orderNumber, promotionId);

        using var response = await _client.PostAsJsonAsync("transaction/process-sale", saleTransaction).ConfigureAwait(false);
        response.EnsureSuccessStatusCode();

        return await response.Content.ReadAsAsync<TransactionResponse>();
    }

    public async Task<TransactionFinalizeResponse> FinalizeTransactionAsync(string referenceId, int orderNumber)
    {
        var httpRequest = new HttpRequestMessage(HttpMethod.Get, $"transaction/process-sale-complete/{referenceId}/{orderNumber}");
        using var response = await _client.SendAsync(httpRequest).ConfigureAwait(false);
        response.EnsureSuccessStatusCode();

        return await response.Content.ReadAsAsync<TransactionFinalizeResponse>();
    }

    public async Task<TransactionCancellationResponse> CancelTransactionAsync(string referenceId, decimal transactionAmount)
    {
        var cancelSaleRequestDto = new CancelSaleRequestDto()
        {
            ReferenceId = referenceId, TransactionSource = _transactionSource, TransactionAmount = transactionAmount
        };
        
        using var response = await _client.PostAsJsonAsync("Transaction/cancel-sale", cancelSaleRequestDto).ConfigureAwait(false);
        response.EnsureSuccessStatusCode();
        
        return await response.Content.ReadAsAsync<TransactionCancellationResponse>();
    }

    public async Task<AccountLookupResponse> LookupAccountAsync(string ssn4, string phone, int idType, string idState, string idNumber, string zipCode)
    {
        var accountLookupRequest =
            new AccountLookupBySsnAndPhoneRequest(_transactionSource, ssn4, phone, idType, idState, idNumber, zipCode);
        
        using var response = await _client.PostAsJsonAsync("accountlookup/by-ssn-phone", accountLookupRequest).ConfigureAwait(false);
        response.EnsureSuccessStatusCode();

        return await response.Content.ReadAsAsync<AccountLookupResponse>();
    }

}