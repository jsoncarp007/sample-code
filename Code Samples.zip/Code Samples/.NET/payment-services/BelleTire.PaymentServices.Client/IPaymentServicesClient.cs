﻿using BelleTire.PaymentServices.Core.Requests;
using BelleTire.PaymentServices.Core.Responses;

namespace BelleTire.PaymentServices.Client;

public interface IPaymentServicesClient
{
    bool TransactionSourceSet { get; }
    void SetTransactionSource(TransactionSource transactionSource);
    void SetTransactionSource(string terminalId, string storeId, int storeNumber, string userId);
    Task<PromotionOptionsLookupResponse> GetPromotionOptionsAsync(AccountDataSource accountDataSource, string accountNumber, string cvv, decimal transactionAmount);
    Task<PromotionOptionsLookupResponse> GetPromotionOptionsAsync(AccountDataSource accountDataSource, CreditCardAccountData creditCardAccountData, decimal transactionAmount);
    Task<TransactionResponse> ProcessSaleTransactionAsync(CreditCardAccountData creditCardAccountData, AccountDataSource accountDataSource, CustomerData customerData, decimal transactionAmount, string orderNumber, string promotionId);
    Task<TransactionFinalizeResponse> FinalizeTransactionAsync(string referenceId, int orderNumber);
    Task<TransactionCancellationResponse> CancelTransactionAsync(string referenceId, decimal transactionAmount);
    Task<AccountLookupResponse> LookupAccountAsync(string ssn4, string phone, int idType, string idState, string idNumber, string zipCode);
}