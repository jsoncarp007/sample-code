﻿namespace BelleTire.PaymentServices.Core.Responses;

public enum TransactionResult
{
    /// <summary>
    /// Transaction was successfully completed
    /// </summary>
    Success,
    
    /// <summary>
    /// Transaction failed, but nothing further needs to be done
    ///
    /// Ex. Void transaction that was already voided
    /// </summary>
    NonCriticalError,
    
    /// <summary>
    /// The transaction was declined and has been flagged as possibly fraudulent 
    /// </summary>
    PossibleFraud,
    
    /// <summary>
    /// The card/account data is correct, but the transaction was declined
    ///
    /// Ex. Insufficient funds, inactive card/account, etc
    /// </summary>
    TransactionDeclined,
    
    /// <summary>
    /// The card/account failed validation
    ///
    /// Ex. CVV mismatch, wrong PIN, address mismatch, invalid card/account number etc
    /// </summary>
    ValidationFailed,
    
    /// <summary>
    /// There was a problem with request data
    ///
    /// Ex. Invalid characters, out of range values, etc
    /// </summary>
    RequestDataError,
    
    /// <summary>
    /// A problem occurred during authorization 
    /// </summary>
    AuthorizationError,
    
    /// <summary>
    /// The transaction was already submitted
    /// </summary>
    DuplicateTransaction,
    
    /// <summary>
    /// There was a problem with the card data captured by the card reader
    /// </summary>
    CardReaderDataError,

    /// <summary>
    /// There was an error returned that needs to be reviewed by IT
    ///
    /// Ex, FreedomPay provisioning problem, request structure was invalid, etc
    /// </summary>
    FatalError,
    
    /// <summary>
    /// There was an error returned that indicated something occured on FreedomPay's end that
    /// is temporary and the transaction can/should be retried 
    /// </summary>
    TemporaryError,
    
    /// <summary>
    /// The transaction requires the selection of a promotion (i.e. financing terms) and they were
    /// not included in the request 
    /// </summary>
    PromotionSelectionMissing
}

public record TransactionResponse(TransactionResult TransactionResult, string RequestUniqueId, string MerchantCode, decimal TransactionAmount, string OrderNumber, string? ResultDetails, string? AccountToken, PromotionOption? SelectedPromotionDetails = null);
public record TransactionVoidReverseResponse(bool Success, string ResponseDetail);