﻿namespace BelleTire.PaymentServices.Core.Responses;

public record AccountLookupResponse(TransactionResult TransactionResult, string RequestUniqueId, string? AccountToken = null, string? ResultDetails = null);