namespace BelleTire.PaymentServices.Core.Responses;

public class TransactionCancellationResponse
{
    public string? ReferenceId { get; set; }
    public bool Success { get; set; }
    public decimal TransactionAmount { get; set; }
    public string? ResponseText { get; set; }
}