namespace BelleTire.PaymentServices.Core.Responses;

public class PromotionOption
{
    public PromotionOption(string promotionId, string description, decimal threshold, decimal interestRate, string? disclaimer)
    {
        PromotionId = promotionId;
        Description = description;
        Threshold = threshold;
        InterestRate = interestRate;
        Disclaimer = disclaimer;
    }

    public string PromotionId { get; set; }
    public string Description { get; set; }
    public decimal Threshold { get; set; }
    public decimal InterestRate { get; set; }
    public string? Disclaimer { get; set; }
}