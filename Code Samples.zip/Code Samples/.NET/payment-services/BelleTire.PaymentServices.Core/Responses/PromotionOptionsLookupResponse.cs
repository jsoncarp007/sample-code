﻿namespace BelleTire.PaymentServices.Core.Responses;

public record PromotionOptionsLookupResponse(bool Success, IList<PromotionOption>? AvailablePromotionOptions, string? ErrorDetails = null);