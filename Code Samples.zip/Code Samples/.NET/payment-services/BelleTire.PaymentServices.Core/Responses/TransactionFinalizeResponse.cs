﻿namespace BelleTire.PaymentServices.Core.Responses;

public class TransactionFinalizeResponse
{
    public bool Success { get; set; }
    public string? ResponseText { get; set; }
    public int OrderNumber { get; set; }
    public string? ReferenceId { get; set; }
    public decimal TotalTransacted { get; set; }
}