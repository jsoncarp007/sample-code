﻿namespace BelleTire.PaymentServices.Core.Requests;

// Source
public enum AccountDataSource { CardReader, ManualEntered, WebCustomerEntered, AccountLookup }

public record TransactionSource(int StoreNumber, string StoreId, string WorkstationId, string TerminalId, string UserId);

// Account
public record AccountData(AccountDataSource AccountDataSource, string AccountNumber);

public record CreditCardAccountData(AccountDataSource AccountDataSource, string AccountNumber, int ExpirationMonth, int ExpirationYear, string? Cvv, string? CardholderName) 
    : AccountData(AccountDataSource, AccountNumber);

public record DebitCardAccountData(AccountDataSource AccountDataSource, string AccountNumber, int Pin) 
    : AccountData(AccountDataSource, AccountNumber);

// Customer
public record CustomerData(string? FirstName, string? LastName, string? Address1, string? Address2, string? City, string? State, string? Zip, string? Country);

// Transaction
public record Transaction(TransactionSource? TransactionSource);

public record VoidTransaction(TransactionSource? TransactionSource, string ReferenceId, string OrderNumber, decimal TransactionAmount) 
    : Transaction(TransactionSource);

public record RefundTransaction(TransactionSource? TransactionSource, string ReferenceId, string OrderNumber, decimal TransactionAmount, decimal? RefundAmount) 
    : Transaction(TransactionSource);

public record AuthorizationTransaction(TransactionSource? TransactionSource, AccountDataSource AccountDataSource, CreditCardAccountData CreditCardAccountData, CustomerData? CustomerData, decimal TransactionAmount, string OrderNumber, string? PromotionId)
    : Transaction(TransactionSource);

public record SaleTransaction(TransactionSource? TransactionSource, AccountDataSource AccountDataSource, CreditCardAccountData CreditCardAccountData, CustomerData? CustomerData, decimal TransactionAmount, string OrderNumber)
    : Transaction(TransactionSource);

public record PromotionSaleTransaction(TransactionSource? TransactionSource, AccountDataSource AccountDataSource, CreditCardAccountData CreditCardAccountData, CustomerData? CustomerData, decimal TransactionAmount, string OrderNumber, string PromotionId) 
    : SaleTransaction(TransactionSource, AccountDataSource, CreditCardAccountData, CustomerData, TransactionAmount, OrderNumber);
  
