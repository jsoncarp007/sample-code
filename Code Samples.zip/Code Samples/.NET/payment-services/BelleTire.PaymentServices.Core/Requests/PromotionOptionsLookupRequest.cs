﻿namespace BelleTire.PaymentServices.Core.Requests;

public record PromotionOptionsLookupRequest(TransactionSource? TransactionSource, CreditCardAccountData AccountData, decimal PurchaseAmount);

