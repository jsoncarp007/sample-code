﻿namespace BelleTire.PaymentServices.Core.Requests;

public record AccountLookupByAccountNumberRequest(TransactionSource TransactionSource, CreditCardAccountData AccountData, CustomerData CustomerData) : Transaction(TransactionSource);
public record AccountLookupBySsnAndPhoneRequest(TransactionSource TransactionSource, string ssn4, string phone, int idType, string idState, string idNumber, string zipCode) : Transaction(TransactionSource);



