﻿namespace BelleTire.PaymentServices.Core.Requests;

public class CancelSaleRequestDto
{
    public TransactionSource? TransactionSource { get; set; }
    public string? ReferenceId { get; set; }
    public string? OrderNumber { get; set; }
    public decimal TransactionAmount { get; set; }
}