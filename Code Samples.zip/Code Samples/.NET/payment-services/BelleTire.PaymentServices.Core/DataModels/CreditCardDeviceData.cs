﻿namespace BelleTire.PaymentServices.Core.DataModels;

public class CreditCardDeviceData
{
    public int? DeviceId { get; set; }
    public string? IpAddress { get; set; }
    public string? SerialNumber { get; set; }
    public string? MacLabel { get; set; }
    public string? MacKey { get; set; }
    public int? Port { get; set; }
    public int? StoreNumber { get; set; }
    public string? Location { get; set; }
    public string? Description { get; set; }
    public string? DeviceBrand { get; set; }
    public string? DeviceModel { get; set; }
    public string? CreditCardProcessorKey { get; set; }
    public string? Status { get; set; }
}