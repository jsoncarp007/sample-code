﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace BelleTire.PaymentServices.Core.DataModels;

[Table("pos_tender")]
public class PosTender
{
    [DisplayName("Expiration Date")]
    [Column("exp_date")]
    public string? ExpirationDate { get; set; }
    
    [DisplayName("Type")]
    [Column("t_ype")]
    public string? TransactionType { get; set; }
    
    [Column("order_num")]
    [DisplayName("Order Number")]
    public int OrderNumber { get; set; }
    
    [DisplayName("Transaction #")]
    [Column("l_ine")]
    public int OrderTenderId { get; set; }
    
    [DisplayName("Reference")]
    [Column("reference")]
    public string? ReferenceId { get; set; }

    [DisplayName("Description")]
    [Column("descr")]
    public string? Description { get; set; }
    
    [DisplayName("Auth")]
    [Column("auth_approv")]
    public string? AuthApproval { get; set; }

    [DisplayName("Tender Date")]
    [Column("tender_date")]
    public string? TenderDate { get; set; }
    
    [DisplayName("User")]
    [Column("salesman")]
    public string? Salesman { get; set; }
    
    [DisplayName("OS Flag")]
    [Column("os_flag")]
    public string? OsFlag { get; set; }
    
    [DisplayName("Amount Tendered")]
    [Column("amt_tendered")]
    public decimal AmountTendered { get; set; }

    [DisplayName("Drawer")]
    [Column("drawer_ctl")]
    public int Drawer { get; set; }
    
    [DisplayName("Paid Out")]
    [Column("paid_out")]
    public decimal PaidOut { get; set; }
    
}