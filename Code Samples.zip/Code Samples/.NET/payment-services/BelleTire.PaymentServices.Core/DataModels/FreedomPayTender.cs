﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BelleTire.PaymentServices.Core.DataModels;

[Table("hps_tender")]
public class FreedomPayTender 
{
	[Column("action_cd")]
	public string? Action { get; set; }
	
	[Column("amt1")]
	public decimal? Amount1 { get; set; }
	
	[Column("amt2")]
	public decimal? Amount2 { get; set; }
	
	[Column("approval_cd")]
	public string? ApprovalCode { get; set; }
	
	[Column("apr")]
	public decimal? Apr { get; set; }
	
	[Column("apr_type")]
	public string? AprType { get; set; }
	
	[Column("avs_result_cd")]
	public string? AvsResultCode { get; set; }
	
	[Column("batch_num")]
	public int? BatchNumber { get; set; }
	
	[Column("card_num")]
	public string? CardNumber { get; set; }
	
	[Column("card_num_enc")]
	public string? CardNumberEncrypted { get; set; }
	
	[Column("cc_cardtype_cd")]
	public string? CreditCardType { get; set; }
	
	[Column("cc_merchant_id")]
	public int? CreditCardMerchantId { get; set; }
	
	[Column("create_dtm")]
	public DateTime Created { get; set; }
	
	[Column("credit_plan")]
	public string? CreditPlan { get; set; }
	
	[Column("cvv_result_cd")]
	public string? CvvResultCode { get; set; }
	
	[Column("drawer_ctl")]
	public int? DrawerControl { get; set; }
	
	[Column("expir_dt_enc")]
	public string? ExpiratonDateEncrypted { get; set; }
	
	[Column("hps_balance_id")]
	public int? HpsBalanceId { get; set; }
	
	[Key]
	[Column("hps_tender_id")]
	public int? HpsTenderId { get; set; }
	
	[Column("item_num")]
	public int? ItemNum { get; set; }
	
	[Column("l_ine")]
	public int? OrderTransactionNumber { get; set; }
	
	[Column("order_num")]
	public int? OrderNumber { get; set; }
	
	[Column("pos_entry_mode")]
	public string? PosEntryMode { get; set; }
	
	[Column("processing_cd")]
	public string? ProcessingCode { get; set; }
	
	[Column("reference")]
	public string? Reference { get; set; }
	
	[Column("sys_trace_audit_num")]
	public int? SysTraceAuditNumber { get; set; }
	
	[Column("transaction_type")]
	public string? TransactionType { get; set; }
	
	[Column("void_reverse")]
	public string? VoidReverse { get; set; }
	
}