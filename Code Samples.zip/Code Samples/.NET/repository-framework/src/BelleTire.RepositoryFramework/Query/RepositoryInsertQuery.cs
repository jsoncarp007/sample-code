﻿using System;
using System.Collections.Generic;
using System.Linq;
using BelleTire.RepositoryFramework.Core;
using BelleTire.RepositoryFramework.Interface;
using BelleTire.RepositoryFramework.Query.Parameter;

namespace BelleTire.RepositoryFramework.Query
{
    public class RepositoryInsertQuery : RepositoryQuery
    {
        private List<string> ColumnsToInclude { get; }
        private RepositorySelectQuery InsertFromSelectQuery { get; }

        internal RepositoryInsertQuery(string baseSql, IDatabaseMappedObject objectToUpdate) : base(baseSql)
        {
            QueryParameters = objectToUpdate.GetMappedObjectValues().Select(m => new RepositoryQueryParameter(m.Key, m.Value, 0)).ToList();
        }

        internal RepositoryInsertQuery(string baseSql, IEnumerable<RepositoryQueryParameter> queryParameters) 
            : base(baseSql, queryParameters.ToList())
        {
        }

        internal RepositoryInsertQuery(string baseSql, RepositoryQueryParameter queryParameter) 
            : base(baseSql, queryParameter)
        {
        }

        internal RepositoryInsertQuery(IRepositoryQueryEntityDefinition insertEntityDefinition, RepositorySelectQuery selectQuery) 
            : this(insertEntityDefinition.EntityName, insertEntityDefinition.ColumnNames, selectQuery)
        {
        }

        internal RepositoryInsertQuery(string insertIntoEntityName, IEnumerable<string> columnsToInsert, RepositorySelectQuery selectQuery)
            : base($"INSERT INTO {insertIntoEntityName}")
        {
            ColumnsToInclude = columnsToInsert.ToList();
            InsertFromSelectQuery = selectQuery;
        }

        internal RepositoryInsertQuery(IRepositoryQueryEntityDefinition insertEntityDefinition, IEnumerable<string> columnsToInsert, RepositorySelectQuery selectQuery)
            : this(insertEntityDefinition.EntityName, columnsToInsert, selectQuery)
        {
        }

        internal override void SetDataProviderFormatting(IRepositoryDataProviderFormatting formatting)
        {
            base.SetDataProviderFormatting(formatting);

            InsertFromSelectQuery?.SetDataProviderFormatting(Formatting);
        }

        protected override void PreGetQueryParameters()
        {
            if (InsertFromSelectQuery != null)
            {
                QueryParameters.Clear();
                QueryParameters.AddRange(InsertFromSelectQuery.GetQueryParameters());
            }
        }

        protected override string GetQueryText()
        {
            return InsertFromSelectQuery == null ? 
                GetQueryTextSingleInsert() : 
                GetQueryTextSelectInsert();
        }

        private string GetQueryTextSingleInsert()
        {
            if (QueryParameters.Count < 1)
                throw new Exception("Must have at least one value to insert");

            string sql = BaseSql + " ";

            string fieldListString = string.Join(",", QueryParameters.Select(p => p.SourceColumnIdentifier));

            string questionMarkString = string.Join(",", QueryParameters.Select(p => "?"));

            sql += $" ({fieldListString}) ";
            sql += $" VALUES ({questionMarkString}) ";

            return sql;
        }

        private string GetQueryTextSelectInsert()
        {
            string fieldListString = string.Join(",", ColumnsToInclude);

            string sql = BaseSql + " ";
            sql += $" ({fieldListString}) ";
            sql += InsertFromSelectQuery.Query;
            return sql;
        }
    }
}
