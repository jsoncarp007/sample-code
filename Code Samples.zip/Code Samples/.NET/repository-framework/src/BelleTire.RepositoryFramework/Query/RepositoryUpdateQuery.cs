﻿using System.Collections.Generic;
using System.Linq;
using BelleTire.RepositoryFramework.Interface;
using BelleTire.RepositoryFramework.Query.ConditionalQuery.MatchCondition;
using BelleTire.RepositoryFramework.Query.Parameter;

namespace BelleTire.RepositoryFramework.Query
{
    public class RepositoryUpdateQuery : RepositoryConditionalQuery
    {
        protected List<RepositoryQueryParameter> UpdateParameters { get; set; }

        private bool _updateParametersInserted = false;

        internal RepositoryUpdateQuery(string baseSql, IDatabaseMappedObject objectToUpdate) : base(baseSql, objectToUpdate)
        {
            UpdateParameters = new List<RepositoryQueryParameter>();
            var keyFieldName = objectToUpdate.GetMappedObjectKeyFieldColumnName();
            UpdateParameters.AddRange(objectToUpdate.GetMappedObjectValues().Where(mov=>mov.Key != keyFieldName).Select(m=>new RepositoryQueryParameter(m.Key, m.Value,0)));
        }

        internal RepositoryUpdateQuery(string baseSql, RepositoryQueryMatchCondition matchCondition) 
            : this(baseSql, new List<RepositoryQueryMatchCondition> {matchCondition}, new List<RepositoryQueryParameter>())
        {
        }

        internal RepositoryUpdateQuery(string baseSql, IEnumerable<RepositoryQueryMatchCondition> matchConditions) 
            : this(baseSql, matchConditions, new List<RepositoryQueryParameter>())
        {
        }

        internal RepositoryUpdateQuery(string baseSql, RepositoryQueryMatchCondition matchCondition, RepositoryQueryParameter updateParameter)
            : this(baseSql, new List<RepositoryQueryMatchCondition> {matchCondition}, new List<RepositoryQueryParameter> { updateParameter })
        {
        }

        internal RepositoryUpdateQuery(string baseSql, RepositoryQueryMatchCondition matchCondition, IEnumerable<RepositoryQueryParameter> updateParameters) 
            : this(baseSql, new [] {matchCondition}, updateParameters)
        {
        }

        internal RepositoryUpdateQuery(string baseSql, IEnumerable<RepositoryQueryMatchCondition> matchConditions, RepositoryQueryParameter updateParameter) 
            : this(baseSql, matchConditions, new [] { updateParameter })
        {
        }

        internal RepositoryUpdateQuery(string baseSql, IEnumerable<RepositoryQueryParameter> queryParameters)
            : this(baseSql, new RepositoryQueryMatchCondition[] {}, queryParameters)
        {
        }

        internal RepositoryUpdateQuery(string baseSql, IEnumerable<RepositoryQueryMatchCondition> matchConditions, IEnumerable<RepositoryQueryParameter> updateParameters) 
            : base(baseSql, matchConditions)
        {
            UpdateParameters = updateParameters.ToList();
        }


        protected override void PreGetQueryParameters()
        {
            // add update query params (before where parameters)
            if (!_updateParametersInserted)
            {
                QueryParameters.InsertRange(0, UpdateParameters);
                _updateParametersInserted = true;
            }

            base.PreGetQueryParameters();
        }

        protected override string ModifyBaseQuery(string baseQuery)
        {
            return baseQuery;
        }

        protected override string GetPreWhereSqlString()
        {
            if (UpdateParameters.Count == 0)
                return string.Empty;

            return "SET " + string.Join(",", 
                       UpdateParameters.Select(p=>
                           $"{p.SourceColumnIdentifier}=?"));
        }

        protected override string GetPostWhereSqlString()
        {
            return string.Empty;
        }
    }
}
