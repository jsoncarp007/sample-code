﻿using System;
using System.Collections.Generic;
using System.Linq;
using BelleTire.RepositoryFramework.Extensions;

namespace BelleTire.RepositoryFramework.Query
{
    public class RepositoryQueryNameBuilder
    {
        public string QueryName { get; set; }

        private string _queryBody;

        public RepositoryQueryNameBuilder(string queryBody)
        {
            _queryBody = queryBody;

            BuildQueryName();
        }

        private void BuildQueryName()
        {
            RemoveFormattingCharacters();

            if (BuildFromStoredProcedureName()) return; // query is already a stored procedure

            BuildQueryNamePrefix();

            BuildSelectFirst();

            bool hasCount = BuildCount();

            if (!hasCount)
            {
                BuildTableName();
            }

            BuildColumnNames();

            Trim();
        }

        private bool BuildFromStoredProcedureName()
        {
            if (_queryBody.ToUpper().StartsWith("EXEC"))
            {
                // get the procedure name from the end of the sql text

                int storedProcedureNameBegins = _queryBody.LastIndexOf(" ");
                int storedProcedureParamOpen = _queryBody.LastIndexOf("(");

                if (storedProcedureParamOpen < 0)
                    storedProcedureParamOpen = _queryBody.Length;

                QueryName = _queryBody
                    .Substring(storedProcedureNameBegins, storedProcedureParamOpen - storedProcedureNameBegins).Trim();

                return true;
            }

            return false;
        }

        private void Trim()
        {
            QueryName = new string(QueryName.Take(128).ToArray());
        }

        private void BuildColumnNames()
        {
            int indexOfWhereStart = _queryBody.IndexOf(" WHERE ");

            string secondHalf = indexOfWhereStart > -1
                ? _queryBody.Substring(indexOfWhereStart)
                    .Replace("(", string.Empty)
                    .Replace(")", string.Empty)
                    .Replace("*", string.Empty)
                : string.Empty;

            // find everything with a '.' in it after WHERE
            var filterColumnNames = secondHalf.Contains(".")
                ? secondHalf
                    .Split(' ')
                    .Where(s => s.Contains('.'))
                    .Select(s => s.Split('.')[1])
                    .Distinct().ToList()
                : new List<string>();

            if (filterColumnNames.Any())
                QueryName += "_by_" + string.Join("_and_", filterColumnNames);
        }

        private void BuildTableName()
        {
            //int indexOfWhereStart = _queryBody.IndexOf(" WHERE ");
            int indexOfFromStart = _queryBody.IndexOf(" FROM ");

            //string firstHalf = _queryBody
            //    .Substring(0, indexOfWhereStart > -1 ? indexOfWhereStart : indexOfFromStart > -1 ? indexOfFromStart : _queryBody.Length)
            //    .Replace("(", string.Empty)
            //    .Replace(")", string.Empty)
            //    .Replace("*", string.Empty);

            //// find everything with a '.' in it before WHERE
            //var tableNames = firstHalf.Contains(".")
            //    ? firstHalf
            //        .Split(' ')
            //        .Where(s => s.Contains('.'))
            //        .Select(s => s.Split('.')[0])
            //        .Distinct()
            //    : new List<string>();

            // use the primary (first) table name

            var queryStartingAtFromEnd = _queryBody.Substring(indexOfFromStart+6);
            var indexOfEndOfPrimaryTableName = queryStartingAtFromEnd.IndexOf(" ");

            QueryName += queryStartingAtFromEnd.Substring(0, indexOfEndOfPrimaryTableName);

        }

        private bool BuildCount()
        {
            if (_queryBody.Contains(" COUNT(*) "))
            {
                QueryName += "count_";

                // get the table name out of FROM 
                int indexOfFromEnd = _queryBody.IndexOf(" FROM ") + 6;
                string parsedTableName = String.Empty;
                while (_queryBody[indexOfFromEnd] != ' ')
                {
                    parsedTableName += _queryBody[indexOfFromEnd];
                    indexOfFromEnd++;
                }

                QueryName += parsedTableName;

                return true;
            }

            return false;
        }

        private void BuildSelectFirst()
        {
            if (_queryBody.Contains(" FIRST "))
            {
                int indexOfFirstEnd = _queryBody.IndexOf(" FIRST ") + 7;
                string parsedCount = string.Empty;
                while (_queryBody[indexOfFirstEnd].IsNumeric())
                {
                    parsedCount += _queryBody[indexOfFirstEnd];
                    indexOfFirstEnd++;
                }

                QueryName += $"first_{parsedCount}_";
            }
        }

        private void BuildQueryNamePrefix()
        {
            if (_queryBody.StartsWith("SELECT"))
                QueryName += "get_";
            else if (_queryBody.StartsWith("UPDATE"))
                QueryName += "update_";
            else if (_queryBody.StartsWith("INSERT"))
                QueryName += "insert_";
            else if (_queryBody.StartsWith("DELETE"))
                QueryName += "delete_";
        }

        private void RemoveFormattingCharacters()
        {
            _queryBody = _queryBody.Replace("\r", " ");
            _queryBody = _queryBody.Replace("\n", " ");
            _queryBody = _queryBody.Replace("\t", " ");
            _queryBody = _queryBody.Replace(",", " ");
        }
    }
}
