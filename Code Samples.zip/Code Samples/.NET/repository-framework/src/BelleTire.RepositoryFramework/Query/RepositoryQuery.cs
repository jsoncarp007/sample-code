﻿using System.Collections.Generic;
using System.Linq;
using BelleTire.RepositoryFramework.Interface;
using BelleTire.RepositoryFramework.Query.Parameter;

namespace BelleTire.RepositoryFramework.Query
{
    public abstract class RepositoryQuery
    {
        protected string BaseSql { get; }

        public RepositoryQueryType QueryType => !string.IsNullOrEmpty(BaseSql)
            ? BaseSql.ToUpper().StartsWith("EXEC") ? RepositoryQueryType.StoredProcedure : RepositoryQueryType.SqlText
            : RepositoryQueryType.SqlText;

        public string Query => GetQueryText();
        public string QueryName => GetQueryName();

        protected List<RepositoryQueryParameter> QueryParameters { get; set; }

        protected bool BaseQueryHasWhere => BaseSql.ToUpper().Contains("WHERE");

        protected const string QueryLineSeparator = " ";
        protected IRepositoryDataProviderFormatting Formatting { get; set; }

        protected RepositoryQuery(string baseSql)
        {
            BaseSql = baseSql;
            QueryParameters = new List<RepositoryQueryParameter>();
        }

        protected RepositoryQuery(string baseSql, IEnumerable<RepositoryQueryParameter> queryParameters)
        {
            BaseSql = baseSql;
            QueryParameters = queryParameters.ToList();
        }

        protected RepositoryQuery(string baseSql, RepositoryQueryParameter queryParameter)
            : this(baseSql, new [] { queryParameter })
        {
        }

        internal virtual void SetDataProviderFormatting(IRepositoryDataProviderFormatting formatting)
        {
            Formatting = formatting;
        }

        private void AddQueryParameters(IEnumerable<RepositoryQueryParameter> parameters)
        {
            QueryParameters.AddRange(parameters);
        }

        protected abstract void PreGetQueryParameters();

        internal RepositoryQueryParameter[] GetQueryParameters()
        {
            PreGetQueryParameters();

            return QueryParameters.Select(p => p).ToArray();
        }

        internal string GetUnparameterizedQuery()
        {
            string outputSql = GetQueryText();

            List<string> queryParamValues = GetQueryParameters()
                .Select(q => Formatting.GetValueAsQueryFriendlyString(q.Value))
                .ToList();

            while (outputSql.Contains("?"))
            {
                outputSql = ReplaceFirst(outputSql, "?", queryParamValues.First());
                queryParamValues.RemoveAt(0);
            }

            return outputSql;
        }

        private string ReplaceFirst(string text, string search, string replace)
        {
            int pos = text.IndexOf(search);
            if (pos < 0)
            {
                return text;
            }
            return text.Substring(0, pos) + replace + text.Substring(pos + search.Length);
        }

        private string GetQueryName()
        {
            return new RepositoryQueryNameBuilder(Query).QueryName;
        }

        protected abstract string GetQueryText();

    }
}
