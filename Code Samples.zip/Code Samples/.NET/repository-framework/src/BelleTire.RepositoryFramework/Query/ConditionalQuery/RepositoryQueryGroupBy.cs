﻿using System.Collections.Generic;

namespace BelleTire.RepositoryFramework.Query.ConditionalQuery
{
    public class RepositoryOrderBy
    {
        public List<string> OrderByFields { get; set; }

        public string Sql => $"ORDER BY {string.Join(",", OrderByFields)} {(_isDescending ? "DESC" : string.Empty)}";

        private readonly bool _isDescending;

        private RepositoryOrderBy(bool isDescending)
        {
            _isDescending = isDescending;
        }

        public RepositoryOrderBy(List<string> orderByFields, bool descending = false) : this(descending)
        {
            
            OrderByFields = orderByFields;
        }

        public RepositoryOrderBy(string field, bool descending = false) : this(descending)
        {
            OrderByFields = new List<string> {field};
        }
    }
}
