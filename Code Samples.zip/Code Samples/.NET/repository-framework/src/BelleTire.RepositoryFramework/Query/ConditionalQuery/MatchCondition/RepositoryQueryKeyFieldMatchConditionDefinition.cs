﻿using BelleTire.RepositoryFramework.Extensions;

namespace BelleTire.RepositoryFramework.Query.ConditionalQuery.MatchCondition
{
    public class RepositoryQueryKeyFieldMatchConditionDefinition : RepositoryMatchConditionDefinition
    {
        public override string WhereClauseFormatString { get; }

        public RepositoryQueryKeyFieldMatchConditionDefinition(string entityName, string entityColumnName)
        {
            WhereClauseFormatString = $"{entityName}.{entityColumnName} {RepositoryQueryCondition.Equals.GetDescription()}";
        }
    }
}
