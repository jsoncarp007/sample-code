﻿namespace BelleTire.RepositoryFramework.Query.ConditionalQuery.MatchCondition
{
    public class RepositoryQueryRuntimeMatchConditionDefinition : RepositoryMatchConditionDefinition
    {
        public override string WhereClauseFormatString { get; }

        public RepositoryQueryRuntimeMatchConditionDefinition(string whereClauseFormatString) 
        {
            WhereClauseFormatString = whereClauseFormatString;
        }
    }
}