﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using BelleTire.RepositoryFramework.DataMapping.Reflection;
using BelleTire.RepositoryFramework.Extensions;
using BelleTire.RepositoryFramework.Interface;
using BelleTire.RepositoryFramework.Query.Parameter;

namespace BelleTire.RepositoryFramework.Query.ConditionalQuery.MatchCondition
{
    public class RepositoryQueryMatchCondition 
    {
        public object Value { get; set; }

        private RepositoryMatchConditionDefinition Template { get; }
        private string _whereClause;

        public RepositoryQueryMatchCondition(RepositoryMatchConditionDefinition template)
        {
            Template = template;
        }

        public RepositoryQueryMatchCondition(RepositoryMatchConditionDefinition template, object value) : this(template)
        {
            Value = value;
        }

        public string GetWhereClause(IRepositoryDataProviderFormatting formatting)
        {
            if (!string.IsNullOrEmpty(_whereClause)) return _whereClause;  // compute only once

            string whereClauseFormatString = GetFormattedWhereClause(formatting);
            whereClauseFormatString = whereClauseFormatString.Replace("{X}", "~");

            string reconstructedClauseString = string.Empty;
            
            string unprocessedStringPart = whereClauseFormatString;

            while (unprocessedStringPart.Contains("~"))
            {
                // get number of ? or ~ that appear before each ~
                int startOfXVar = unprocessedStringPart.IndexOf("~");
                string stringPriorToXVar = unprocessedStringPart.Substring(0, startOfXVar);

                int varMarkerCount = stringPriorToXVar.Length - stringPriorToXVar.Replace("?", string.Empty).Replace("~", string.Empty).Length;

                reconstructedClauseString += stringPriorToXVar;

                unprocessedStringPart = unprocessedStringPart.Replace(stringPriorToXVar, string.Empty);
                unprocessedStringPart = unprocessedStringPart.Substring(1, unprocessedStringPart.Length - 1);

                string objectStringValue = string.Empty;

                if (Value is IEnumerable<object> enumerable && enumerable.Count() >= varMarkerCount)
                {
                    objectStringValue = formatting.GetValueAsQueryFriendlyString(enumerable.ElementAt(varMarkerCount));
                    
                    // see if we're inside quotes already
                    if (unprocessedStringPart.Take(3).Any(c => c == '\'') ||
                        stringPriorToXVar.Reverse().Take(3).Any(c => c == '\''))
                    {
                        // we're in quotes, remove quotes from our returned value
                        objectStringValue = objectStringValue.Replace("'", string.Empty);
                    }

                    var newValueList = new List<object>(enumerable);
                    newValueList.RemoveAt(varMarkerCount);
                    Value = newValueList;
                }
                else 
                    objectStringValue = formatting.GetValueAsQueryFriendlyString(Value);

                reconstructedClauseString += objectStringValue;

            }

            reconstructedClauseString += unprocessedStringPart;

            _whereClause = string.Format(reconstructedClauseString, Template.SourceColumnList);

            return _whereClause;
        }


        private string GetFormattedWhereClause(IRepositoryDataProviderFormatting formatting)
        {
            string whereClause = Template.WhereClauseFormatString;

            // find strings in the where clause that match the names of RepositoryQueryConditions
            foreach (RepositoryQueryCondition condition in (RepositoryQueryCondition[])Enum.GetValues(typeof(RepositoryQueryCondition)))
            {
                // swap out the condition name string for the formatted condition
                whereClause = whereClause.Replace(condition.GetDescription(),
                    formatting.GetFormatStringForCondition(condition));
            }

            return whereClause;
        }

        public List<RepositoryQueryParameter> AsRepositoryQueryParameters(IRepositoryDataProviderFormatting formatting)
        {
            List<RepositoryQueryParameter> queryParams = new List<RepositoryQueryParameter>();

            string whereClauseFormatString = GetWhereClause(formatting);
            int countOfVariables = whereClauseFormatString.Count(c => c == '?');

            var splitObjectValues = Value.SplitEnumerableValues();

            // if this is a LIST
            if (whereClauseFormatString.Contains(formatting.GetFormatStringForCondition(RepositoryQueryCondition.InList)))
            {
                var enumTypes = splitObjectValues.GetTypesInsideEnumerable();
                var enumType = enumTypes.Any() ? enumTypes.First() : typeof(int);

                var listType = typeof(List<>).MakeGenericType(enumType);
                IList list = (IList) Activator.CreateInstance(listType);
                queryParams.Add(new RepositoryQueryParameter(
                    new RepositoryQueryParameterTypeDefinition(list.GetType(), splitObjectValues.Count), Value, 0));
                
            }
            else
            {
                int positionsPerParam = countOfVariables / splitObjectValues.Count;
                int startPosition = 0;
                foreach (var item in splitObjectValues)
                {
                    List<int> positions = new List<int>();
                    for (int i = 0; i < positionsPerParam; i++)
                    {
                        positions.Add(startPosition+(i*splitObjectValues.Count));
                    }

                    if (Template.ParameterTypeDefinitionOverride != null)
                        queryParams.Add(new RepositoryQueryParameter(
                            Template.ParameterTypeDefinitionOverride[startPosition], item, positions.ToArray()));
                    else
                        queryParams.Add(new RepositoryQueryParameter(Template.SourceColumnList[startPosition], item, positions.ToArray()));

                    startPosition++;
                }
            }

            return queryParams;
        }

        public static RepositoryQueryMatchCondition GetMatchCondition<T>(Expression<Predicate<T>> selector)
        {
            var visitor = new RepositoryLinqVisitor();
            visitor.Visit(selector);
            return visitor.MatchCondition;
        }
    }
}
