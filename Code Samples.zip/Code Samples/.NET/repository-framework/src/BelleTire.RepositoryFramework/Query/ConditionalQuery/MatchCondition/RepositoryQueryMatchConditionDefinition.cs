﻿using System.Linq;
using BelleTire.RepositoryFramework.Query.Parameter;

namespace BelleTire.RepositoryFramework.Query.ConditionalQuery.MatchCondition
{
    public abstract class RepositoryMatchConditionDefinition
    {
        public virtual RepositoryQueryParameterTypeDefinition[] ParameterTypeDefinitionOverride { get; }
        public virtual string[] SourceColumnList => ParseSourceColumnsFromWhereClause();
        public abstract string WhereClauseFormatString { get; }
        
        public RepositoryQueryMatchCondition GetConditionForDefinition()
        {
            return new RepositoryQueryMatchCondition(this);
        }

        public RepositoryQueryMatchCondition GetConditionForDefinition(object value)
        {
            return new RepositoryQueryMatchCondition(this, value);
        }

        private string[] ParseSourceColumnsFromWhereClause()
        {
            var splitString = WhereClauseFormatString.Split(' ', '(', ')');
            return splitString.Where(s => s.Contains(".")).Select(s=>s.Trim()).ToArray();
        }
    }
}
