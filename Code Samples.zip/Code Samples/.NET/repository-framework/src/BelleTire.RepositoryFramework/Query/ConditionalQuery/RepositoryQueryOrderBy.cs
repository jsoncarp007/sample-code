﻿using System.Collections.Generic;

namespace BelleTire.RepositoryFramework.Query.ConditionalQuery
{
    public class RepositoryGroupBy
    {
        public List<string> GroupByFields { get; set; }
        public string Sql => $"GROUP BY {string.Join(",", GroupByFields)}";

        public RepositoryGroupBy(List<string> groupByFields)
        {
            GroupByFields = groupByFields;
        }

        public RepositoryGroupBy(string field)
        {
            GroupByFields = new List<string> {field};
        }
    }
}
