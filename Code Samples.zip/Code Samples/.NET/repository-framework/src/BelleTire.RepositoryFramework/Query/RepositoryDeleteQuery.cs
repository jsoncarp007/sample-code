﻿using System.Collections.Generic;
using BelleTire.RepositoryFramework.Interface;
using BelleTire.RepositoryFramework.Query.ConditionalQuery.MatchCondition;
using BelleTire.RepositoryFramework.Query.Parameter;

namespace BelleTire.RepositoryFramework.Query
{
    public class RepositoryDeleteQuery : RepositoryConditionalQuery
    {

        internal RepositoryDeleteQuery(string baseSql, IDatabaseMappedObject mappedObjectToDelete)
        :base (baseSql, mappedObjectToDelete)
        {

        }

        internal RepositoryDeleteQuery(string baseSql, IEnumerable<RepositoryQueryMatchCondition> matchConditions) 
            : base(baseSql, matchConditions)
        {
        }

        internal RepositoryDeleteQuery(string baseSql, RepositoryQueryMatchCondition matchCondition) 
            : base(baseSql, matchCondition)
        {
        }

        internal RepositoryDeleteQuery(string baseSql, RepositoryQueryMatchCondition matchCondition, RepositoryQueryParameter queryParameter) 
            : base(baseSql, matchCondition, queryParameter)
        {
        }

        internal RepositoryDeleteQuery(string baseSql, RepositoryQueryMatchCondition matchCondition, IEnumerable<RepositoryQueryParameter> queryParameters) 
            : base(baseSql, matchCondition, queryParameters)
        {
        }

        internal RepositoryDeleteQuery(string baseSql, List<RepositoryQueryMatchCondition> matchConditions, IEnumerable<RepositoryQueryParameter> queryParameters) 
            : base(baseSql, matchConditions, queryParameters)
        {
        }

        internal RepositoryDeleteQuery(string baseSql, IEnumerable<RepositoryQueryParameter> queryParameters) 
            : base(baseSql, queryParameters)
        {
        }

        protected override string ModifyBaseQuery(string baseQuery)
        {
            return baseQuery;
        }

        protected override string GetPreWhereSqlString()
        {
            return string.Empty;
        }

        protected override string GetPostWhereSqlString()
        {
            return string.Empty;
        }

        
    }
}
