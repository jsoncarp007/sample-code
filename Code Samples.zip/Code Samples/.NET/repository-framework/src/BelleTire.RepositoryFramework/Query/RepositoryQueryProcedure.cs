﻿using System.Collections.Generic;
using BelleTire.RepositoryFramework.Query.Parameter;

namespace BelleTire.RepositoryFramework.Query
{
    public class RepositoryQueryProcedure : RepositoryQuery
    {
        public RepositoryQueryProcedure(string storedProcedureSql) : base(storedProcedureSql)
        {
        }

        public RepositoryQueryProcedure(string storedProcedureSql, IEnumerable<RepositoryQueryParameter> queryParameters) : base(storedProcedureSql, queryParameters)
        {
        }

        public RepositoryQueryProcedure(string storedProcedureSql, RepositoryQueryParameter queryParameter) : base(storedProcedureSql, queryParameter)
        {
        }

        protected override void PreGetQueryParameters()
        {
        }

        protected override string GetQueryText()
        {
            return BaseSql;
        }
    }
}
