﻿using System;
using System.Collections.Generic;
using System.Linq;
using BelleTire.RepositoryFramework.Interface;
using BelleTire.RepositoryFramework.Query.ConditionalQuery.MatchCondition;
using BelleTire.RepositoryFramework.Query.Parameter;

namespace BelleTire.RepositoryFramework.Query
{
    public abstract class RepositoryConditionalQuery : RepositoryQuery
    {
        protected List<RepositoryQueryMatchCondition> MatchConditions { get; set; }

        private bool _whereClauseConditionParametersSet = false;

        protected RepositoryConditionalQuery(string baseSql) 
            : base(baseSql)
        {
            MatchConditions = new List<RepositoryQueryMatchCondition>();
        }

        protected RepositoryConditionalQuery(string baseSql, IDatabaseMappedObject objectToMatch) : base(baseSql)
        {
            var keyFieldMatchCondition = new RepositoryQueryKeyFieldMatchConditionDefinition(
                    objectToMatch.GetMappedObjectTableName(),
                    objectToMatch.GetMappedObjectKeyFieldColumnName())
                .GetConditionForDefinition(objectToMatch.GetMappedObjectKeyFieldValue());

            MatchConditions = new List<RepositoryQueryMatchCondition> {keyFieldMatchCondition};
        }

        protected RepositoryConditionalQuery(string baseSql, IEnumerable<RepositoryQueryMatchCondition> matchConditions) 
            : base(baseSql)
        {
            MatchConditions = matchConditions.ToList();
        }

        protected RepositoryConditionalQuery(string baseSql, RepositoryQueryMatchCondition matchCondition) 
            : this(baseSql, new []{ matchCondition })
        {
        }

        protected RepositoryConditionalQuery(string baseSql, RepositoryQueryMatchCondition matchCondition, RepositoryQueryParameter queryParameter) 
            : this(baseSql, new [] { matchCondition }, new [] { queryParameter })
        { 
        }

        protected RepositoryConditionalQuery(string baseSql, RepositoryQueryMatchCondition matchCondition, IEnumerable<RepositoryQueryParameter> queryParameters) 
            : this(baseSql, new [] { matchCondition }, queryParameters)
        {
        }

        protected RepositoryConditionalQuery(string baseSql, IEnumerable<RepositoryQueryMatchCondition> matchConditions, IEnumerable<RepositoryQueryParameter> queryParameters) 
            : base(baseSql, queryParameters)
        {
            MatchConditions = matchConditions.ToList();
        }

        protected RepositoryConditionalQuery(string baseSql, IEnumerable<RepositoryQueryParameter> queryParameters) 
            : base(baseSql, queryParameters)
        {
        }

        public void AddRepositorySearchOption(RepositoryQueryMatchCondition searchOption)
        {
            MatchConditions.Add(searchOption);
        }

        private void SetWhereClauseConditionParameters()
        {
            if (_whereClauseConditionParametersSet) return;

            List<RepositoryQueryMatchCondition> matchConditionWhereClauses = MatchConditions
                .Where(c => c.GetWhereClause(Formatting).Contains("?"))
                .ToList();

            var paramsToAdd = matchConditionWhereClauses
                .SelectMany(p => p.AsRepositoryQueryParameters(Formatting));

            QueryParameters.AddRange(paramsToAdd);

            _whereClauseConditionParametersSet = true;
        }


        protected override void PreGetQueryParameters()
        {
            SetWhereClauseConditionParameters();
        }

        protected string GetWhereClausesString()
        {
            string sqlText = Environment.NewLine;

            if (MatchConditions.Count > 0)
            {
                sqlText += "\t";
                sqlText += !BaseQueryHasWhere ? "WHERE " : "AND ";
            }

            sqlText += string.Join($"{Environment.NewLine}AND ", MatchConditions.Select(s => s.GetWhereClause(Formatting) + Environment.NewLine));

            return sqlText;
        }

        protected override string GetQueryText()
        {
            if (QueryType == RepositoryQueryType.StoredProcedure)
                return BaseSql;

            string sqlText = ModifyBaseQuery(BaseSql) + QueryLineSeparator;

            sqlText += GetPreWhereSqlString() + QueryLineSeparator;

            sqlText += GetWhereClausesString() + QueryLineSeparator;

            sqlText += GetPostWhereSqlString() + QueryLineSeparator;

            return sqlText;
        }

        protected abstract string ModifyBaseQuery(string baseQuery);
        
        protected abstract string GetPreWhereSqlString();
        protected abstract string GetPostWhereSqlString();
    }
}
