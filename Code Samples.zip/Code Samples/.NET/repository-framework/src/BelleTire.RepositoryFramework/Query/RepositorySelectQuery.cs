﻿using System.Collections.Generic;
using System.Linq;
using BelleTire.RepositoryFramework.Interface;
using BelleTire.RepositoryFramework.Query.ConditionalQuery;
using BelleTire.RepositoryFramework.Query.ConditionalQuery.MatchCondition;
using BelleTire.RepositoryFramework.Query.Parameter;

namespace BelleTire.RepositoryFramework.Query
{
    public class RepositorySelectQuery : RepositoryConditionalQuery
    {
        protected bool CountOnly { get; set; }
        protected int SelectFirst { get; set; }
        protected RepositoryGroupBy GroupBy { get; set; }
        protected RepositoryOrderBy OrderBy { get; set; }

        public List<string> LimitToColumns { get; }

        public RepositorySelectQuery(string baseSql, IDatabaseMappedObject objectToSelect) : base(baseSql, objectToSelect)
        {
        }

        public RepositorySelectQuery(string baseSql, IEnumerable<RepositoryQueryMatchCondition> matchConditions, IEnumerable<RepositoryQueryParameter> queryParameters, IEnumerable<string> limitToColumns = null, int selectFirst = 0)
            : base(baseSql, matchConditions, queryParameters)
        {
            SelectFirst = selectFirst;
            LimitToColumns = limitToColumns?.ToList();
        }

        public RepositorySelectQuery(string baseSql, IEnumerable<RepositoryQueryMatchCondition> matchConditions, IEnumerable<RepositoryQueryParameter> queryParameters, int selectFirst)
            : this(baseSql, matchConditions, queryParameters, new List<string>(), selectFirst)
        {
        }

        public RepositorySelectQuery(string baseSql, int selectFirst = 0) 
            : base(baseSql)
        {
            SelectFirst = selectFirst;
        }

        public RepositorySelectQuery(string baseSql, RepositoryOrderBy orderBy, int selectFirst = 0)
            : this(baseSql)
        {
            SelectFirst = selectFirst;
        }

        public RepositorySelectQuery(string baseSql, IEnumerable<string> limitToColumns, int selectFirst = 0)
            : base(baseSql)
        {
            SelectFirst = selectFirst;
            LimitToColumns = limitToColumns.ToList();
        }

        public RepositorySelectQuery(string baseSql, IEnumerable<RepositoryQueryMatchCondition> matchConditions, IEnumerable<string> limitToColumns, int selectFirst = 0) 
            : base(baseSql, matchConditions)
        {
            LimitToColumns = limitToColumns.ToList();
            SelectFirst = selectFirst;
        }

        public RepositorySelectQuery(string baseSql, IEnumerable<RepositoryQueryMatchCondition> matchConditions, int selectFirst = 0)
            : this(baseSql, matchConditions, new List<string>(), selectFirst)
        {
        }

        public RepositorySelectQuery(string baseSql, RepositoryQueryMatchCondition matchCondition, int selectFirst = 0) 
            : base(baseSql, matchCondition)
        {
            SelectFirst = selectFirst;
        }

        public RepositorySelectQuery(string baseSql, RepositoryQueryMatchCondition[] matchConditions, bool countOnly)
            : base(baseSql, matchConditions)
        {
            CountOnly = countOnly;
        }

        public RepositorySelectQuery(string baseSql, RepositoryQueryMatchCondition matchCondition, bool countOnly)
            : base(baseSql, matchCondition)
        {
            CountOnly = countOnly;
        }

        public RepositorySelectQuery(string baseSql, RepositoryQueryMatchCondition matchCondition, IEnumerable<string> limitToColumns, int selectFirst = 0)
            : base(baseSql, matchCondition)
        {
            LimitToColumns = limitToColumns.ToList();
            SelectFirst = selectFirst;
        }

        public RepositorySelectQuery(string baseSql, RepositoryQueryMatchCondition matchCondition, RepositoryQueryParameter queryParameter, int selectFirst = 0) 
            : base(baseSql, matchCondition, queryParameter)
        {
            SelectFirst = selectFirst;
        }

        public RepositorySelectQuery(string baseSql, RepositoryQueryMatchCondition matchCondition, RepositoryQueryParameter queryParameter, IEnumerable<string> limitToColumns, int selectFirst = 0)
            : base(baseSql, matchCondition, queryParameter)
        {
            LimitToColumns = limitToColumns.ToList();
            SelectFirst = selectFirst;
        }

        public RepositorySelectQuery(string baseSql, IEnumerable<RepositoryQueryParameter> queryParameters, int selectFirst = 0) 
            : base(baseSql, queryParameters)
        {
            SelectFirst = selectFirst;
        }

        public RepositorySelectQuery(string baseSql, IEnumerable<RepositoryQueryParameter> queryParameters, IEnumerable<string> limitToColuns, int selectFirst = 0)
            : base(baseSql, queryParameters)
        {
            LimitToColumns = limitToColuns.ToList();
            SelectFirst = selectFirst;
        }

        public void SetGroupBy(RepositoryGroupBy groupBy)
        {
            GroupBy = groupBy;
        }

        public void SetOrderBy(RepositoryOrderBy orderBy)
        {
            OrderBy = orderBy;
        }

        protected override string ModifyBaseQuery(string baseQuery)
        {
            if (CountOnly)
            {
                int indexOfFrom = baseQuery.IndexOf("FROM");
                var queryStartAtFrom = baseQuery.Substring(indexOfFrom, baseQuery.Length - indexOfFrom);
                return $"SELECT COUNT(*) {queryStartAtFrom}";
            }

            string modifiedQuery = LimitToColumns != null && LimitToColumns.Count > 0 ?
               ReduceToOnlyLimitToColumns(baseQuery) :
               baseQuery;

           return SelectFirst == 0 ?
               modifiedQuery :
               modifiedQuery.Replace("SELECT ", $"SELECT {Formatting.TopRecordsString} {SelectFirst} ");

        }

        private string ReduceToOnlyLimitToColumns(string querySql)
        {
            int indexOfFromStart = querySql.IndexOf("FROM");

            string originalFromStatement = querySql.Substring(indexOfFromStart, querySql.Length - indexOfFromStart);

            string limitToColsString = string.Join(", ", LimitToColumns);

            return $"SELECT {limitToColsString} {originalFromStatement}";
        }

        protected override string GetPreWhereSqlString()
        {
            return string.Empty;
        }

        protected override string GetPostWhereSqlString()
        {
            string sqlText = string.Empty;

            if (GroupBy != null)
                sqlText += GroupBy.Sql + QueryLineSeparator;

            if (OrderBy != null)
                sqlText += OrderBy.Sql + QueryLineSeparator;

            return sqlText;
        }
    }
}
