﻿using System.ComponentModel;

namespace BelleTire.RepositoryFramework.Query
{
    public enum RepositoryQueryCondition
    {
        [Description("|Equals|")]
        Equals,

        [Description("|GreaterThan|")]
        GreaterThan,

        [Description("|GreaterThanOrEqual|")]
        GreaterThanOrEqual,

        [Description("|LessThan|")]
        LessThan,

        [Description("|LessThanOrEqual|")]
        LessThanOrEqual,

        [Description("|NotEqual|")]
        NotEqual,

        [Description("|IsNotNull|")]
        IsNotNull,

        [Description("|IsNull|")]
        IsNull,

        [Description("|InList|")]
        InList,

        [Description("|Between|")]
        Between,

        [Description("|BeginsWith|")]
        BeginsWith,

        [Description("|EndsWith|")]
        EndsWith,

        [Description("|And|")]
        And,

        [Description("|Or|")]
        Or
    }
}
