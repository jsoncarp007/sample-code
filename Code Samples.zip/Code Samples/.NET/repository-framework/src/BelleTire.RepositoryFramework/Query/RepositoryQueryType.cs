﻿namespace BelleTire.RepositoryFramework.Query
{
    public enum RepositoryQueryType
    {
        SqlText,
        StoredProcedure
    }
}
