﻿using System.Linq;

namespace BelleTire.RepositoryFramework.Query.Parameter
{
    public class RepositoryQueryParameter
    {
        public RepositoryQueryParameterTypeDefinition TypeDefinition { get; }
        public string SourceColumnIdentifier { get; }
        public object Value { get; set; }
        public int[] ParameterPositions { get; set; }

        public RepositoryQueryParameter(string sourceColumnIdentifier, object value, int[] parameterPositions)
        {
            ParameterPositions = parameterPositions;
            SourceColumnIdentifier = sourceColumnIdentifier;
            Value = value;
        }

        public RepositoryQueryParameter(string sourceColumnIdentifier, object value, int parameterPosition) : this(sourceColumnIdentifier, value, new []{parameterPosition})
        {
        }

        public RepositoryQueryParameter(RepositoryQueryParameterTypeDefinition typeDefinition, object value, int[] parameterPositions)
        {
            ParameterPositions = parameterPositions;
            TypeDefinition = typeDefinition;
            Value = value;
        }

        public RepositoryQueryParameter(RepositoryQueryParameterTypeDefinition typeDefinition, object value, int parameterPosition) : this (typeDefinition, value, new []{parameterPosition})
        {
        }

        public void AdjustParameterPositions(int filledPositionNumber)
        {
            if (ParameterPositions.Length > 0)
            {
                if (ParameterPositions.Contains(filledPositionNumber))
                {
                    for (int i = 0; i < ParameterPositions.Length; i++)
                    {
                        ParameterPositions[i] = ParameterPositions[i] + 1;
                    }
                }
            }
            else
                ParameterPositions = new[] {0};
        }
    }
}
