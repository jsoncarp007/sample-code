﻿using System.Collections.Generic;
using System.Linq;

namespace BelleTire.RepositoryFramework.Query.Parameter
{
    public class RepositoryQueryParameterFactory
    {
        public Dictionary<int, RepositoryQueryParameter> GetOrderedParametersDictionary(List<RepositoryQueryParameter> queryParams)
        {
            ReNumberParameterPositions(queryParams);

            Dictionary<int, RepositoryQueryParameter> queryParametersByPosition =
                new Dictionary<int, RepositoryQueryParameter>();

            foreach (var queryParam in queryParams)
            {
                foreach (var position in queryParam.ParameterPositions)
                {
                    queryParametersByPosition.Add(position, queryParam);
                }
            }

            queryParametersByPosition =
                queryParametersByPosition.OrderBy(s => s.Key)
                    .ToDictionary(p => p.Key, p => p.Value);

            return queryParametersByPosition;
        }

        private void ReNumberParameterPositions(List<RepositoryQueryParameter> queryParams)
        {
            List<RepositoryQueryParameter> processedParams = new List<RepositoryQueryParameter>();
            foreach (var queryParam in queryParams)
            {
                processedParams.Add(queryParam);

                // adjust for filled positions
                foreach (var position in queryParam.ParameterPositions)
                {
                    foreach (var otherQueryParam in queryParams.Where(p => !processedParams.Contains(p)))
                    {
                        otherQueryParam.AdjustParameterPositions(position);
                    }
                }
            }
        }
    }
}
