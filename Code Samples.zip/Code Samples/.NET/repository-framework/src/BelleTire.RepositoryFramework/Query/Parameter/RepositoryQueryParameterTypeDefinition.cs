﻿using System;

namespace BelleTire.RepositoryFramework.Query.Parameter
{
    public class RepositoryQueryParameterTypeDefinition
    {
        public Type DataType { get; }
        public int Length { get; }

        public RepositoryQueryParameterTypeDefinition(Type dataType, int length)
        {
            DataType = dataType;
            Length = length;
        }
    }
}
