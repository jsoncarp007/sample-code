﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using BelleTire.RepositoryFramework.Query;

namespace BelleTire.RepositoryFramework.Extensions
{
    public static class RepositoryReflectionExtensions
    {
        public static bool IsEnumerable(this object obj)
        {
            return obj is IEnumerable;
        }

        public static Type GetInnerGenericType(this Type type)
        {
            // Attempt to get the inner generic type
            Type innerType = type.GetGenericArguments().FirstOrDefault();

            // Recursively call this function until no inner type is found
            return innerType is null ? type : innerType.GetInnerGenericType();
        }

        public static string GetDescription(this RepositoryQueryCondition queryCondition)
        {
            MemberInfo[] memberInfo = typeof(RepositoryQueryCondition)
                .GetMember(queryCondition.ToString())
                .Where(mi => mi.DeclaringType == typeof(RepositoryQueryCondition))
                .ToArray();

            if (memberInfo.Length > 0)
            {
                object[] attrs = memberInfo[0].GetCustomAttributes(typeof(DescriptionAttribute), false);

                if (attrs.Length > 0)
                {
                    return ((DescriptionAttribute)attrs[0]).Description;
                }
            }
            return queryCondition.ToString();
        }

        public static List<object> SplitEnumerableValues(this object value)
        {
            if (value is string)
            {
                return new List<object>() { value };
            }

            List<object> returnList = new List<object>();

            if (value is IEnumerable enumerable)
            {
                foreach (var item in enumerable)
                    returnList.Add(item);
            }
            else
                returnList.Add(value);

            return returnList;
        }

        public static List<Type> GetTypesInsideEnumerable(this IEnumerable<object> enumerable)
        {
            return enumerable.Select(e => e.GetType()).Distinct().ToList();

        }
    }
}
