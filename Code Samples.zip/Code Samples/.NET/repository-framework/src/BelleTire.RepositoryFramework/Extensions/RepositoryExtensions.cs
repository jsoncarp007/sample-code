﻿using System;
using System.Globalization;

namespace BelleTire.RepositoryFramework.Extensions
{
    public static class RepositoryExtensions
    {
        public static string ConvertUnderscoreCaseToPascalCase(this string dbCaseName)
        {
            var pascalCaseName = dbCaseName.ToLower().Replace("_", " ");
            TextInfo info = CultureInfo.CurrentCulture.TextInfo;
            return info.ToTitleCase(pascalCaseName).Replace(" ", string.Empty);
        }

        public static bool IsNumeric(this char charToTest)
        {
            return Char.IsNumber(charToTest);
        }
    }
}
