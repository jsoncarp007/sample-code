﻿namespace BelleTire.RepositoryFramework.Entity
{
    public class RepositoryQueryEntityColumn
    {
        public string Name { get; }
        public bool IsPrimaryKey { get; set; }

        public RepositoryQueryEntityColumn(string name, bool isPrimaryKey = false)
        {
            Name = name;
            IsPrimaryKey = isPrimaryKey;
        }
    }
}
