﻿using BelleTire.RepositoryFramework.Core;

namespace BelleTire.RepositoryFramework.Entity
{
    public class RepositoryQueryEntityRelationship
    {
        public RepositoryQueryEntity Entity { get; set; }
        public RepositoryQueryEntityColumn EntityColumn { get; set; }

        public RepositoryQueryEntity JoinToEntity { get; set; }
        public RepositoryQueryEntityColumn JoinToEntityColumn { get; set; }

        public bool IsOuterJoin { get; }

        public RepositoryQueryEntityRelationship(RepositoryQueryEntity entity, RepositoryQueryEntityColumn entityColumn, RepositoryQueryEntity joinToEntity, RepositoryQueryEntityColumn joinToEntityColumn, bool isOuterJoin = false)
        {
            Entity = entity;
            EntityColumn = entityColumn;
            JoinToEntity = joinToEntity;
            JoinToEntityColumn = joinToEntityColumn;
            IsOuterJoin = isOuterJoin;
        }

        public RepositoryQueryEntityRelationship(IRepositoryQueryEntityRelationshipDefinition definition)
        : this(new RepositoryQueryEntity(definition.PrimaryEntityDefinition), new RepositoryQueryEntityColumn(definition.PrimaryEntityJoinFieldName), new RepositoryQueryEntity(definition.JoinToEntityDefinition), new RepositoryQueryEntityColumn(definition.JoinToEntityJoinField, true), definition.OuterJoin)
        {
        }

        public void AdjustJoinDirectionForPrimaryEntity(RepositoryQueryEntity primaryEntity)
        {
            if (Entity.EntityName == primaryEntity.EntityName && JoinToEntity != null)
            {
                Entity = JoinToEntity;
                EntityColumn = JoinToEntityColumn;
                JoinToEntity = primaryEntity;
                JoinToEntityColumn = primaryEntity.GetKeyColumn();
            }
        }
    }
}
