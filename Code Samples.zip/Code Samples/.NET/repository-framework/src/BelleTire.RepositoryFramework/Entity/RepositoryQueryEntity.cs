﻿using System.Collections.Generic;
using System.Linq;
using BelleTire.RepositoryFramework.Core;

namespace BelleTire.RepositoryFramework.Entity
{
    public class RepositoryQueryEntity : IRepositoryQueryEntityDefinition
    {
        public string EntityName { get; }
        public string KeyColumnName { get; }
        public List<RepositoryQueryEntityColumn> Columns { get; }

        public string[] ColumnNames => Columns.Select(c => c.Name).ToArray();

        public RepositoryQueryEntity(string entityName, string keyColumnName, IEnumerable<string> columnNames)
        {
            columnNames = columnNames.ToList();
            KeyColumnName = keyColumnName;
            
            EntityName = entityName;

            var primaryEntityColumns =
                columnNames.Select(c => new RepositoryQueryEntityColumn(c)).ToList();

            if (!columnNames.Contains(keyColumnName))
            {
                var primaryEntityKeyColumn = new RepositoryQueryEntityColumn(keyColumnName, true);
                primaryEntityColumns.Add(primaryEntityKeyColumn);
            }
            else
                primaryEntityColumns.First(c => c.Name == keyColumnName).IsPrimaryKey = true;
            
            Columns = primaryEntityColumns;
        }

        public RepositoryQueryEntity(IRepositoryQueryEntityDefinition entityDefinition) 
            : this(entityDefinition.EntityName, entityDefinition.KeyColumnName, entityDefinition.ColumnNames)
        {
        }

        public RepositoryQueryEntityColumn GetKeyColumn()
        {
            return Columns.First(k => k.IsPrimaryKey);
        }
    }
}
