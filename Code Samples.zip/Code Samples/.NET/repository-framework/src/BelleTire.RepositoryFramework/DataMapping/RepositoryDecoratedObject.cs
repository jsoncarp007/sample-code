﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using BelleTire.RepositoryFramework.Core;
using BelleTire.RepositoryFramework.DataMapping.Reflection;
using BelleTire.RepositoryFramework.Extensions;
using BelleTire.RepositoryFramework.Interface;

namespace BelleTire.RepositoryFramework.DataMapping
{
    public class RepositoryDecoratedObject : IDatabaseMappedObject
    {
        private readonly RepositoryDecoratedObjectReflectedMapping _reflectedObjectMapping;

        private string[] TableNames { get; }

        public RepositoryDecoratedObject()
        {
            _reflectedObjectMapping = DecoratedObjectReflection.InitReflectedMapping(GetType());

            var tableNames = _reflectedObjectMapping
                .JoinToEntityTypes
                .Select(e => e.GetMappedObjectTableName())
                .ToList();
            tableNames.Add(_reflectedObjectMapping.TableName);
            TableNames = tableNames.ToArray();
        }

        public Dictionary<string, object> GetMappedObjectValues()
        {
            return _reflectedObjectMapping.ReflectedProperties.Where(c=>!string.IsNullOrEmpty(c.ColumnName))
                .ToDictionary(p => p.ColumnName, p => p.GetPropertyValue(this));
        }

        public void LoadFromDataRow(DataRow dr)
        {
            DecoratedObjectReflection.LoadFromDataRow(this, dr, _reflectedObjectMapping, TableNames);
        }

        public void LoadFromDataTable(DataTable dt)
        {
            if (dt.Rows.Count < 1) return;

            var firstDataRow = dt.Rows.OfType<DataRow>().First();

            LoadFromDataRow(firstDataRow);

            foreach (var property in _reflectedObjectMapping.ReflectedProperties.Where(p => p.IsVirtual))
            {
                var newInstanceOfPropertyType = Activator.CreateInstance(property.PropertyDataType);

                if (property.IsEnumerable)
                {
                    var enumerableType = newInstanceOfPropertyType.GetType().GetInnerGenericType();

                    var listType = typeof(List<>);
                    var constructedListType = listType.MakeGenericType(enumerableType);

                    dynamic instance = Activator.CreateInstance(constructedListType);

                    foreach (var dataRow in dt.Rows.OfType<DataRow>())
                    {
                        dynamic childInstance = Activator.CreateInstance(enumerableType);
                        childInstance.LoadFromDataRow(dataRow);
                        instance.Add(childInstance);
                        property.SetPropertyValue(this, instance);
                    }
                }
                else
                {
                    dynamic instanceAsDatabaseMappedObject = newInstanceOfPropertyType;
                    instanceAsDatabaseMappedObject.LoadFromDataRow(firstDataRow);
                    property.SetPropertyValue(this, instanceAsDatabaseMappedObject);
                }
            }
        }

        public string[] GetMappedObjectColumnNames()
        {
            return _reflectedObjectMapping.ReflectedProperties
                .Where(r=>!r.IsVirtual)
                .Select(r => r.ColumnName)
                .Distinct()
                .ToArray();
        }

        public string GetMappedObjectKeyFieldColumnName()
        {
            return _reflectedObjectMapping.KeyFieldColumnName;
        }

        public object GetMappedObjectKeyFieldValue()
        {
            return _reflectedObjectMapping.KeyFieldProperty?.GetPropertyValue(this);
        }

        public string GetMappedObjectTableName()
        {
            return _reflectedObjectMapping.TableName;
        }

        public string GetColumnNameForPropertyName(string propertyName)
        {
            return _reflectedObjectMapping.ReflectedProperties.FirstOrDefault(p => p.PropertyName == propertyName)?.ColumnName;
        }

        public RepositoryDecoratedObjectReflectedMapping GetReflectedMapping()
        {
            return _reflectedObjectMapping;
        }

        public bool IsNavigationOnly()
        {
            return _reflectedObjectMapping.IsNavigationOnly;
        }

        public string GetValueListNamePropertyValue()
        {
            return _reflectedObjectMapping.ReflectedProperties
                .FirstOrDefault(p => p.IsValueListNameProperty)
                ?.GetPropertyValue(this).ToString();
        }

        public string GetValueListNamePropertyColumnName()
        {
            return _reflectedObjectMapping.ReflectedProperties
                .FirstOrDefault(p => p.IsValueListNameProperty)
                ?.ColumnName;
        }

        public bool HasVirtualEnumerableChildren()
        {
            return _reflectedObjectMapping.ReflectedProperties.Any(reflectedProperty =>
                reflectedProperty.IsVirtual && reflectedProperty.IsEnumerable);
        }
    }
}
