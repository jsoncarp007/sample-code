﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using BelleTire.RepositoryFramework.Core.CustomAttributes;
using BelleTire.RepositoryFramework.Extensions;

namespace BelleTire.RepositoryFramework.DataMapping.Reflection
{
    public class RepositoryDecoratedObjectReflectedMapping
    {
        public bool IsNavigationOnly { get; }
        public string TableName { get; }
        public string KeyFieldColumnName { get; }
        public HashSet<ReflectedEntityProperty> ReflectedProperties { get; }
        public ReflectedEntityProperty KeyFieldProperty { get; }
        public object[] Attributes { get; }
        public RepositoryDecoratedObject[] JoinToEntityTypes { get; }

        public RepositoryDecoratedObjectReflectedMapping(Type objectType)
        {
            Attributes = objectType.GetCustomAttributes(true);
            IsNavigationOnly = GetIsNavigationOnly();
            ReflectedProperties = new HashSet<ReflectedEntityProperty>(GetReflectedProperties(objectType));

            var keyFieldProp = ReflectedProperties.FirstOrDefault(p => p.IsPrimaryKey);
            if (keyFieldProp != null)
            {
                KeyFieldProperty = keyFieldProp;
                KeyFieldColumnName = keyFieldProp.ColumnName;
            }

            TableName = GetMappedObjectTableName();

            var objList = ReflectedProperties
                .Where(v => v.IsVirtual)
                .Select(mapping => mapping.PropertyDataType)
                .Select(Activator.CreateInstance)
                .ToList();

            var nestedObjList = objList
                .SelectMany(o => GetReflectedProperties(o.GetType()))
                .Where(v => v.IsVirtual)
                .Select(mapping => mapping.PropertyDataType)
                .Select(Activator.CreateInstance)
                .Where(i=>i is RepositoryDecoratedObject)
                .ToList();

            objList.AddRange(nestedObjList);

            var joinToEntityTypes = objList.OfType<RepositoryDecoratedObject>().Distinct().ToList();

            var enumOfDecoratedObj =
                objList
                    .OfType<IEnumerable>()
                    .Select(s => s)
                    .Distinct()
                    .ToList();

            foreach (var decoratedObjectEnum in enumOfDecoratedObj)
            {
                var elementType = decoratedObjectEnum.GetType().GetInnerGenericType();
                var instance = Activator.CreateInstance(elementType);
                if (instance is RepositoryDecoratedObject repositoryDecoratedObject)
                    joinToEntityTypes.Add(repositoryDecoratedObject);
            }

            JoinToEntityTypes = joinToEntityTypes.Distinct().ToArray();
        }

        private bool GetIsNavigationOnly()
        {
            var navigationOnlyAttribute = Attributes.FirstOrDefault(p => p is NavigationOnlyEntityAttribute);

            return navigationOnlyAttribute != null;
        }

        private IEnumerable<ReflectedEntityProperty> GetReflectedProperties(Type objType)
        {
            return objType.GetProperties().Select(p => new ReflectedEntityProperty(p));
        }

        public string GetMappedObjectTableName()
        {
            if (IsNavigationOnly) return GetNavigationOnlyObjectKeyFieldReferenceTableName();

            var tableAttribute = Attributes.FirstOrDefault(p => p is TableAttribute);

            if (tableAttribute is TableAttribute attrib)
                return attrib.Name;

            return string.Empty;
        }

        private string GetNavigationOnlyObjectKeyFieldReferenceTableName()
        {
            var keyFieldReflectedPropertyMap = KeyFieldProperty;
            var foreignKeyPropertyAttribute = keyFieldReflectedPropertyMap.Attributes.FirstOrDefault(a => a is ForeignPropertyAttribute);

            if (foreignKeyPropertyAttribute is ForeignPropertyAttribute attrib)
            {
                var foreignObject = Activator.CreateInstance(attrib.ForeignObjectType);

                if (foreignObject is RepositoryDecoratedObject decoratedObject)
                    return decoratedObject.GetMappedObjectTableName();
            }

            return string.Empty;
        }

    }
}
