﻿using System.Linq.Expressions;

namespace BelleTire.RepositoryFramework.DataMapping.Reflection
{
    public class LinqQueryParser
    {
        public string GetStringForExpressionType(ExpressionType expressionType)
        {
            switch (expressionType)
            {
                case ExpressionType.Increment:
                case ExpressionType.AddChecked:
                case ExpressionType.Add:
                    return "+";

                case ExpressionType.And:
                    return "||";

                case ExpressionType.AndAlso:
                    return "AND";

                case ExpressionType.ArrayLength:
                    return "LENGTH()";

                case ExpressionType.Coalesce:
                    return "NVL()";

               case ExpressionType.Divide:
                    return "/";
                    
                case ExpressionType.Equal:
                    return "=";

                case ExpressionType.GreaterThan:
                    return ">";

                case ExpressionType.GreaterThanOrEqual:
                    return ">=";

                case ExpressionType.LessThan:
                    return "<";
                    
                case ExpressionType.LessThanOrEqual:
                    return "<=";

                case ExpressionType.MultiplyChecked:
                case ExpressionType.Multiply:
                    return "*";

                case ExpressionType.Decrement:
                case ExpressionType.Subtract:
                case ExpressionType.SubtractChecked:
                case ExpressionType.NegateChecked:
                case ExpressionType.Negate:
                    return "-";
                    
                case ExpressionType.UnaryPlus:
                    return "+";

                case ExpressionType.Not:
                    return "NOT";

                case ExpressionType.NotEqual:
                    return "<>";

                case ExpressionType.OrElse:
                case ExpressionType.Or:
                    return "OR";

                case ExpressionType.IsTrue:
                    return "=";

                case ExpressionType.IsFalse:
                    return "!=";
                
            }

            return expressionType.ToString();
        }
    }
}
