﻿using System.Linq;
using BelleTire.RepositoryFramework.Core;
using BelleTire.RepositoryFramework.Interface;

namespace BelleTire.RepositoryFramework.DataMapping.Reflection
{
    public class ReflectedEntityDefinition : IRepositoryQueryEntityDefinition
    {
        public string EntityName { get; }
        public string KeyColumnName { get; }
        public string[] ColumnNames { get; }

        public ReflectedEntityDefinition(IDatabaseMappedObject mappedObject)
        {
            EntityName = mappedObject.GetMappedObjectTableName();
            KeyColumnName = mappedObject.GetMappedObjectKeyFieldColumnName();
            ColumnNames = mappedObject.GetMappedObjectValues().Select(v => v.Key).ToArray();
        }
    }
}
