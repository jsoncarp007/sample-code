﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using BelleTire.RepositoryFramework.Extensions;
using BelleTire.RepositoryFramework.Interface;
using BelleTire.RepositoryFramework.Query;
using BelleTire.RepositoryFramework.Query.ConditionalQuery.MatchCondition;

namespace BelleTire.RepositoryFramework.DataMapping.Reflection
{
    public class RepositoryLinqVisitor : ExpressionVisitor
    {
        public List<object> ValueList { get; set; }
        public RepositoryQueryMatchCondition MatchCondition => 
            new RepositoryQueryRuntimeMatchConditionDefinition(_buffer.ToString())
                .GetConditionForDefinition(ValueList);

        private readonly StringBuilder _buffer;
        
        public RepositoryLinqVisitor()
        {
            ValueList = new List<object>();
            _buffer = new StringBuilder();
        }

        private void ProcessMemberExpression(MemberExpression node)
        {
            IDatabaseMappedObject mappedObject = null;
            if (node.Expression?.Type != null && node.Expression.Type.GetInterfaces().Contains(typeof(IDatabaseMappedObject)))
            {
                var objInstance = Activator.CreateInstance(node.Expression.Type);

                mappedObject = (IDatabaseMappedObject)objInstance;
            }
            else if (node.Member.DeclaringType != null && node.Member.DeclaringType.GetInterfaces().Contains(typeof(IDatabaseMappedObject)))
            {
                var objInstance = Activator.CreateInstance(node.Member.DeclaringType);

                mappedObject = (IDatabaseMappedObject) objInstance;
            }

            string fieldNameForMemberName;

            if (mappedObject != null)
            {
                fieldNameForMemberName =
                    $"{mappedObject.GetMappedObjectTableName()}.{mappedObject.GetColumnNameForPropertyName(node.Member.Name)}";
            }
            else
            {
                var value = new object();
                if ((node.Member as PropertyInfo) != null)
                {
                    if (node.Expression != null)
                    {
                        var exp = (MemberExpression) node.Expression;
                        var constant = (ConstantExpression) exp.Expression;
                        var fieldInfoValue = ((FieldInfo) exp.Member).GetValue(constant.Value);
                        value = ((PropertyInfo) node.Member).GetValue(fieldInfoValue, null);
                    }
                    else
                    {
                        value = Expression.Lambda(node).Compile().DynamicInvoke();
                    }

                }
                else if ((node.Member as FieldInfo) != null)
                {
                    var fieldInfo = node.Member as FieldInfo;
                    var constantExpression = node.Expression as ConstantExpression;
                    if (fieldInfo != null & constantExpression != null)
                    {
                        value = fieldInfo.GetValue(constantExpression.Value);
                    }
                }
                else
                {
                    throw new NotImplementedException("Unsupported member type");
                }

                ValueList.Add(value);

                fieldNameForMemberName = "?";
            }

            _buffer.Append($"{fieldNameForMemberName}");
        }

        private void ProcessMethodCallExpression(MethodCallExpression node)
        {
            if (node.Object is MemberExpression memberExpression)
            {
                IDatabaseMappedObject mappedObject = null;

                if (memberExpression.Member.DeclaringType != null && memberExpression.Member.DeclaringType.GetInterfaces().Contains(typeof(IDatabaseMappedObject)))
                {
                    var objInstance = Activator.CreateInstance(memberExpression.Member.DeclaringType);

                    mappedObject = (IDatabaseMappedObject)objInstance;
                }

                var colAttrib = Attribute.GetCustomAttribute(memberExpression.Member, typeof(ColumnAttribute));

                if (mappedObject != null && colAttrib != null)
                {
                    var colAttribCast = ((ColumnAttribute)colAttrib);
                    var colName = !string.IsNullOrEmpty(colAttribCast.Name)
                        ? colAttribCast.Name
                        : memberExpression.Member.Name;

                    var colFullName = $"{mappedObject.GetMappedObjectTableName()}.{colName}";

                    switch (node.Method.Name)
                    {
                        case "StartsWith":
                            var startsWith = string.Format(RepositoryQueryCondition.BeginsWith.GetDescription(), colFullName);
                            _buffer.Append(startsWith);
                            break;
                        case "EndsWith":
                            var endsWith = string.Format(RepositoryQueryCondition.EndsWith.GetDescription(), colFullName);
                            _buffer.Append(endsWith);
                            break;
                        case "Contains":
                            _buffer.Append($"CONTAINS({colFullName}, ?)");
                            break;

                        default:
                            throw new NotImplementedException($"{node.Method.Name} not implemented");
                    }

                    foreach (var argument in node.Arguments)
                    {
                        ValueList.Add(Expression.Lambda(argument).Compile().DynamicInvoke());
                    }

                    return;
                }
            }

            _buffer.Append("?");
            ValueList.Add(Expression.Lambda(node).Compile().DynamicInvoke());

        }

        protected override Expression VisitConstant(ConstantExpression node)
        {
            ValueList.Add(node.Value);
            _buffer.Append("?");
            return node;
        }

        protected override Expression VisitBinary(BinaryExpression node)
        {
            _buffer.Append("(");

            switch (node.Left)
            {
                case MemberExpression memberExpression:
                    ProcessMemberExpression(memberExpression);
                    break;
                case MethodCallExpression methodCallExpression:
                    ProcessMethodCallExpression(methodCallExpression);
                    break;
                default:
                    this.Visit(node.Left);
                    break;
            }

            var linqParser = new LinqQueryParser();

            _buffer.Append($" {linqParser.GetStringForExpressionType(node.NodeType)} ");

            switch (node.Right)
            {
                case MemberExpression rightMemberExpression:
                    ProcessMemberExpression(rightMemberExpression);
                    break;
                case MethodCallExpression methodCallExpression:
                    ProcessMethodCallExpression(methodCallExpression);
                    break;
                default:
                    this.Visit(node.Right);
                    break;
            }

            _buffer.Append(")");

            return node;
        }

        protected override Expression VisitUnary(UnaryExpression node)
        {
            if (node.NodeType != ExpressionType.Not)
                throw new NotSupportedException("Only not(\"!\") unary operator is supported!");

            _buffer.Append($" {node.NodeType} ");

            _buffer.Append("(");                 
            Visit(node.Operand);                 
            _buffer.Append(")");

            return base.VisitUnary(node);
        }


    }
}
