﻿using System.Collections.Generic;
using System.Linq;
using BelleTire.RepositoryFramework.Entity;

namespace BelleTire.RepositoryFramework.DataMapping.Reflection
{
    public class ReflectedEntityRelationshipDefinition : List<RepositoryQueryEntityRelationship>
    {
        public ReflectedEntityRelationshipDefinition(RepositoryDecoratedObject decoratedObject)
        {
            PopulateCollection(decoratedObject);
        }

        private void PopulateCollection(RepositoryDecoratedObject decoratedObject)
        {
            var joinToEntityDefinitions =
                decoratedObject
                    .GetReflectedMapping()
                    .JoinToEntityTypes
                    .Select(GetEntityForDecoratedObject)
                    .ToList();

            if (!decoratedObject.IsNavigationOnly())
                joinToEntityDefinitions.Add(GetEntityForDecoratedObject(decoratedObject));

            // match entities together by key field definitions
            foreach (var entityDefinition in joinToEntityDefinitions)
            {
                var matchedEntities =
                    joinToEntityDefinitions
                        .Where(def => def.ColumnNames.Contains(entityDefinition.KeyColumnName))
                        .Where(def => def.EntityName != entityDefinition.EntityName)
                        .ToList();

                // TODO: Process ForeignPropertyAttribute to find match when column name isn't same

                if (matchedEntities.Count == 0)
                {
                    Add(new RepositoryQueryEntityRelationship(entityDefinition, entityDefinition.GetKeyColumn(), null, null));
                    return;
                }

                foreach (var matchedEntity in matchedEntities)
                {
                    // add to relationships if not already there, check both join positions
                    if (!this.Any(
                        def =>
                            (def.Entity == entityDefinition
                             && def.JoinToEntity == matchedEntity)
                            ||
                            (def.Entity == matchedEntity
                             && def.JoinToEntity == entityDefinition)))
                    {
                        Add(new RepositoryQueryEntityRelationship(entityDefinition,
                            entityDefinition.GetKeyColumn(), matchedEntity, entityDefinition.GetKeyColumn()));
                    }
                }
            }
        }

        private RepositoryQueryEntity GetEntityForDecoratedObject(RepositoryDecoratedObject decoratedObject)
        {
            return new RepositoryQueryEntity(
                decoratedObject.GetMappedObjectTableName(),
                decoratedObject.GetMappedObjectKeyFieldColumnName(),
                decoratedObject.GetMappedObjectColumnNames());
        }
    }
}