﻿using System;
using System.Collections;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Reflection;
using BelleTire.RepositoryFramework.Core.CustomAttributes;

namespace BelleTire.RepositoryFramework.DataMapping.Reflection
{
    public class ReflectedEntityProperty
    {
        public Type PropertyDataType { get; private set; }
        public int PropertyDataTypeLength { get; private set; }
        public string PropertyName { get; private set; }
        public string ColumnName { get; set; }
        public bool IsPrimaryKey { get; private set; }
        public bool IsValueListNameProperty { get; private set; }
        public object[] Attributes { get; }
        public bool IsVirtual { get; }
        public bool IsEnumerable => PropertyDataType.GetInterfaces().Contains(typeof(IEnumerable));
        public bool HasLookupList => LookupListType != null;
        public Type LookupListType { get; private set; }
        public Type LookupListMatchConditionType { get; private set; }

        private readonly PropertyInfo _propertyInfo;

        public ReflectedEntityProperty(PropertyInfo propertyInfo)
        {
            _propertyInfo = propertyInfo;
            Attributes = propertyInfo.GetCustomAttributes(true);
            IsVirtual = propertyInfo.GetGetMethod().IsVirtual && propertyInfo.Name != "HasVirtualEnumerableChildren";

            SetFromAttributes();
        }

        private void SetFromAttributes()
        {
            PropertyName = _propertyInfo.Name;
            PropertyDataType = _propertyInfo.PropertyType;

            SetColumnName();

            SetPropertiesFromForeignKey();

            SetPropertyDataLength();

            SetIsPrimaryKey();

            SetValueList();

            SetValueListNameProperty();
        }

        private void SetValueListNameProperty()
        {
            var valueListNameProperty = Attributes.FirstOrDefault(attrib => attrib is ValueListNamePropertyAttribute);

            IsValueListNameProperty = valueListNameProperty is ValueListNamePropertyAttribute;
        }

        private void SetValueList()
        {
            var valueListAttribute = Attributes.FirstOrDefault(p => p is ValueListEntityAttribute);

            if (!(valueListAttribute is ValueListEntityAttribute attrib)) return;

            LookupListType = attrib.EntityType;
            LookupListMatchConditionType = attrib.RepositoryMatchConditionType;
        }

        private void SetIsPrimaryKey()
        {
            var keyFieldAttribute =
                Attributes.FirstOrDefault(p => p is KeyAttribute);

            IsPrimaryKey = keyFieldAttribute != null;
        }

        private void SetPropertyDataLength()
        {
            var lengthAttribute = Attributes.FirstOrDefault(p => p is MaxLengthAttribute);

            if (lengthAttribute != null && lengthAttribute is MaxLengthAttribute maxLengthAttrib)
                PropertyDataTypeLength = maxLengthAttrib.Length;
        }

        private void SetPropertiesFromForeignKey()
        {
            var foreignPropertyAttribute = Attributes.FirstOrDefault(a => a is ForeignPropertyAttribute);

            if (foreignPropertyAttribute is ForeignPropertyAttribute foreignPropertyAttrib)
            {
                var foreignObject = Activator.CreateInstance(foreignPropertyAttrib.ForeignObjectType);
                if (foreignObject is RepositoryDecoratedObject decoratedObject)
                {
                    var foreignObjectPropertyReflection = decoratedObject.GetReflectedMapping().ReflectedProperties
                        .First(p => p.PropertyName == foreignPropertyAttrib.ForeignFieldPropertyName);

                    ColumnName = foreignObjectPropertyReflection.ColumnName;
                    PropertyDataTypeLength = foreignObjectPropertyReflection.PropertyDataTypeLength;
                    PropertyDataType = foreignObjectPropertyReflection.PropertyDataType;
                }
            }
        }

        private void SetColumnName()
        {
            var columnAttribute =
                Attributes.FirstOrDefault(p => p is ColumnAttribute);

            if (columnAttribute != null && columnAttribute is ColumnAttribute colAttrib)
                ColumnName = !string.IsNullOrEmpty(colAttrib.Name) ? colAttrib.Name : PropertyName;
        }

        public void SetPropertyValue(object targetObject, object valueToSet)
        {
            if (valueToSet != DBNull.Value && _propertyInfo.CanWrite)
            {
                if (valueToSet is string str)
                    _propertyInfo.SetValue(targetObject, str.Trim());
                else
                    _propertyInfo.SetValue(targetObject, valueToSet);
            }
        }

        public object GetPropertyValue(object targetObject)
        {
            return _propertyInfo.GetValue(targetObject);
        }
    }
}
