﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using BelleTire.RepositoryFramework.DataMapping.Reflection;
using Hyper.ComponentModel;

namespace BelleTire.RepositoryFramework.DataMapping
{
    public class DecoratedObjectReflection
    {
        public static readonly Dictionary<Type, RepositoryDecoratedObjectReflectedMapping> DecoratedObjectMap =
            new Dictionary<Type, RepositoryDecoratedObjectReflectedMapping>();

        public static RepositoryDecoratedObjectReflectedMapping InitReflectedMapping(Type typeToInit)
        {
            RepositoryDecoratedObjectReflectedMapping reflectedObjectMapping;

            lock (DecoratedObjectMap)
            {
                if (!DecoratedObjectMap.ContainsKey(typeToInit))
                {
                    reflectedObjectMapping = new RepositoryDecoratedObjectReflectedMapping(typeToInit);

                    InitHyperAccessorForType(typeToInit);

                    DecoratedObjectMap.Add(typeToInit, reflectedObjectMapping);
                    
                }
                else
                {
                    reflectedObjectMapping = DecoratedObjectMap[typeToInit];
                }
            }

            return reflectedObjectMapping;
        }

        private static void InitHyperAccessorForType(Type typeToInit)
        {
            HyperTypeDescriptionProvider.Add(typeToInit);
        }

        public static void LoadFromDataRow(object objectToSet, DataRow dr,
            RepositoryDecoratedObjectReflectedMapping mapping, string[] tableNames)
        {
            foreach (var property in mapping.ReflectedProperties.Where(p => !p.IsVirtual))
            {
                if (!string.IsNullOrEmpty(property.ColumnName) && dr.Table.Columns.OfType<DataColumn>()
                    .Any(c => c.ColumnName == property.ColumnName))
                    property.SetPropertyValue(objectToSet, dr[property.ColumnName]);
                else
                {
                    if (tableNames.Length > 0)
                    {
                        foreach (var tableName in tableNames)
                        {
                            if (!string.IsNullOrEmpty(property.ColumnName) && dr.Table.Columns.OfType<DataColumn>()
                                .Any(c => tableName + "_" + property.ColumnName == c.ColumnName))
                                property.SetPropertyValue(objectToSet, dr[tableName + "_" + property.ColumnName]);
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(property.ColumnName) && dr.Table.Columns.OfType<DataColumn>()
                            .Any(c => c.ColumnName.EndsWith(property.ColumnName)))
                        {
                            var dataRowColumnName = dr.Table.Columns.OfType<DataColumn>()
                                .First(c => c.ColumnName.EndsWith(property.ColumnName));

                            property.SetPropertyValue(objectToSet, dr[dataRowColumnName]);
                        }
                    }
                }
            }

            foreach (var property in mapping.ReflectedProperties.Where(p => p.IsVirtual))
            {
                // create the virtual object
                var instanceOfProperty = Activator.CreateInstance(property.PropertyDataType);

                if (instanceOfProperty is RepositoryDecoratedObject decoratedObject)
                {
                    // call this method on it
                    LoadFromDataRow(instanceOfProperty, dr, decoratedObject.GetReflectedMapping(), tableNames);
                    //decoratedObject.LoadFromDataRow(dr);
                }

                property.SetPropertyValue(objectToSet, instanceOfProperty);


            }
        }
    }
}
