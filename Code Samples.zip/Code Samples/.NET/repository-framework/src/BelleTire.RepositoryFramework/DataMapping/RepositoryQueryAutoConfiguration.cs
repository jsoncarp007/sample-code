﻿using System;
using System.Collections.Generic;
using System.Linq;
using BelleTire.RepositoryFramework.Core;
using BelleTire.RepositoryFramework.DataMapping.Reflection;
using BelleTire.RepositoryFramework.Entity;
using BelleTire.RepositoryFramework.Interface;

namespace BelleTire.RepositoryFramework.DataMapping
{
    public class RepositoryQueryAutoConfiguration : IRepositoryQueryConfiguration
    {
        public RepositoryQueryEntity PrimaryEntity => Relationships?
            .FirstOrDefault(e=>e.JoinToEntity == null)?.Entity 
                                                      ?? Relationships?.FirstOrDefault()?.Entity;
        private string PrimaryEntityName => PrimaryEntity?.EntityName;
        private List<RepositoryQueryEntityRelationship> Relationships { get; }

        private string[] ColumnStrings => GetColumnStrings();

        private List<RepositoryQueryEntity> Entities => GetUniqueEntities();

        public string SelectSqlBase => GetSelectSql();
        public string InsertSqlBase => $"INSERT INTO {PrimaryEntityName}";
        public string DeleteSqlBase => $"DELETE FROM {PrimaryEntityName}";
        public string UpdateSqlBase => $"UPDATE {PrimaryEntityName}";
        
        public RepositoryQueryAutoConfiguration(string primaryEntityName, string primaryEntityKeyColumnName, string[] primaryEntityIncludeColumns)
        {
           var primaryEntity = new RepositoryQueryEntity(primaryEntityName, primaryEntityKeyColumnName, primaryEntityIncludeColumns);

            Relationships = new List<RepositoryQueryEntityRelationship>()
            {
                new RepositoryQueryEntityRelationship(primaryEntity, primaryEntity.GetKeyColumn(), null, null)
            };
        }

        public RepositoryQueryAutoConfiguration(RepositoryDecoratedObject decoratedObject)
        {
            Relationships = new ReflectedEntityRelationshipDefinition(decoratedObject);
        }

        public RepositoryQueryAutoConfiguration(IEnumerable<RepositoryQueryEntityRelationship> relationships)
        {
            Relationships = relationships.ToList();
        }

        public RepositoryQueryAutoConfiguration(IRepositoryQueryEntityDefinition entityDefinition)
        : this(entityDefinition.EntityName, entityDefinition.KeyColumnName, entityDefinition.ColumnNames)
        {
        }

        private List<RepositoryQueryEntity> GetUniqueEntities()
        {
            List<RepositoryQueryEntity> uniqueEntities = new List<RepositoryQueryEntity>();

            foreach (var relationship in Relationships)
            {
                if (uniqueEntities.All(u=>u.EntityName != relationship.Entity.EntityName))
                    uniqueEntities.Add(relationship.Entity);
                if (relationship.JoinToEntity != null && uniqueEntities.All(u => u.EntityName != relationship.JoinToEntity.EntityName))
                    uniqueEntities.Add(relationship.JoinToEntity);
            }

            return uniqueEntities;
        }

        private string[] GetColumnStrings()
        {
            if (Entities == null) return new string[] {};

            // build a list of entities and columns, strip out any duplicate id columns, give alternate return name to other dupes
            var allColumnNames = Entities.SelectMany(e => e.ColumnNames).ToList();
            var columnNamesAdded = new List<string>();
            var entityColumnList = new List<KeyValuePair<string, string>>();
            foreach (var entity in Entities)
            {
                foreach (var columnName in entity.ColumnNames.Where(c=>!string.IsNullOrEmpty(c)))
                {
                    if (allColumnNames.Count(e => e == columnName) == 1 || !columnNamesAdded.Contains(columnName))  // only one column with this name or only one added so far
                    {
                        entityColumnList.Add(new KeyValuePair<string, string>(entity.EntityName, columnName));
                    }
                    else 
                    {
                        if (!columnName.ToLower().EndsWith("_id")) // only add the first instance of a duplicate id field
                        {
                            // add the current duplicate column name with the adjusted "return as" column name format: entity_name_column_name
                            entityColumnList.Add(new KeyValuePair<string, string>(entity.EntityName,
                                $"{columnName} as {entity.EntityName}_{columnName}"));
                        }
                    }
                    columnNamesAdded.Add(columnName);
                }
            }

            return entityColumnList.Select(e => $"{e.Key}.{e.Value}").ToArray();
        }

        private string GetSelectSql()
        {
            string sql = "SELECT ";

            sql += string.Join(", ", ColumnStrings) + Environment.NewLine;

            sql += $"FROM {PrimaryEntityName}{Environment.NewLine}{Environment.NewLine}";

            foreach (var relationship in Relationships)
            {
                if (relationship.JoinToEntity == null) continue;

                var joinToTable = relationship.Entity.EntityName == PrimaryEntityName
                    ? relationship.JoinToEntity.EntityName
                    : relationship.Entity.EntityName;

                var joinToTableColumn = relationship.Entity.EntityName == PrimaryEntityName
                    ? relationship.JoinToEntityColumn.Name
                    : relationship.EntityColumn.Name;

                var joinFromTable = relationship.Entity.EntityName == PrimaryEntityName
                    ? relationship.Entity.EntityName
                    : relationship.JoinToEntity.EntityName;

                var joinFromTableColumn = relationship.Entity.EntityName == PrimaryEntityName
                    ? relationship.EntityColumn.Name
                    : relationship.JoinToEntityColumn.Name;


                sql += "\t";
                sql += relationship.IsOuterJoin ? "OUTER" : "INNER";
                sql += " JOIN ";
                sql += joinToTable;
                sql += $" ON {joinToTable}.{joinToTableColumn} = {joinFromTable}.{joinFromTableColumn} {Environment.NewLine}";
            }

            return sql;
        }
    }
}
