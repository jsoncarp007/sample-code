﻿using System;
using BelleTire.RepositoryFramework.Query;

namespace BelleTire.RepositoryFramework.Interface
{
    public interface IRepositoryDataProviderFormatting
    {
        string DateTimeFormatString { get; }
        string TopRecordsString { get; }

        string GetValueAsQueryFriendlyString(object value);

        string GetFormatStringForCondition(RepositoryQueryCondition condition);
        string GetPhoneFormat(string phone);
        string GetDatabaseTypeStringForObjectType(Type objectType, int length);
    }
}
