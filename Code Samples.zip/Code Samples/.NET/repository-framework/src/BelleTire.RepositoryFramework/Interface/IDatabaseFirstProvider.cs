﻿using System.Collections.Generic;
using BelleTire.RepositoryFramework.DataProviders;

namespace BelleTire.RepositoryFramework.Interface
{
    public interface IDatabaseFirstProvider
    {
        string GenerateClass(string tableName, string classNamespace);
        List<DatabaseColumnProperties> GetColumnPropertiesListForTable(string tableName);
    }
}
