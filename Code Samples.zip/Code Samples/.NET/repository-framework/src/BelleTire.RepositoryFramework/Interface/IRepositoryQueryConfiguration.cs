﻿namespace BelleTire.RepositoryFramework.Interface
{
    public interface IRepositoryQueryConfiguration
    {
        string SelectSqlBase { get; }
        string InsertSqlBase { get; }
        string DeleteSqlBase { get; }
        string UpdateSqlBase { get; }
    }
}
