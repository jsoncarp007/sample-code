﻿using System.Collections.Generic;
using System.Data;
using BelleTire.RepositoryFramework.DataMapping.Reflection;

namespace BelleTire.RepositoryFramework.Interface
{
    public interface IDatabaseMappedObject
    {
        Dictionary<string, object> GetMappedObjectValues();
        void LoadFromDataRow(DataRow dr);
        void LoadFromDataTable(DataTable dt);
        string[] GetMappedObjectColumnNames();
        string GetMappedObjectKeyFieldColumnName();
        object GetMappedObjectKeyFieldValue();
        string GetMappedObjectTableName();
        string GetColumnNameForPropertyName(string propertyName);
        RepositoryDecoratedObjectReflectedMapping GetReflectedMapping();
        bool IsNavigationOnly();
        string GetValueListNamePropertyValue();
        string GetValueListNamePropertyColumnName();
        bool HasVirtualEnumerableChildren();
    }
}
