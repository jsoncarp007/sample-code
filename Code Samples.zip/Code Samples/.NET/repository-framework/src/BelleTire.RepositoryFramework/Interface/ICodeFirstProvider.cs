﻿using BelleTire.RepositoryFramework.DataMapping;

namespace BelleTire.RepositoryFramework.Interface
{
    public interface ICodeFirstProvider
    {
        bool CreateTableForObject(RepositoryDecoratedObject decoratedObject);
    }
}
