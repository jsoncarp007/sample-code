﻿using System.Data;
using BelleTire.RepositoryFramework.Query;

namespace BelleTire.RepositoryFramework.Interface
{
    public interface IRepositoryDataProvider
    {
        IRepositoryDataProviderFormatting Formatting { get; }

        DataTable GetDataTable(RepositorySelectQuery query, int timeout = int.MaxValue);
        DataTable GetDataTable(string sqlQueryText, int timeout = int.MaxValue);
        int ExecuteQuery(RepositoryQuery query, int timeout = int.MaxValue);
        int ExecuteQuery(string querySql, int timeout = int.MaxValue);
        void SetDataProvider(RepositoryQuery query);
        bool StoredProcedureExists(string storedProcedureName);
        void AddStoredProcedureToList(string storedProcedureName);
    }
}
