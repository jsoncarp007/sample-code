﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using BelleTire.Framework.DatabaseIO.DBObject;
using BelleTire.RepositoryFramework.DataProviders.CodeFirst;
using BelleTire.RepositoryFramework.DataProviders.Formatting;
using BelleTire.RepositoryFramework.Interface;
using BelleTire.RepositoryFramework.Query;
using BelleTire.RepositoryFramework.Query.Parameter;
using IBM.Data.Informix;

namespace BelleTire.RepositoryFramework.DataProviders
{
    public class InformixDataProvider : IRepositoryDataProvider
    {
        public List<string> StoredProceduresList => _storedProceduresList;
        private static List<string> _storedProceduresList;

        public IRepositoryDataProviderFormatting Formatting { get; }

        private DatabaseObj _db;
        private string _normalConnString;

        public bool RecreateStoredProcedures { get; set; }

        private InformixDataProvider()
        {
            Formatting = new InformixDataFormatting();
            RecreateStoredProcedures = false;
        }

        public InformixDataProvider(DatabaseObj db) : this()
        {
            _db = db;
            _normalConnString = _db.ConnString;
            InitRepositoryStoredProceduresList();
        }

        public DatabaseObj GetDatabaseObj()
        {
            return _db;
        }

        public DataTable GetDataTable(RepositorySelectQuery query, int timeout = int.MaxValue)
        {
            SetDataProvider(query);

            var storedProcedureExists = FindOrCreateStoredProcedure(query);

            var ifxParams = GetIfxParams(query, storedProcedureExists).ToList();

            string queryText = storedProcedureExists
                ? BuildExecuteProcedureString(query.QueryName, ifxParams)
                : query.Query;

            Console.WriteLine("InformixDataProvider - executing: {0}", queryText);

            return _db.GetDataTable(queryText, ifxParams.ToArray(), timeout);
        }

        public DataTable GetDataTable(string sqlQueryText, int timeout = Int32.MaxValue)
        {
            return _db.GetDataTable(sqlQueryText, timeout);
        }

        public DataTable GetDataTable(string sqlQueryText, IfxParameter[] ifxParameters = null, int timeout = Int32.MaxValue)
        {
            return ifxParameters != null
            ? _db.GetDataTable(sqlQueryText, timeout)
            : _db.GetDataTable(sqlQueryText, ifxParameters, timeout);
        }

        public int RemoveStoredProceduresStartingWith(string matchString)
        {
            SetElevatedPrivilegesIfAvailable();

            int numRemoved = 0;
            int numFailed = 0;

            var storedProceduresMatchingSearchString =
                _storedProceduresList.Where(s => s.ToLower().StartsWith(matchString));

            foreach (var sp in storedProceduresMatchingSearchString)
            {
                string dropSql = $"DROP PROCEDURE {sp}";
                try
                {
                    ExecuteNonQuery(dropSql);
                    numRemoved++;
                }
                catch (Exception ex)
                {
                    var s = ex.Message;
                    numFailed++;
                }
            }

            SetNormalPrivileges();

            Console.WriteLine("Removed {0} stored procdured, could not remove {1}", numRemoved, numFailed);

            return numRemoved;
        }

        private string BuildExecuteProcedureString(string queryName, List<IfxParameter> ifxParams)
        {
            var parameterList = new List<string>();
            List<IfxParameter> ifxParamsToRemove = new List<IfxParameter>();
            foreach (var ifxParam in ifxParams)
            {
                if (ifxParam.Value is string)
                {
                    if (ifxParam.Value.ToString().StartsWith("LIST{"))
                    {
                        parameterList.Add(ifxParam.Value.ToString());
                        ifxParamsToRemove.Add(ifxParam);
                    }
                    else
                        parameterList.Add("?");
                }
                else if (ifxParam.Value is IEnumerable enumerable)
                {
                    var enumItemValueAsStringList = new List<string>();
                    foreach (var item in enumerable)
                    {
                        var formattedItem = Formatting.GetValueAsQueryFriendlyString(item);
                        enumItemValueAsStringList.Add(formattedItem);
                    }

                    string enumAsCommaSeparatedString = string.Join(",", enumItemValueAsStringList);
                    string currentListString = $"LIST{{{enumAsCommaSeparatedString}}}";
                    parameterList.Add(currentListString);
                    ifxParamsToRemove.Add(ifxParam);
                }
                else
                    parameterList.Add("?");
            }

            ifxParams.RemoveAll(ifxParam=>ifxParamsToRemove.Contains(ifxParam));

            return $"EXECUTE PROCEDURE {queryName}({string.Join(",", parameterList)})";
        }

        private string ReplaceListValues(string queryText, List<IfxParameter> ifxParams)
        {
            foreach (var ifxParam in ifxParams.ToArray())
            {
                if (ifxParam.Value != null && ifxParam.Value.ToString().StartsWith("LIST{"))
                {
                    var extractedListValues =
                        ifxParam
                            .Value
                            .ToString()
                            .Replace("LIST{", string.Empty)
                            .Replace("}", string.Empty);

                    queryText = queryText.Replace("SELECT * FROM TABLE(?)", $"{extractedListValues}");
                    ifxParams.Remove(ifxParam);
                }
            }

            return queryText;
        }

        private bool FindOrCreateStoredProcedure(RepositorySelectQuery query)
        {
            // check if the SP for this select query exists
            bool storedProcedureExists = StoredProcedureExists(query.QueryName);

            // see if we set the RecreateStoredProcedures flag, if so remove it if it exists
            if (storedProcedureExists && RecreateStoredProcedures)
            {
                try
                {
                    Console.WriteLine($"Dropping procedure: {query.QueryName}");

                    RemoveStoredProceduresStartingWith(query.QueryName);

                    Console.WriteLine($"Procedure {query.QueryName} dropped");

                    storedProcedureExists = false;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Failed to drop {query.QueryName}.  Error: {ex.Message}");
                }
            }

            // if it doesn't exist, see if we can create it
            if (!storedProcedureExists && SetElevatedPrivilegesIfAvailable())
            {
                Console.WriteLine("InformixDataProvider - creating stored procedure for {0}", query.QueryName);

                var ifxStoredProcedureFactory = new InformixStoredProcedureFactory(this);
                int result = ifxStoredProcedureFactory.CreateStoredProcedure(query);
                if (result > -1)
                {
                    AddStoredProcedureToList(query.QueryName);
                    storedProcedureExists = StoredProcedureExists(query.QueryName);
                }
                SetNormalPrivileges();
            }

            return storedProcedureExists;
        }

        public int ExecuteQuery(RepositoryQuery query, int timeout = int.MaxValue)
        {
            SetDataProvider(query);

            var ifxParams = GetIfxParams(query, false);

            var ifxParamsList = ifxParams.ToList();
            string parsedQueryText = ReplaceListValues(query.Query, ifxParamsList);

            ifxParams = ifxParamsList.ToArray();

            if (query is RepositoryUpdateQuery)
                return _db.UpdateData(parsedQueryText, ifxParams);

            if (query is RepositoryDeleteQuery)
                return _db.DeleteData(parsedQueryText, ifxParams);

            if (query is RepositoryInsertQuery)
                return _db.InsertDataReturnSerial(parsedQueryText, ifxParams);

            Console.WriteLine("InformixDataProvider - Executing {0}: {1}", query.GetType().Name, parsedQueryText);

            return _db.ExecProcRetInt(query.Query, ifxParams, timeout);
        }

        public int ExecuteQuery(string querySql, int timeout = int.MaxValue)
        {
            return _db.ExecProcRetInt(querySql);
        }

        public int ExecuteNonQuery(string nonQuerySql)
        {
            IfxCommand cmd = new IfxCommand(nonQuerySql);
            return _db.ExecuteNonQuery(cmd);
        }

        public void SetDataProvider(RepositoryQuery query)
        {
            query.SetDataProviderFormatting(this.Formatting);
        }

        private bool SetElevatedPrivilegesIfAvailable()
        {
            if (_db.ConnString.Contains("dbadm")) return true;

            var adminConnStringParts = new List<string>();
            var splitConnString = _db.ConnString.Split(';');

            foreach (var item in splitConnString)
            {
                var keyValuePair = item.Split('=');

                if (keyValuePair[0].ToLower() == "user id")
                {
                    keyValuePair[1] = "dbadm";
                }
                else if (keyValuePair[0].ToLower() == "password")
                {
                    keyValuePair[1] = "flunkus";
                }

                adminConnStringParts.Add($"{keyValuePair[0]}={keyValuePair[1]}");
            }

            _db = new DatabaseObj(string.Join(";", adminConnStringParts));

            Console.WriteLine("InformixDataProvider - Using admin connection string to create a procedure...");

            return true;

            //try
            //{
            //    // see if we have an _admin connection string in the executing project .config
            //    var adminConnStringName = ConfigurationManager.AppSettings["activeInformixConnectionStringName"] + "_admin";

            //    var connectionString = ConfigurationManager.ConnectionStrings[adminConnStringName];

            //    if (connectionString == null) return false;

            //    var adminConnString = connectionString.ConnectionString;
            //    _db = new DatabaseObj(adminConnString);
            //    Console.WriteLine("InformixDataProvider - Using admin connection string to create a procedure...");
            //    return true;
            //}
            //catch
            //{
            //    return false;
            //}
        }

        private void SetNormalPrivileges()
        {
            _db = new DatabaseObj(_normalConnString);
            Console.WriteLine("InformixDataProvider - Normal DB privileges restored");
        }

        private IfxParameter[] GetIfxParams(RepositoryQuery query, bool storedProcedureFormat)
        {
            var queryParameters = query.GetQueryParameters();

            foreach (var queryParameter in queryParameters)
            {
                if (!(queryParameter.Value is string) && queryParameter.Value is IEnumerable enumValue)
                {
                    List<string> valuesAsStrings = new List<string>();
                    foreach (var item in enumValue)
                    {
                        valuesAsStrings.Add(item.ToString());
                    }
                    //var dataListString = string.Join(",", $"'{valuesAsStrings}'");
                    var dataListString = string.Join(",", valuesAsStrings);
                    queryParameter.Value = $"LIST{{{dataListString}}}";
                }
            }

            if (storedProcedureFormat)
                return queryParameters
                .Select(p => new IfxParameter(p.SourceColumnIdentifier, p.Value))
                .ToArray();

            var orderedParamDictionary =
                new RepositoryQueryParameterFactory().GetOrderedParametersDictionary(queryParameters.ToList());

            var retArray = orderedParamDictionary
                .Select(orderedParam => orderedParam.Value)
                .Select(queryParam => new IfxParameter(queryParam.SourceColumnIdentifier, queryParam.Value))
                .ToArray();

            return retArray;
        }

        private void InitRepositoryStoredProceduresList()
        {
            if (_storedProceduresList == null)
                _storedProceduresList =
                    new InformixInformationProvider(this).GetStoredProcedureNames(
                        "get_").ToList();
        }

        public bool StoredProcedureExists(string storedProcedureName)
        {
            return _storedProceduresList.Contains(storedProcedureName);
        }

        public void AddStoredProcedureToList(string storedProcedureName)
        {
            _storedProceduresList.Add(storedProcedureName);
        }
    }
}
