﻿using System;
using System.Collections.Generic;
using System.Linq;
using BelleTire.RepositoryFramework.Interface;
using BelleTire.RepositoryFramework.Query;

namespace BelleTire.RepositoryFramework.DataProviders.Formatting
{
    public class MsSqlDataFormatting : IRepositoryDataProviderFormatting
    {
        public string DateTimeFormatString => "'{0:MM/dd/YYYY HH:mm:ss.fff}'";
        public string TopRecordsString => "TOP";

        public string GetValueAsQueryFriendlyString(object value)
        {
            if (value == null)
                return "null";

            if (value is DateTime dt)
                return string.Format(DateTimeFormatString, dt);

            if (value is IEnumerable<int> enumInt)
            {
                return string.Join(",", enumInt);
            }
            if (value is IEnumerable<decimal> enumDec)
            {
                return string.Join(",", enumDec);
            }
            if (value is IEnumerable<double> enumDouble)
            {
                return string.Join(",", enumDouble);
            }
            if (value is IEnumerable<DateTime> enumDt)
            {
                return string.Join(",", string.Format(DateTimeFormatString, enumDt));
            }
            if (value is IEnumerable<string> enumString)
            {
                return string.Join(",", enumString.Select(l => "'" + l + "'"));
            }

            return value.ToString();
        }

        public string GetFormatStringForCondition(RepositoryQueryCondition condition)
        {
            switch (condition)
            {
                case RepositoryQueryCondition.Equals:
                    return "= ?";
                   
                case RepositoryQueryCondition.GreaterThan:
                    return "> ?";

                case RepositoryQueryCondition.GreaterThanOrEqual:
                    return ">= ?";

                case RepositoryQueryCondition.LessThan:
                    return "< ?";
                  
                case RepositoryQueryCondition.LessThanOrEqual:
                    return "<= ?";

                case RepositoryQueryCondition.NotEqual:
                    return "<> ?";

                case RepositoryQueryCondition.IsNotNull:
                    return "IS NOT NULL";

                case RepositoryQueryCondition.IsNull:
                    return "IS NULL";
                  
                case RepositoryQueryCondition.InList:
                    return "IN ({X})";

                case RepositoryQueryCondition.Between:
                   return "BETWEEN ? AND ?";

                case RepositoryQueryCondition.BeginsWith:
                    return "LIKE ? + '%'";
                   
                case RepositoryQueryCondition.EndsWith:
                    return "LIKE '%' + ?";

                case RepositoryQueryCondition.And:
                    return "AND ?";

                case RepositoryQueryCondition.Or:
                    return "OR ?";

                default:
                    throw new ArgumentOutOfRangeException(nameof(condition), condition, null);
            }
        }

        public string GetPhoneFormat(string phone)
        {
            return new CommonFormatting().GetCommonPhoneFormat(phone);
        }

        public string GetDatabaseTypeStringForObjectType(Type objectType, int length)
        {
            throw new NotImplementedException();
        }

        public string GetDatabaseTypeStringForObjectType(Type objectType)
        {
            throw new NotImplementedException();
        }
    }
}
