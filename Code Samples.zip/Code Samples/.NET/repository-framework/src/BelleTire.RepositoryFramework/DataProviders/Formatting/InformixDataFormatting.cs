﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using BelleTire.RepositoryFramework.Interface;
using BelleTire.RepositoryFramework.Query;

namespace BelleTire.RepositoryFramework.DataProviders.Formatting
{
    public class InformixDataFormatting : IRepositoryDataProviderFormatting
    {
        public string DateTimeFormatString =>  "TO_DATE('{0:yyyy-MM-dd HH:mm:ss.fff}','%Y-%m-%d %H:%M:%S.%F3')";
        public string TopRecordsString => "FIRST";

        public string GetValueAsQueryFriendlyString(object value)
        {
            if (value == null)
                return "null";

            if (value is string s)
                return $"'{s.Replace("'", "''")}'";

            if (value is DateTime dt)
                return string.Format(DateTimeFormatString, dt);

            if (value is IEnumerable enumerable)
            {
                List<object> objectList = new List<object>();
                foreach (var item in enumerable)
                {
                    objectList.Add(item);
                }
                return string.Join(",", objectList.Select(GetValueAsQueryFriendlyString));
            }
            if (value is int || value is decimal || value is double || value is float)
            {
                return value.ToString();
            }
            if (value is bool valueBool)
            {
                return valueBool ? "1" : "null";
            }

            string retString = value.ToString().Replace("'", "''");
            return $"'{retString}'";
        }

        public string GetFormatStringForCondition(RepositoryQueryCondition condition)
        {
            switch (condition)
            {
                case RepositoryQueryCondition.Equals:
                    return "= ?";
                   
                case RepositoryQueryCondition.GreaterThan:
                    return "> ?";

                case RepositoryQueryCondition.GreaterThanOrEqual:
                    return ">= ?";

                case RepositoryQueryCondition.LessThan:
                    return "< ?";
                  
                case RepositoryQueryCondition.LessThanOrEqual:
                    return "<= ?";

                case RepositoryQueryCondition.NotEqual:
                    return "<> ?";

                case RepositoryQueryCondition.IsNotNull:
                    return "IS NOT NULL";

                case RepositoryQueryCondition.IsNull:
                    return "IS NULL";
                  
                case RepositoryQueryCondition.InList:
                    return "IN (SELECT * FROM TABLE(?))";

                case RepositoryQueryCondition.Between:
                   return "BETWEEN ? AND ?";

                case RepositoryQueryCondition.BeginsWith:
                    return "LIKE ? || '%'";
                   
                case RepositoryQueryCondition.EndsWith:
                    return "LIKE '%' || ?";

                case RepositoryQueryCondition.And:
                    return "AND ?";
                    
                case RepositoryQueryCondition.Or:
                    return "OR ?";
                    
                default:
                    throw new ArgumentOutOfRangeException(nameof(condition), condition, null);
            }
        }

        public string GetPhoneFormat(string phone)
        {
            return new CommonFormatting().GetCommonPhoneFormat(phone);
        }

        public string GetDatabaseTypeStringForObjectType(Type objectType, int length = 0)
        {
            if (objectType == typeof(string))
            {
                int len = length > 0 ? length : 25;
                return $"CHAR({len})";
            }

            if (objectType.GetInterfaces().Contains(typeof(IEnumerable)))
            {
                var enumType = objectType.GetGenericArguments()[0];
                return $"LIST({GetDatabaseTypeStringForObjectType(enumType)} NOT NULL)";
            }

            if (objectType == typeof(DateTime))
                return "DATETIME YEAR to SECOND NOT NULL";
            if (objectType == typeof(DateTime?))
                return "DATETIME YEAR to SECOND";
            if (objectType == typeof(int))
                return "INT";
            if (objectType == typeof(decimal))
                return "DECIMAL";
            if (objectType == typeof(float))
                return "FLOAT";
            if (objectType == typeof(bool))
                return "INT";

            return string.Empty;
        }
    }
}
