﻿namespace BelleTire.RepositoryFramework.DataProviders.Formatting
{
    public class CommonFormatting
    {
        public string GetCommonPhoneFormat(string phone)
        {
            if (string.IsNullOrEmpty(phone)) return string.Empty;

            phone = phone.Replace("(", string.Empty);
            phone = phone.Replace(")", string.Empty);
            phone = phone.Replace("-", string.Empty);

            if (phone.Length != 10)
                return phone;

            phone = phone.Insert(3, "-");
            phone = phone.Insert(7, "-");
            return phone;
        }
    }
}
