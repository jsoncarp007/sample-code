﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BelleTire.RepositoryFramework.DataProviders.DatabaseFirst
{
    public class DatabaseFirstClassFactory
    {
        private readonly string[] _usingStatements =
        {
            "using System;",
            "using System.ComponentModel.DataAnnotations;",
            "using System.ComponentModel.DataAnnotations.Schema;",
            "using BelleTire.Framework.RepositoryFramework.DataMapping;"
        };

        private string NamespaceLine => $"namespace {_namespace}.Entities";
        private string ClassTableAttributeLine => $"[Table(\"{_tableName}\")]";
        private string ClassLine => $"public class {_className} : RepositoryDecoratedObject";

        private readonly string _tableName;
        private readonly string _className;
        private readonly string _namespace;
        private readonly List<DatabaseColumnProperties> _columnProperties;

        public DatabaseFirstClassFactory(string tableName, string className, string classNamespace, List<DatabaseColumnProperties> columnProperties)
        {
            _tableName = tableName;
            _className = className;
            _namespace = classNamespace;
            _columnProperties = columnProperties;
        }

        public string GetClassText()
        {
            var sb = new StringBuilder();

            foreach (var usingStatement in _usingStatements)
            {
                sb.AppendLine(usingStatement);
            }
            sb.AppendLine();
            sb.AppendLine(NamespaceLine);
            sb.AppendLine("{"); // begin namespace
            sb.AppendLine($"\t{ClassTableAttributeLine}");
            sb.AppendLine($"\t{ClassLine}");
            sb.AppendLine("\t{"); // begin class
            foreach (var line in GetClassPropertyLines())
            {
                sb.AppendLine($"\t\t{line}");
            }
            sb.AppendLine("\t}");  // end class
            sb.AppendLine("}");  // end namespace

            return sb.ToString();
        }

        private List<string> GetClassPropertyLines()
        {
            return _columnProperties.SelectMany(p=>GetPropertyLinesForColumn(p)).ToList();
        }

        private List<string> GetPropertyLinesForColumn(DatabaseColumnProperties columnProperties, bool addDisplayProperties = true)
        {
            List<string> propertyLines = new List<string>();

            if (columnProperties.IsKeyColumn)
            {
                propertyLines.Add("[Key]");

                if (addDisplayProperties)
                    propertyLines.Add("[Display(AutoGenerateField = false)]");
            }

            propertyLines.Add($"[Column(\"{columnProperties.ColumnName}\")]");

            if (columnProperties.DataType == typeof(string))
            {
                propertyLines.Add($"[MaxLength({columnProperties.DataTypeLength},ErrorMessage=\"Max length is {columnProperties.DataTypeLength}\")]");
            }

            propertyLines.Add($"public {GetNameForType(columnProperties.DataType)} {columnProperties.PropertyName} {{ get; set; }}");
            propertyLines.Add(string.Empty);

            return propertyLines;
        }

        private string GetNameForType(Type type)
        {
            if (type == typeof(int))
                return "int";
            if (type == typeof(int?))
                return "int?";
            if (type == typeof(string))
                return "string";
            if (type == typeof(DateTime))
                return "DateTime";
            if (type == typeof(DateTime?))
                return "DateTime?";
            if (type == typeof(bool))
                return "bool";
            if (type == typeof(bool?))
                return "bool?";
            if (type == typeof(decimal))
                return "decimal";
            if (type == typeof(decimal?))
                return "decimal?";
            if (type == typeof(float))
                return "float";
            if (type == typeof(float?))
                return "float?";
            if (type == typeof(double))
                return "double";

            return "string";

        }
    }

    public class DatabaseFirstRepositoryClassFactory
    {
        private string[] UsingStatements => new []
        {
            $"using {_namespace}.Entities;",
            "using BelleTire.Framework.RepositoryFramework.DataMapping;",
            "using BelleTire.Framework.RepositoryFramework.DataMapping.Reflection;",
            "using BelleTire.Framework.RepositoryFramework.Interface;",
            "using BelleTire.Framework.RepositoryFramework.Repository;"
        };

        private string NamespaceLine => $"namespace {_namespace}";

        private string ClassLine => $"public class {_className}Repository : Repository";

        private string[] PropertyLines => new[]
        {
            "protected override IRepositoryQueryConfiguration QueryConfiguration => new RepositoryQueryAutoConfiguration(EntityDefinition);",
            $"protected override IRepositoryQueryEntityDefinition EntityDefinition => new ReflectedEntityDefinition(new {_className}());",
        };

        private string ConstructorLine =>
            $"public {_className}Repository(IRepositoryDataProvider dataProvider) : base(dataProvider)";

        private readonly string _className;
        private readonly string _namespace;

        public DatabaseFirstRepositoryClassFactory(string className, string classNamespace)
        {
            _className = className;
            _namespace = classNamespace;
        }

        public string GetClassText()
        {
            var sb = new StringBuilder();

            foreach (var usingStatement in UsingStatements)
            {
                sb.AppendLine(usingStatement);
            }

            sb.AppendLine();
            sb.AppendLine(NamespaceLine);
            sb.AppendLine("{"); // begin namespace
            sb.AppendLine($"\t{ClassLine}");
            sb.AppendLine("\t{"); // begin class
            foreach (var line in PropertyLines)
            {
                sb.AppendLine($"\t\t{line}");
            }
            sb.AppendLine($"\t\t{ConstructorLine}");
            sb.AppendLine("\t\t{"); // begin constructor
            sb.AppendLine("\t\t}"); // end constructor
            sb.AppendLine("\t}"); // end class
            sb.AppendLine("}"); // end namespace

            return sb.ToString();
        }
    }
}
