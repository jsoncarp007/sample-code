﻿using System.Collections.Generic;
using BelleTire.RepositoryFramework.Extensions;
using BelleTire.RepositoryFramework.Interface;

namespace BelleTire.RepositoryFramework.DataProviders.DatabaseFirst
{
    public class InformixDatabaseFirstProvider : IDatabaseFirstProvider
    {
        private readonly InformixInformationProvider _informixInformationProvider;

        public InformixDatabaseFirstProvider(InformixInformationProvider informixInformationProvider)
        {
            _informixInformationProvider = informixInformationProvider;
        }

        public string GenerateClass(string tableName, string classNamespace)
        {
            var columnProperties = GetColumnPropertiesListForTable(tableName);
            var className = tableName.ConvertUnderscoreCaseToPascalCase();

            var classFactory = new DatabaseFirstClassFactory(tableName, className, classNamespace, columnProperties);

            return classFactory.GetClassText();
        }

        public List<DatabaseColumnProperties> GetColumnPropertiesListForTable(string tableName)
        {
            return _informixInformationProvider.GetColumnPropertiesListForTable(tableName);
        }

        public string GenerateRepositoryClass(string tableName, string classNamespace)
        {
            var className = tableName.ConvertUnderscoreCaseToPascalCase();

            var classFactory = new DatabaseFirstRepositoryClassFactory(className, classNamespace);

            return classFactory.GetClassText();
        }
    }
}
