﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using BelleTire.Framework.DatabaseIO.SqlServerDatabase;
using BelleTire.RepositoryFramework.DataProviders.Formatting;
using BelleTire.RepositoryFramework.Interface;
using BelleTire.RepositoryFramework.Query;

namespace BelleTire.RepositoryFramework.DataProviders
{
    public class MsSqlDataProvider : IRepositoryDataProvider
    {
        public IRepositoryDataProviderFormatting Formatting { get; }

        private readonly ISqlServerDatabase _db;

        private MsSqlDataProvider()
        {
            Formatting = new MsSqlDataFormatting();
        }

        public MsSqlDataProvider(ISqlServerDatabase db) : this()
        {
            _db = db;
        }

        public ISqlServerDatabase GetDatabaseObj()
        {
            return _db;
        }

        public DataTable GetDataTable(RepositorySelectQuery query, int timeout = int.MaxValue)
        {
            SetDataProvider(query);

            var sqlCommand = GetSqlCommand(query, timeout);

            return _db.ExecuteDataSet(sqlCommand).Tables[0];
        }

        public DataTable GetDataTable(string sqlQueryText, int timeout = Int32.MaxValue)
        {
            var sqlCommand = new SqlCommand(sqlQueryText)
            {
                CommandType = sqlQueryText.ToUpper().StartsWith("EXEC")
                    ? CommandType.StoredProcedure : CommandType.Text,
                CommandTimeout = timeout
            };
            return _db.ExecuteDataSet(sqlCommand).Tables[0];
        }

        private SqlCommand GetSqlCommand(RepositoryQuery query, int timeout)
        {
            var queryParams = GetSqlParams(query);
            string queryText = ReplaceParameterPlaceholders(query.Query, queryParams);

            var sqlCommand = new SqlCommand(queryText)
            {
                CommandType = query.QueryType == RepositoryQueryType.StoredProcedure
                    ? CommandType.StoredProcedure
                    : CommandType.Text,
                CommandTimeout = timeout
            };

            sqlCommand.Parameters.AddRange(queryParams);
            return sqlCommand;
        }

        private string ReplaceParameterPlaceholders(string queryText, SqlParameter[] parameters)
        {
            int paramCount = 0;
            while (queryText.Contains("?"))
            {
                int indexOfPlaceholder = queryText.IndexOf("?");

                queryText = queryText.Substring(0, indexOfPlaceholder) + 
                            $"{parameters[paramCount]}" +
                            queryText.Substring(indexOfPlaceholder + 1);

                paramCount++;
            }

            return queryText;
        }

        public int ExecuteQuery(RepositoryQuery query, int timeout = int.MaxValue)
        {
            SetDataProvider(query);

            var sqlCommand = GetSqlCommand(query, timeout);

            return _db.ExecuteNonQuery(sqlCommand);
        }

        public int ExecuteQuery(string querySql, int timeout = int.MaxValue)
        {
            var sqlCommand = new SqlCommand(querySql) {CommandType = CommandType.Text, CommandTimeout = timeout};

            return _db.ExecuteNonQuery(sqlCommand);
        }

        public void SetDataProvider(RepositoryQuery query)
        {
            query.SetDataProviderFormatting(this.Formatting);
        }

        public bool StoredProcedureExists(string storedProcedureName)
        {
            throw new System.NotImplementedException();
        }

        public void AddStoredProcedureToList(string storedProcedureName)
        {
            throw new System.NotImplementedException();
        }

        public bool HasElevatedPrivileges()
        {
            throw new System.NotImplementedException();
        }

        private SqlParameter[] GetSqlParams(RepositoryQuery query)
        {
            return query.GetQueryParameters()
                .Select(p => new SqlParameter($"@{p.SourceColumnIdentifier.Replace(".","_")}", p.Value))
                .ToArray();
        }
    }
}