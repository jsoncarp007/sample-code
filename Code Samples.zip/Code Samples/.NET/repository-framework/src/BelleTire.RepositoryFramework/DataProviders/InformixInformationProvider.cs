﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using BelleTire.RepositoryFramework.Extensions;
using IBM.Data.Informix;

namespace BelleTire.RepositoryFramework.DataProviders
{
    public class InformixInformationProvider
    {
        private readonly InformixDataProvider _informixDataProvider;

        public InformixInformationProvider(InformixDataProvider informixDataProvider)
        {
            _informixDataProvider = informixDataProvider;
        }

        public List<string> GetStoredProcedureNames(string startsWith = null)
        {
            string getStoredProceduresSql = "SELECT procname FROM sysprocedures ";
            if (startsWith != null)
                getStoredProceduresSql += $"WHERE procname LIKE '{startsWith}%'";

            return _informixDataProvider
                .GetDatabaseObj()
                .GetDataTable(getStoredProceduresSql)
                .Rows
                .OfType<DataRow>()
                .Select(r => r[0].ToString())
                .OrderBy(o => o)
                .ToList();
        }

        public List<string> GetTableNames()
        {
            string getTablesSql = "SELECT TRIM(tabname) as tabname FROM sysmaster:informix.systabnames ORDER BY tabname";

            return _informixDataProvider
                .GetDatabaseObj()
                .GetDataTable(getTablesSql)
                .Rows
                .OfType<DataRow>()
                .Select(r => r[0].ToString())
                .OrderBy(o => o)
                .ToList();
        }

        public List<DatabaseColumnProperties> GetColumnPropertiesListForTable(string tableName)
        {
            var getColumnPropertiesSql = "SELECT TRIM(c.colname) AS columnName, c.coltype, c.collength " +
                                         "FROM systables  AS t " +
                                         "JOIN syscolumns AS c ON t.tabid = c.tabid " +
                                         "WHERE t.tabname = ? ";

            getColumnPropertiesSql += "UNION SELECT TRIM(c.colname) AS columnName, c.coltype, c.collength " +
                                      "FROM fms:systables  AS t " +
                                      "JOIN fms:syscolumns AS c ON t.tabid = c.tabid " +
                                      "WHERE t.tabname = ? ";

            IfxParameter[] ifxParams =
            {
                new IfxParameter("tabname", tableName),
                new IfxParameter("tabname", tableName)
            };

            var table = _informixDataProvider.GetDatabaseObj().GetDataTable(getColumnPropertiesSql, ifxParams);

            var columnPropertiesList = new List<DatabaseColumnProperties>();

            foreach (DataRow dr in table.Rows)
            {
                var columnName = dr["columnName"].ToString();
                var propertyName = columnName.ConvertUnderscoreCaseToPascalCase();
                var colLength = Convert.ToInt32(dr["collength"]);
                var colTypeCode = Convert.ToInt32(dr["coltype"]);
                var dataType = GetDataTypeForColumnDataTypeCode(colTypeCode);
                var dataTypeName = _informixDataProvider.Formatting.GetDatabaseTypeStringForObjectType(dataType, colLength);

                var databaseColumnProperties = new DatabaseColumnProperties(tableName, columnName, propertyName, dataType, colLength, dataTypeName, colTypeCode == 262);

                columnPropertiesList.Add(databaseColumnProperties);
            }

            return columnPropertiesList;
        }

        private Type GetDataTypeForColumnDataTypeCode(int dataTypeCode)
        {
            switch (dataTypeCode)
            {
                case 1:
                case 2:
                case 258:
                case 262:
                    return typeof(int);

                case 3:
                    return typeof(double);

                case 5:
                case 261:
                    return typeof(decimal);

                case 0:
                case 256:
                    return typeof(string);

                case 7:
                case 263:
                case 266:
                    return typeof(DateTime);

                case 10:
                    return typeof(DateTime?);

                default:
                    return typeof(string);

            }
        }
    }
}
