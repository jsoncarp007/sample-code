﻿using System;

namespace BelleTire.RepositoryFramework.DataProviders
{
    public class DatabaseColumnProperties
    {
        public string TableName { get; }
        public string ColumnName { get; set; }
        public string PropertyName { get; }
        public bool IsKeyColumn { get; }
        public Type DataType { get; }
        public int DataTypeLength { get; }
        public string DataTypeName { get; }

        public DatabaseColumnProperties(string tableName, string columnName, string propertyName, Type dataType, int dataTypeLength, string dataTypeName, bool isKeyColumn = false)
        {
            TableName = tableName;
            ColumnName = columnName;
            PropertyName = propertyName;
            IsKeyColumn = isKeyColumn;
            DataType = dataType;
            DataTypeLength = dataTypeLength;
            DataTypeName = dataTypeName;
        }

        public DatabaseColumnProperties Copy()
        {
            return new DatabaseColumnProperties(TableName, ColumnName, PropertyName, DataType, DataTypeLength,
                DataTypeName, IsKeyColumn);
        }

    }
}
