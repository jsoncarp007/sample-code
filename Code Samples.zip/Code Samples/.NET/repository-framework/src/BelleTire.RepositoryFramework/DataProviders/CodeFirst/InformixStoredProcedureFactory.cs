﻿using System.Collections.Generic;
using System.Linq;
using BelleTire.RepositoryFramework.Query;
using BelleTire.RepositoryFramework.Query.Parameter;

namespace BelleTire.RepositoryFramework.DataProviders.CodeFirst
{
    public class InformixStoredProcedureFactory
    {
        private readonly InformixDataProvider _ifxProvider;
        private readonly InformixInformationProvider _ifxInformixInformationProvider;

        public InformixStoredProcedureFactory(InformixDataProvider informixProvider)
        {
            _ifxProvider = informixProvider;
            _ifxInformixInformationProvider = new InformixInformationProvider(informixProvider);
        }

        public int CreateStoredProcedure(RepositorySelectQuery selectQuery, string procedureName = null)
        {
            string storedProcedureText = GetStoredProcedureForQuery(selectQuery, procedureName);
            return _ifxProvider.ExecuteNonQuery(storedProcedureText);
        }

        public string GetStoredProcedureForQuery(RepositorySelectQuery selectQuery, string procedureName = null)
        {
            selectQuery.SetDataProviderFormatting(_ifxProvider.Formatting);

            var queryParamProperties = new List<DatabaseColumnProperties>();
            var queryParamPropertiesImplemented = new List<DatabaseColumnProperties>();

            var databaseColumnProperties = GetDatabaseColumnPropertiesForQuery(selectQuery.Query);
            var queryParams = selectQuery.GetQueryParameters().ToList();

            Dictionary<RepositoryQueryParameter, DatabaseColumnProperties> paramToPropertyMap = new Dictionary<RepositoryQueryParameter, DatabaseColumnProperties>();

            if (queryParams.Any())
            {
                var parameterFactory = new RepositoryQueryParameterFactory();

                // based on the order of the query params, re-number the positions
                // iterate through the query params based on position
                var paramsDictionary = parameterFactory.GetOrderedParametersDictionary(queryParams);

                // build one column property per param
                foreach (var queryParamMapping in paramsDictionary)
                {
                    var queryParam = queryParamMapping.Value;

                    if (paramToPropertyMap.ContainsKey(queryParam))
                    {
                        queryParamPropertiesImplemented.Add(paramToPropertyMap[queryParam]);
                        continue;
                    }

                    if (queryParam.TypeDefinition != null)
                    {
                        var colTypeName = _ifxProvider.Formatting.GetDatabaseTypeStringForObjectType(queryParam.TypeDefinition.DataType,
                            queryParam.TypeDefinition.Length);

                        var columnName = colTypeName.ToLower();
                        if (columnName.IndexOf("(") > -1)
                        {
                            columnName = columnName.Substring(0, columnName.IndexOf("("));
                        }

                        if (columnName.IndexOf(" ") > -1)
                        {
                            columnName = columnName.Substring(0, columnName.IndexOf(" "));
                        }

                        var columnProperties = new DatabaseColumnProperties(
                            string.Empty, $"param_{columnName}", string.Empty,
                            queryParam.TypeDefinition.DataType,
                            queryParam.TypeDefinition.Length,
                            _ifxProvider.Formatting.GetDatabaseTypeStringForObjectType(queryParam.TypeDefinition.DataType, queryParam.TypeDefinition.Length)
                        );

                        queryParamProperties.Add(columnProperties);
                        queryParamPropertiesImplemented.Add(columnProperties);
                        paramToPropertyMap.Add(queryParam, columnProperties);
                    }
                    else if (queryParam.SourceColumnIdentifier.Contains("."))
                    {
                        var currentTableName = queryParam.SourceColumnIdentifier.Split('.')[0];
                        var currentColumnName = queryParam.SourceColumnIdentifier.Split('.')[1];
                        var matchedColumnProperties =
                            databaseColumnProperties.FirstOrDefault(p => p.TableName == currentTableName && p.ColumnName == currentColumnName);

                        queryParamProperties.Add(matchedColumnProperties);
                        queryParamPropertiesImplemented.Add(matchedColumnProperties?.Copy());
                        paramToPropertyMap.Add(queryParam, matchedColumnProperties);
                    }

                }
            }

            if (procedureName == null)
                procedureName = selectQuery.QueryName;

            AdjustParamNamesForDuplicateImplementedProperties(queryParamPropertiesImplemented);

            var storedProcedureTemplate = new InformixStoredProcedureTemplate(procedureName, queryParamProperties, queryParamPropertiesImplemented, databaseColumnProperties, databaseColumnProperties, selectQuery.Query);

            return storedProcedureTemplate.GetCreateProcedureText();
        }

        private void AdjustParamNamesForDuplicateImplementedProperties(List<DatabaseColumnProperties> queryParamPropertiesImplemented)
        {
            var columnNamesList = new List<string>();

            foreach (var implementedProperty in queryParamPropertiesImplemented)
            {
                var origColumnName = implementedProperty.ColumnName;

                var countDuplicateColumnName = columnNamesList.Count(l => l == origColumnName);

                if (countDuplicateColumnName > 0)
                {
                    implementedProperty.ColumnName =
                        implementedProperty.ColumnName + $"_{countDuplicateColumnName + 1}";
                }

                columnNamesList.Add(origColumnName);
            }
        }

        private List<DatabaseColumnProperties> GetDatabaseColumnPropertiesForQuery(string query)
        {
            List<DatabaseColumnProperties> columnProperties = new List<DatabaseColumnProperties>();

            var columnList = GetQueryColumns(query);

            Dictionary<string, List<DatabaseColumnProperties>> tableColumnMap = new Dictionary<string, List<DatabaseColumnProperties>>();

            foreach (var tableName in columnList.Select(l => l.Key).Distinct())
            {
                var tableProperties = _ifxInformixInformationProvider.GetColumnPropertiesListForTable(tableName);
                tableColumnMap.Add(tableName, tableProperties);
            }

            foreach (var column in columnList)
            {
                var colProperty = tableColumnMap[column.Key].FirstOrDefault(c =>
                    c.ColumnName.Trim() == column.Value.Trim() || $"{c.ColumnName.Trim()} as {c.TableName.Trim()}_{c.ColumnName.Trim()}" == column.Value.Trim());
                if (colProperty != null)
                    columnProperties.Add(colProperty);
            }

            return columnProperties;
        }

        private List<KeyValuePair<string, string>> GetQueryColumns(string query)
        {
            string queryColumnListSubstring = query
                .Substring(0, query.IndexOf("FROM "))
                .Replace("SELECT ", string.Empty);

            if (queryColumnListSubstring.StartsWith("FIRST "))
            {
                queryColumnListSubstring = queryColumnListSubstring.Substring(5, queryColumnListSubstring.Length - 5);
            }

            while (queryColumnListSubstring[0] == ' ' || int.TryParse(queryColumnListSubstring[0].ToString(), out _))
            {
                queryColumnListSubstring = queryColumnListSubstring.Substring(1, queryColumnListSubstring.Length-1);
            }

            string[] tableDotColumnStrings = queryColumnListSubstring.Split(',').ToArray();

            return tableDotColumnStrings
                .Select(s => new KeyValuePair<string, string>(s.Split('.')[0].Trim(), s.Split('.')[1].Trim()))
                .ToList();

        }
    }
}
