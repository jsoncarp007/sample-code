﻿using System;
using System.Collections.Generic;
using System.Linq;
using BelleTire.RepositoryFramework.DataMapping;
using BelleTire.RepositoryFramework.DataMapping.Reflection;
using BelleTire.RepositoryFramework.Interface;

namespace BelleTire.RepositoryFramework.DataProviders.CodeFirst
{
    public class InformixCodeFirstTableFactory : ICodeFirstProvider
    {
        private readonly IRepositoryDataProvider _informixDataProvider;
        private readonly IRepositoryDataProviderFormatting _informixDataFormatting;

        public InformixCodeFirstTableFactory(InformixDataProvider informixDataProvider)
        {
            _informixDataProvider = informixDataProvider;
            _informixDataFormatting = informixDataProvider.Formatting;
        }

        public bool CreateTableForObject(RepositoryDecoratedObject decoratedObject)
        {
            var createTableSql = GetCreateTableSql(decoratedObject.GetReflectedMapping());
            return _informixDataProvider.ExecuteQuery(createTableSql) == 0;
        }

        public string GetCreateTableSql(RepositoryDecoratedObjectReflectedMapping reflectedMapping)
        {
            var primaryKeyProperty = 
                reflectedMapping.ReflectedProperties.FirstOrDefault(p => p.IsPrimaryKey);

            string primaryKeyDefinition = string.Empty;
            if (primaryKeyProperty != null)
            {
                var primaryKeyType = primaryKeyProperty.PropertyDataType == typeof(int)
                    ? "SERIAL"
                    : _informixDataFormatting.GetDatabaseTypeStringForObjectType(primaryKeyProperty.PropertyDataType, primaryKeyProperty.PropertyDataTypeLength);
                primaryKeyDefinition += $"{primaryKeyProperty.ColumnName} {primaryKeyType}";
            }

            List<string> columnDefinitions =
                reflectedMapping
                    .ReflectedProperties
                    .Where(p=>!p.IsPrimaryKey && !p.IsVirtual && p.PropertyName != "HasVirtualEnumerableChildren")
                    .Select(p => $"\t{p.ColumnName} as {_informixDataFormatting.GetDatabaseTypeStringForObjectType(p.PropertyDataType, p.PropertyDataTypeLength)}")
                    .ToList();

            if (!string.IsNullOrEmpty(primaryKeyDefinition))
                columnDefinitions.Insert(0, primaryKeyDefinition);

            string columnDefinitionsString = string.Join($",{Environment.NewLine}", columnDefinitions);

            string createTableSql = $"CREATE TABLE {reflectedMapping.TableName} " + Environment.NewLine + 
                                    $"({Environment.NewLine}\t{columnDefinitionsString}{Environment.NewLine})";

            return createTableSql;
        }

    }
}
