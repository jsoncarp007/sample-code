﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BelleTire.RepositoryFramework.DataProviders.CodeFirst
{
    public class InformixStoredProcedureTemplate
    {
        protected string CreateProcedureLine =>
            $"CREATE PROCEDURE {ProcedureName} ({QueryParametersListString})" + Environment.NewLine;
        protected string QueryParametersListString { get; set; }
        protected string ReturningLine => $"RETURNING {Environment.NewLine}{ReturningListString};" + Environment.NewLine;
        protected string Declarations { get; set; }
        protected string ProcedureBody { get; set; }
        protected string EndProcedureLine => "END PROCEDURE;" + Environment.NewLine;
        protected string ReturningListString { get; set; }

        protected string ProcedureName { get; set; }

        protected List<string> QueryParamNames { get; set; }

        public InformixStoredProcedureTemplate(string procedureName, List<DatabaseColumnProperties> inputProperties, List<DatabaseColumnProperties> propertyImplementation, List<DatabaseColumnProperties> returningProperties, List<DatabaseColumnProperties> declarationsProperties, string body)
        {
            ProcedureName = procedureName;

            var declarationPropertiesCopy =
                declarationsProperties
                    .Select(d => d.Copy())
                    .ToList();

            SetDeclarationsText(declarationPropertiesCopy);
            SetReturningText(returningProperties);
            SetQueryParameterText(inputProperties);

            SetBodyText(body, propertyImplementation, declarationPropertiesCopy);
        }


        private void SetQueryParameterText(List<DatabaseColumnProperties> inputProperties)
        {
            QueryParamNames = new List<string>();
            List<KeyValuePair<string, string>> queryParamsStrings = new List<KeyValuePair<string, string>>();

            // de-dupe the param names
            foreach (var inputProperty in inputProperties)
            {
                int countOfKey = queryParamsStrings.Count(k => k.Key == inputProperty.ColumnName);

                if (countOfKey > 0)
                    inputProperty.ColumnName += $"_{countOfKey+1}";

                QueryParamNames.Add($"in_{inputProperty.ColumnName}");

                var dataTypeName = inputProperty.DataTypeName;
                if (!dataTypeName.Contains("LIST("))
                    dataTypeName = dataTypeName.Replace(" NOT NULL", string.Empty);

                var kvp = new KeyValuePair<string,string>(inputProperty.ColumnName, $"in_{inputProperty.ColumnName} {dataTypeName}");
                queryParamsStrings.Add(kvp);
            }

            QueryParametersListString =
                string.Join(", ", queryParamsStrings.Select(p=>p.Value));
        }

        private void SetReturningText(IEnumerable<DatabaseColumnProperties> returningProperties)
        {
            ReturningListString = string.Join($", {Environment.NewLine}",
                returningProperties.Select(d => $"\t{d.DataTypeName.Replace("NOT NULL", string.Empty)} as {d.TableName}_{d.ColumnName}"));
        }

        private void SetDeclarationsText(IEnumerable<DatabaseColumnProperties> declarationProperties)
        {
            Declarations = string.Join(Environment.NewLine,
                declarationProperties.Select(d => $"DEFINE v_{d.TableName}_{d.ColumnName} {d.DataTypeName.Replace("NOT NULL", string.Empty)};"));
        }

        private void SetBodyText(string body, IEnumerable<DatabaseColumnProperties> implementedProperties, IEnumerable<DatabaseColumnProperties> declarationProperties)
        {
            // find where FROM starts
            int fromStartsIndex = body.IndexOf("FROM ");

            string varsList = string.Join(", ", declarationProperties.Select(d => $"v_{d.TableName}_{d.ColumnName}"));

            // create the INTO text
            string intoSection = Environment.NewLine + Environment.NewLine + "\tINTO " + varsList + Environment.NewLine + Environment.NewLine + "\t";

            // create the RETURN text
            string returnSection = $"{Environment.NewLine}\tRETURN {varsList} WITH RESUME; {Environment.NewLine}{Environment.NewLine}";

            // insert the INTO text in between SELECT and FROM
            body = body.Insert(fromStartsIndex, intoSection);

            body += $"{returnSection} ";
            body += "END FOREACH;" + Environment.NewLine;
            body = $"{Environment.NewLine}FOREACH{Environment.NewLine}\t " + body + Environment.NewLine;

            // swap out the question marks for the variable names
            var propertiesArray = implementedProperties.ToArray();
            int paramCount = 0;
            while (body.IndexOf("?") > -1)
            {
                int indexOfQuestionMark = body.IndexOf("?");
                body = body.Remove(indexOfQuestionMark, 1);
                body = body.Insert(indexOfQuestionMark, $"in_{propertiesArray[paramCount].ColumnName}");
                paramCount++;
                if (paramCount >= propertiesArray.Length) paramCount = 0;
            }

            ProcedureBody = body;
        }

        public string GetCreateProcedureText()
        {
            return CreateProcedureLine + Environment.NewLine +
                   ReturningLine + Environment.NewLine +
                   Declarations + Environment.NewLine +
                   ProcedureBody + Environment.NewLine +
                   EndProcedureLine + Environment.NewLine;
        }
    }
}
