﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using BelleTire.RepositoryFramework.DataMapping;
using BelleTire.RepositoryFramework.Interface;
using BelleTire.RepositoryFramework.Query;
using BelleTire.RepositoryFramework.Query.ConditionalQuery;
using BelleTire.RepositoryFramework.Query.ConditionalQuery.MatchCondition;
using BelleTire.RepositoryFramework.Query.Parameter;

namespace BelleTire.RepositoryFramework.Repository
{
    public abstract partial class Repository
    {
        #region Count

        public int Count<T>(Expression<Predicate<T>> selector) where T : IDatabaseMappedObject, new()
        {
            var selectQuery = new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, GetMatchConditionForSelector(selector), true);

            return DataProvider.ExecuteQuery(selectQuery);
        }

        public int Count(RepositoryQueryMatchCondition condition)
        {
            var selectQuery = new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, condition, true);

            return DataProvider.ExecuteQuery(selectQuery);
        }

        public int Count(RepositoryQueryMatchCondition[] conditions)
        {
            var selectQuery = new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, conditions, true);

            return DataProvider.ExecuteQuery(selectQuery);
        }

        #endregion

        #region Get<T>

        public List<T> Get<T>(Expression<Predicate<T>> selector) where T : IDatabaseMappedObject, new()
        {
            return Get<T>(GetMatchConditionForSelector(selector));
        }

        public List<T> Get<T>(Expression<Predicate<T>> selector, RepositoryQueryMatchCondition[] additionalMatchConditions) where T : IDatabaseMappedObject, new()
        {
            return Get<T>(new List<RepositoryQueryMatchCondition>(additionalMatchConditions) {
                GetMatchConditionForSelector(selector)
            });
        }

        public List<T> Get<T>(Expression<Predicate<T>> selector, RepositoryQueryMatchCondition[] additionalMatchConditions, RepositoryOrderBy orderBy) where T : IDatabaseMappedObject, new()
        {
            return Get<T>(new List<RepositoryQueryMatchCondition>(additionalMatchConditions) {
                GetMatchConditionForSelector(selector)
            }, orderBy);
        }

        public List<T> Get<T>(Expression<Predicate<T>> selector, RepositoryQueryMatchCondition[] additionalMatchConditions, RepositoryOrderBy orderBy, int selectFirst) where T : IDatabaseMappedObject, new()
        {
            return Get<T>(new List<RepositoryQueryMatchCondition>(additionalMatchConditions) {
                GetMatchConditionForSelector(selector)
            }, orderBy, selectFirst);
        }

        public List<T> Get<T>(Expression<Predicate<T>> selector, RepositoryOrderBy orderBy)
            where T : IDatabaseMappedObject, new()
        {
            return Get<T>(GetMatchConditionForSelector(selector), orderBy);
        }

        public List<T> Get<T>(Expression<Predicate<T>> selector, RepositoryOrderBy orderBy, int selectFirst)
            where T : IDatabaseMappedObject, new()
        {
            return Get<T>(GetMatchConditionForSelector(selector), orderBy, selectFirst);
        }

        public T Get<T>(int keyFieldValue) where T : IDatabaseMappedObject, new()
        {
            T newObject = new T();
            var keyFieldName = newObject.GetMappedObjectKeyFieldColumnName();
            var tableName = newObject.GetMappedObjectTableName();
            var condition = new RepositoryQueryKeyFieldMatchConditionDefinition(tableName, keyFieldName)
                .GetConditionForDefinition(keyFieldValue);
            return Get<T>(condition).FirstOrDefault();
        }

        protected RepositoryQueryMatchCondition GetMatchConditionForSelector<T>(Expression<Predicate<T>> selector)
            where T : IDatabaseMappedObject
        {
            if (selector.Parameters.Count > 1)
                throw new Exception("Only one parameter supported in Repository LINQ queries");

            return RepositoryQueryMatchCondition.GetMatchCondition(selector);
        }

        public List<T> Get<T>(RepositoryQueryMatchCondition matchCondition) where T : IDatabaseMappedObject, new()
        {
            var dt = Select(matchCondition);
            return GetFromDataTable<T>(dt);
        }

        public List<T> Get<T>(List<RepositoryQueryMatchCondition> matchConditions)
            where T : IDatabaseMappedObject, new()
        {
            var dt = Select(matchConditions);
            return GetFromDataTable<T>(dt);
        }

        public List<T> Get<T>(RepositoryQueryMatchCondition matchCondition, int selectFirst)
            where T : IDatabaseMappedObject, new()
        {
            var dt = SelectFirst(matchCondition, selectFirst);
            return GetFromDataTable<T>(dt);
        }

        public List<T> Get<T>(List<RepositoryQueryMatchCondition> matchConditions, int selectFirst)
            where T : IDatabaseMappedObject, new()
        {
            var dt = SelectFirst(matchConditions, selectFirst);
            return GetFromDataTable<T>(dt);
        }

        public List<T> Get<T>(RepositoryQueryMatchCondition matchCondition, RepositoryOrderBy orderBy)
            where T : IDatabaseMappedObject, new()
        {
            var dt = Select(matchCondition, orderBy);
            return GetFromDataTable<T>(dt);
        }

        public List<T> Get<T>(RepositoryOrderBy orderBy, int selectFirst)
            where T : IDatabaseMappedObject, new()
        {
            var dt = SelectFirst(orderBy, selectFirst);
            return GetFromDataTable<T>(dt);
        }

        public List<T> Get<T>(RepositoryQueryMatchCondition matchCondition, RepositoryOrderBy orderBy, int selectFirst)
            where T : IDatabaseMappedObject, new()
        {
            var dt = SelectFirst(matchCondition, orderBy, selectFirst);
            return GetFromDataTable<T>(dt);
        }

        public List<T> Get<T>(List<RepositoryQueryMatchCondition> matchConditions, RepositoryOrderBy orderBy)
            where T : IDatabaseMappedObject, new()
        {
            var dt = Select(matchConditions, orderBy);
            return GetFromDataTable<T>(dt);
        }

        public List<T> Get<T>(List<RepositoryQueryMatchCondition> matchConditions, RepositoryOrderBy orderBy,
            int selectFirst) where T : IDatabaseMappedObject, new()
        {
            var dt = SelectFirst(matchConditions, orderBy, selectFirst);
            return GetFromDataTable<T>(dt);
        }

        private List<T> GetFromDataTable<T>(DataTable dt) where T : IDatabaseMappedObject, new()
        {
            var newObj = new T();

            if (newObj.HasVirtualEnumerableChildren())
            {
                newObj.LoadFromDataTable(dt);

                return new List<T>() { newObj };
            }

            return dt.Rows.OfType<DataRow>().Select(GetNewObjectFromDataRow<T>).ToList();
        }

        private T GetNewObjectFromDataRow<T>(DataRow dr) where T : IDatabaseMappedObject, new()
        {
            T newObject = new T();
            newObject.LoadFromDataRow(dr);
            return newObject;
        }

        #endregion

        #region Get

        public List<RepositoryDecoratedObject> Get(Type decoratedObjectType,
            RepositoryQueryMatchCondition matchCondition)
        {
            var autoMappedRepo = Factory.GetRepositoryForType(decoratedObjectType);

            List<RepositoryDecoratedObject> objectList = new List<RepositoryDecoratedObject>();

            var results = autoMappedRepo.Select(matchCondition);

            foreach (DataRow dr in results.Rows)
            {
                dynamic newObject = Activator.CreateInstance(decoratedObjectType);
                newObject.LoadFromDataRow(dr);
                objectList.Add(newObject);
            }

            return objectList;
        }

        public List<RepositoryDecoratedObject> Get(Type decoratedObjectType)
        {
            var autoMappedRepo = Factory.GetRepositoryForType(decoratedObjectType);

            List<RepositoryDecoratedObject> objectList = new List<RepositoryDecoratedObject>();

            var results = autoMappedRepo.Select();

            foreach (DataRow dr in results.Rows)
            {
                dynamic newObject = Activator.CreateInstance(decoratedObjectType);
                newObject.LoadFromDataRow(dr);
                objectList.Add(newObject);
            }

            return objectList;
        }

        #endregion

        #region GetQuery

        public RepositorySelectQuery GetQuery<T>(Expression<Predicate<T>> selector)
            where T : IDatabaseMappedObject, new()
        {
            var matchCondition = GetMatchConditionForSelector(selector);
            return new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, matchCondition);
        }

        #endregion

        #region Select

        public DataTable Select(int timeout = int.MaxValue)
        {
            return Select(new RepositorySelectQuery(QueryConfiguration.SelectSqlBase), timeout);
        }

        public DataTable Select(IEnumerable<RepositoryQueryMatchCondition> matchConditions, int timeout = int.MaxValue)
        {
            return Select(new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, matchConditions), timeout);
        }

        public DataTable Select(IEnumerable<RepositoryQueryMatchCondition> matchConditions, RepositoryOrderBy orderBy,
            int timeout = int.MaxValue)
        {
            var selectQuery = new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, matchConditions);
            selectQuery.SetOrderBy(orderBy);
            return Select(selectQuery, timeout);
        }

        public DataTable Select(IEnumerable<RepositoryQueryMatchCondition> matchConditions, RepositoryGroupBy groupBy,
            int timeout = int.MaxValue)
        {
            var selectQuery = new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, matchConditions);
            selectQuery.SetGroupBy(groupBy);
            return Select(selectQuery, timeout);
        }

        public DataTable Select(IEnumerable<RepositoryQueryMatchCondition> matchConditions, RepositoryOrderBy orderBy,
            RepositoryGroupBy groupBy, int timeout = int.MaxValue)
        {
            var selectQuery = new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, matchConditions);
            selectQuery.SetOrderBy(orderBy);
            selectQuery.SetGroupBy(groupBy);
            return Select(selectQuery, timeout);
        }

        public DataTable Select(RepositoryQueryMatchCondition matchCondition, int timeout = int.MaxValue)
        {
            return Select(new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, matchCondition), timeout);
        }

        public DataTable Select(RepositoryQueryMatchCondition matchCondition, RepositoryOrderBy orderBy,
            int timeout = int.MaxValue)
        {
            var selectQuery = new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, matchCondition);
            selectQuery.SetOrderBy(orderBy);
            return Select(selectQuery, timeout);
        }

        public DataTable Select(RepositoryQueryMatchCondition matchCondition, RepositoryGroupBy groupBy,
            int timeout = int.MaxValue)
        {
            var selectQuery = new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, matchCondition);
            selectQuery.SetGroupBy(groupBy);
            return Select(selectQuery, timeout);
        }

        public DataTable Select(RepositoryQueryMatchCondition matchCondition, RepositoryOrderBy orderBy,
            RepositoryGroupBy groupBy, int timeout = int.MaxValue)
        {
            var selectQuery = new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, matchCondition);
            selectQuery.SetOrderBy(orderBy);
            selectQuery.SetGroupBy(groupBy);
            return Select(selectQuery, timeout);
        }

        public DataTable Select(RepositoryQueryMatchCondition matchCondition, RepositoryQueryParameter queryParameter,
            int timeout = int.MaxValue)
        {
            return Select(new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, matchCondition, queryParameter), timeout);
        }

        public DataTable Select(List<RepositoryQueryParameter> queryParameters, int timeout = int.MaxValue)
        {
            return Select(new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, queryParameters), timeout);
        }

        public DataTable Select(RepositorySelectQuery selectQuery, int timeout = int.MaxValue)
        {
            return DataProvider.GetDataTable(selectQuery, timeout);
        }

        // Select first

        public DataTable SelectFirst(RepositoryOrderBy orderBy, int selectFirst, int timeout = int.MaxValue)
        {
            var query = new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, orderBy, selectFirst);
            query.SetOrderBy(orderBy);

            return Select(query, timeout);
        }

        public DataTable SelectFirst(int selectFirst, int timeout = int.MaxValue)
        {
            return Select(new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, selectFirst),
                timeout);
        }

        public DataTable SelectFirst(List<RepositoryQueryMatchCondition> matchConditions, int selectFirst,
            int timeout = int.MaxValue)
        {
            return Select(new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, matchConditions, selectFirst), timeout);
        }

        public DataTable SelectFirst(RepositoryQueryMatchCondition matchCondition, int selectFirst,
            int timeout = int.MaxValue)
        {
            return Select(new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, matchCondition, selectFirst), timeout);
        }

        public DataTable SelectFirst(RepositoryQueryMatchCondition matchCondition, RepositoryOrderBy orderBy,
            int selectFirst, int timeout = int.MaxValue)
        {
            var query = new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, matchCondition, selectFirst);
            query.SetOrderBy(orderBy);
            return Select(query, timeout);
        }

        public DataTable SelectFirst(List<RepositoryQueryMatchCondition> matchConditions, RepositoryOrderBy orderBy,
            int selectFirst, int timeout = int.MaxValue)
        {
            var query = new RepositorySelectQuery(QueryConfiguration.SelectSqlBase, matchConditions, selectFirst);
            query.SetOrderBy(orderBy);
            return Select(query, timeout);
        }

        #endregion
    }
}
