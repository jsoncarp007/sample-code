﻿using BelleTire.RepositoryFramework.Core;
using BelleTire.RepositoryFramework.Interface;

namespace BelleTire.RepositoryFramework.Repository
{
    public abstract partial class Repository
    {
        protected abstract IRepositoryQueryConfiguration QueryConfiguration { get; }
        protected IRepositoryDataProvider DataProvider { get; }
        protected abstract IRepositoryQueryEntityDefinition EntityDefinition { get; }

        public RepositoryFactory Factory { get; }

        protected Repository(IRepositoryDataProvider dataProvider)
        {
            DataProvider = dataProvider;
            Factory = new RepositoryFactory(DataProvider);
        }

    }
}
