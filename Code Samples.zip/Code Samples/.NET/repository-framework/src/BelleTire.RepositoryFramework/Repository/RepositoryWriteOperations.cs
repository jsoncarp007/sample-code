﻿using System.Collections.Generic;
using System.Linq;
using BelleTire.RepositoryFramework.Interface;
using BelleTire.RepositoryFramework.Query;
using BelleTire.RepositoryFramework.Query.ConditionalQuery.MatchCondition;
using BelleTire.RepositoryFramework.Query.Parameter;

namespace BelleTire.RepositoryFramework.Repository
{
    public abstract partial class Repository
    {
        #region Insert

        public RepositoryInsertQuery GetInsertQuery(IDatabaseMappedObject mappedObject)
        {
            var insertQuery = new RepositoryInsertQuery(QueryConfiguration.InsertSqlBase, mappedObject);
            return insertQuery;
        }

        public List<RepositoryInsertQuery> GetInsertQueries(IEnumerable<IDatabaseMappedObject> mappedObjects)
        {
            var insertQueries = mappedObjects
                .Select(m => new RepositoryInsertQuery(QueryConfiguration.InsertSqlBase, m)).ToList();
            return insertQueries;
        }

        public RepositoryInsertQuery GetInsertQuery(RepositoryQueryParameter queryParameter)
        {
            return new RepositoryInsertQuery(QueryConfiguration.InsertSqlBase, queryParameter);
        }

        public RepositoryInsertQuery GetInsertQuery(IEnumerable<RepositoryQueryParameter> queryParameters)
        {
            return new RepositoryInsertQuery(QueryConfiguration.InsertSqlBase, queryParameters);
        }

        public int Insert(IDatabaseMappedObject objectToUpdate, int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryInsertQuery(QueryConfiguration.InsertSqlBase, objectToUpdate),
                timeout);
        }

        public int Insert(List<RepositoryQueryParameter> queryParameters, int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryInsertQuery(QueryConfiguration.InsertSqlBase, queryParameters), timeout);
        }

        public int Insert(RepositoryQueryParameter queryParameter, int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryInsertQuery(QueryConfiguration.InsertSqlBase, queryParameter), timeout);
        }

        public int InsertFromSelect(RepositorySelectQuery selectQuery, int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(new RepositoryInsertQuery(EntityDefinition, selectQuery), timeout);
        }

        public int InsertFromSelect(string selectQueryBase, int timeout = int.MaxValue)
        {
            var selectQuery = new RepositorySelectQuery(selectQueryBase);
            return InsertFromSelect(selectQuery, timeout);
        }

        public int InsertFromSelect(string selectQueryBase, RepositoryQueryMatchCondition condition,
            int timeout = int.MaxValue)
        {
            var selectQuery = new RepositorySelectQuery(selectQueryBase, condition);
            return InsertFromSelect(selectQuery, timeout);
        }

        public int InsertFromSelect(string selectQueryBase, RepositoryQueryMatchCondition condition,
            IEnumerable<string> limitToColumns, int timeout = int.MaxValue)
        {
            var selectQuery = new RepositorySelectQuery(selectQueryBase, condition, limitToColumns);
            return InsertFromSelect(selectQuery, timeout);
        }

        public int InsertFromSelect(string selectQueryBase, IEnumerable<RepositoryQueryMatchCondition> conditions,
            int timeout = int.MaxValue)
        {
            var selectQuery = new RepositorySelectQuery(selectQueryBase, conditions);
            selectQuery.SetDataProviderFormatting(DataProvider.Formatting);
            return InsertFromSelect(selectQuery, timeout);
        }

        public int InsertFromSelect(string selectQueryBase, IEnumerable<RepositoryQueryMatchCondition> conditions,
            IEnumerable<string> limitToColumns, int timeout = int.MaxValue)
        {
            var selectQuery = new RepositorySelectQuery(selectQueryBase, conditions, limitToColumns);
            selectQuery.SetDataProviderFormatting(DataProvider.Formatting);
            return InsertFromSelect(selectQuery, timeout);
        }


        #endregion

        #region Update

        public int Update(IDatabaseMappedObject objectToUpdate, int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryUpdateQuery(QueryConfiguration.UpdateSqlBase, objectToUpdate),
                timeout);
        }

        public int Update(RepositoryQueryMatchCondition matchCondition, int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryUpdateQuery(QueryConfiguration.UpdateSqlBase, matchCondition),
                timeout);
        }

        public int Update(List<RepositoryQueryMatchCondition> matchConditions, int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryUpdateQuery(QueryConfiguration.UpdateSqlBase, matchConditions),
                timeout);
        }

        public int Update(RepositoryQueryMatchCondition matchCondition, RepositoryQueryParameter updateParameter,
            int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryUpdateQuery(QueryConfiguration.UpdateSqlBase, matchCondition, updateParameter),
                timeout);
        }

        public int Update(RepositoryQueryMatchCondition matchCondition, List<RepositoryQueryParameter> updateParameters,
            int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryUpdateQuery(QueryConfiguration.UpdateSqlBase, matchCondition, updateParameters),
                timeout);
        }

        public int Update(List<RepositoryQueryMatchCondition> matchConditions, RepositoryQueryParameter updateParameter,
            int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryUpdateQuery(QueryConfiguration.UpdateSqlBase, matchConditions, updateParameter),
                timeout);
        }

        public int Update(List<RepositoryQueryParameter> queryParameters, int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryUpdateQuery(QueryConfiguration.UpdateSqlBase, queryParameters),
                timeout);
        }

        public int Update(List<RepositoryQueryMatchCondition> matchConditions,
            List<RepositoryQueryParameter> updateParameters, int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryUpdateQuery(QueryConfiguration.UpdateSqlBase, matchConditions, updateParameters),
                timeout);
        }

        #endregion

        #region Delete

        public int Delete(IDatabaseMappedObject mappedObjectToDelete, int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryDeleteQuery(QueryConfiguration.DeleteSqlBase, mappedObjectToDelete), timeout);
        }

        public int Delete(List<RepositoryQueryMatchCondition> matchConditions, int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryDeleteQuery(QueryConfiguration.DeleteSqlBase, matchConditions), timeout);
        }

        public int Delete(RepositoryQueryMatchCondition matchCondition, int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryDeleteQuery(QueryConfiguration.DeleteSqlBase, matchCondition), timeout);
        }

        public int Delete(RepositoryQueryMatchCondition matchCondition, RepositoryQueryParameter queryParameter,
            int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryDeleteQuery(QueryConfiguration.DeleteSqlBase, matchCondition, queryParameter), timeout);
        }

        public int Delete(RepositoryQueryMatchCondition matchCondition, List<RepositoryQueryParameter> queryParameters,
            int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryDeleteQuery(QueryConfiguration.DeleteSqlBase, matchCondition, queryParameters), timeout);
        }

        public int Delete(List<RepositoryQueryMatchCondition> matchConditions,
            List<RepositoryQueryParameter> queryParameters, int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryDeleteQuery(QueryConfiguration.DeleteSqlBase, matchConditions, queryParameters), timeout);
        }

        public int Delete(List<RepositoryQueryParameter> queryParameters, int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(
                new RepositoryDeleteQuery(QueryConfiguration.DeleteSqlBase, queryParameters), timeout);
        }

        #endregion

        #region Non Query / Procedure

        public int ExecuteProcedure(string procedureSql, int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(new RepositoryQueryProcedure(procedureSql), timeout);
        }

        public int ExecuteProcedure(string procedureSql, RepositoryQueryParameter queryParameter,
            int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(new RepositoryQueryProcedure(procedureSql, queryParameter), timeout);
        }

        public int ExecuteProcedure(string procedureSql, List<RepositoryQueryParameter> queryParameters,
            int timeout = int.MaxValue)
        {
            return DataProvider.ExecuteQuery(new RepositoryQueryProcedure(procedureSql, queryParameters), timeout);
        }


        #endregion

        #region Batch

        public int ExecuteBatchInsert(IDatabaseMappedObject[] dbMappedObjects, int batchSize = 100,
            int timeout = int.MaxValue)
        {
            var queries = GetInsertQueries(dbMappedObjects);
            return ExecuteBatch(queries.ToArray(), batchSize, timeout);
        }

        public int ExecuteBatchUpdate(IDatabaseMappedObject[] dbMappedObjects, int batchSize = 100,
            int timeout = int.MaxValue)
        {
            var queries = dbMappedObjects.Select(o => new RepositoryUpdateQuery(QueryConfiguration.InsertSqlBase, o));
            return ExecuteBatch(queries.ToArray(), batchSize, timeout);
        }

        public int ExecuteBatch(IEnumerable<RepositoryQuery> queries, int batchSize = 100, int timeout = int.MaxValue)
        {
            int statementsExecuted = 0;

            var statementList = GetBatchQueryStatements(queries, batchSize);

            foreach (var statement in statementList)
            {
                statementsExecuted += DataProvider.ExecuteQuery(statement, timeout);
            }

            return statementsExecuted;
        }

        private List<string> GetBatchQueryStatements(IEnumerable<RepositoryQuery> queries, int batchSize = 100)
        {
            var queriesList = queries.ToList();

            queriesList.ForEach(q => q.SetDataProviderFormatting(DataProvider.Formatting));

            List<string> queryStatementList = new List<string>();
            while (queriesList.Count > 0)
            {
                var queriesForCurrentString =
                    queriesList.GetRange(0, batchSize > queriesList.Count ? queriesList.Count : batchSize);

                string currentBatchInsertString =
                    string.Join(";", queriesForCurrentString.Select(q => q.GetUnparameterizedQuery()));

                queryStatementList.Add(currentBatchInsertString);

                queriesList.RemoveAll(q => queriesForCurrentString.Contains(q));

            }

            return queryStatementList;

        }

        #endregion
    }
}
