﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using BelleTire.RepositoryFramework.Core;
using BelleTire.RepositoryFramework.DataMapping;
using BelleTire.RepositoryFramework.Entity;
using BelleTire.RepositoryFramework.Interface;
using BelleTire.RepositoryFramework.Query.ConditionalQuery;

namespace BelleTire.RepositoryFramework.Repository
{
    public class AutoMappedRepository : Repository
    {
        protected override IRepositoryQueryConfiguration QueryConfiguration { get; }
        protected override IRepositoryQueryEntityDefinition EntityDefinition { get; }

        internal AutoMappedRepository(IRepositoryDataProvider dataProvider, RepositoryQueryAutoConfiguration queryAutoConfig) : base(dataProvider)
        {
            QueryConfiguration = queryAutoConfig;
            EntityDefinition = new RepositoryQueryEntity(queryAutoConfig.PrimaryEntity);
        }
    }

    public class AutoMappedRepository<T> : Repository where T : RepositoryDecoratedObject, new()
    {
        protected override IRepositoryQueryConfiguration QueryConfiguration { get; }
        protected override IRepositoryQueryEntityDefinition EntityDefinition { get; }

        internal AutoMappedRepository(IRepositoryDataProvider dataProvider) : base(dataProvider)
        {
            var queryAutoConfig = new RepositoryQueryAutoConfiguration(new T());
            QueryConfiguration = queryAutoConfig;
            EntityDefinition = new RepositoryQueryEntity(queryAutoConfig.PrimaryEntity);
        }

        public List<T> Get(Expression<Predicate<T>> selector)
        {
            return Get<T>(GetMatchConditionForSelector(selector));
        }

        public List<T> Get(Expression<Predicate<T>> selector, RepositoryOrderBy orderBy)
        {
            return Get<T>(GetMatchConditionForSelector(selector), orderBy);
        }

        public List<T> Get(Expression<Predicate<T>> selector, RepositoryOrderBy orderBy, int selectFirst)
        {
            return Get<T>(GetMatchConditionForSelector(selector), orderBy, selectFirst);
        }
    }
}
