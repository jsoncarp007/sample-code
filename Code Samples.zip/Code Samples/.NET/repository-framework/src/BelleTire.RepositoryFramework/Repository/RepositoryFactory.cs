﻿using System;
using BelleTire.RepositoryFramework.DataMapping;
using BelleTire.RepositoryFramework.Interface;

namespace BelleTire.RepositoryFramework.Repository
{
    public class RepositoryFactory
    {
        protected IRepositoryDataProvider DataProvider { get; }

        public RepositoryFactory(IRepositoryDataProvider dataProvider)
        {
            DataProvider = dataProvider;
        }

        public AutoMappedRepository GetRepositoryForType(Type decoratedObjectType)
        {
            if (!decoratedObjectType.IsSubclassOf(typeof(RepositoryDecoratedObject)))
            {
                string requiredObjectName = typeof(RepositoryDecoratedObject).Name;
                throw new InvalidCastException($"Object must be a {requiredObjectName}");
            }

            dynamic instanceOfDatabaseMappedObject = Activator.CreateInstance(decoratedObjectType);

            var autoMappedRepo = new AutoMappedRepository(DataProvider,
                new RepositoryQueryAutoConfiguration(instanceOfDatabaseMappedObject));
            return autoMappedRepo;
        }

        public AutoMappedRepository GetRepository(IRepositoryDataProvider dataProvider,
            RepositoryQueryAutoConfiguration queryAutoConfig)
        {
            return new AutoMappedRepository(dataProvider, queryAutoConfig);
        }

        public AutoMappedRepository<T> GetRepository<T>() where T : RepositoryDecoratedObject, new()
        {
            var decoratedObjectType = typeof(T);

            if (!decoratedObjectType.IsSubclassOf(typeof(RepositoryDecoratedObject)))
            {
                string requiredObjectName = typeof(RepositoryDecoratedObject).Name;
                throw new InvalidCastException($"Object must be a {requiredObjectName}");
            }

            var autoMappedRepo = new AutoMappedRepository<T>(DataProvider);
            return autoMappedRepo;
        }
    }
}
