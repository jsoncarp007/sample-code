﻿using Newtonsoft.Json.Converters;

namespace BelleTire.RepositoryFramework.Core.Tools.Serialization.Serialization
{
    public class DateFormatConverter : IsoDateTimeConverter
    {
        public DateFormatConverter(string format)
        {
            DateTimeFormat = format;
        }
    }
}