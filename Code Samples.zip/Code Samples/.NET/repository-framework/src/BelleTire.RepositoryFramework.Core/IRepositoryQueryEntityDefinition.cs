﻿namespace BelleTire.RepositoryFramework.Core
{
    public interface IRepositoryQueryEntityDefinition
    {
        string EntityName { get; }
        string KeyColumnName { get; }
        string[] ColumnNames { get; }
    }
}
