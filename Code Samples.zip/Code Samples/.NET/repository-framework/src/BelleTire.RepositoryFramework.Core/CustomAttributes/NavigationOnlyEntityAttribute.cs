﻿using System;

namespace BelleTire.RepositoryFramework.Core.CustomAttributes
{
    public class NavigationOnlyEntityAttribute : Attribute
    {
    }
}
