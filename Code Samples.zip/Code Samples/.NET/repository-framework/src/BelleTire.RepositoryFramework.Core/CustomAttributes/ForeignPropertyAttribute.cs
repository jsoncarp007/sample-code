﻿using System;

namespace BelleTire.RepositoryFramework.Core.CustomAttributes
{
    public class ForeignPropertyAttribute : Attribute
    {
        public Type ForeignObjectType { get; }
        public string ForeignFieldPropertyName { get; set; }

        public ForeignPropertyAttribute(Type foreignObjectType, string foreignFieldPropertyName)
        {
            ForeignObjectType = foreignObjectType;
            ForeignFieldPropertyName = foreignFieldPropertyName;
        }
    }
}