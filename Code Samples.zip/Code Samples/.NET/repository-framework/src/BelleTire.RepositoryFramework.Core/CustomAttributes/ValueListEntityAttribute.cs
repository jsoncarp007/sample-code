﻿using System;

namespace BelleTire.RepositoryFramework.Core.CustomAttributes
{
    public class ValueListEntityAttribute : Attribute
    {
        public Type EntityType { get; }
        public Type RepositoryMatchConditionType { get; }

        public ValueListEntityAttribute(Type entityType)
        {
            EntityType = entityType;
        }

        public ValueListEntityAttribute(Type entityType, Type repositoryMatchConditionType) : this(entityType)
        {
            RepositoryMatchConditionType = repositoryMatchConditionType;
        }
    }
}
