﻿namespace BelleTire.RepositoryFramework.Core
{
    public interface IRepositoryQueryEntityRelationshipDefinition
    {
        IRepositoryQueryEntityDefinition PrimaryEntityDefinition { get; }
        string PrimaryEntityJoinFieldName { get; }

        IRepositoryQueryEntityDefinition JoinToEntityDefinition { get; }
        string JoinToEntityJoinField { get; }

        bool OuterJoin { get; }

    }
}
