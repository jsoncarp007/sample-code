﻿using BelleTire.RepositoryFramework.Extensions;
using BelleTire.RepositoryFramework.Query;
using BelleTire.RepositoryFramework.Query.ConditionalQuery.MatchCondition;

namespace BelleTire.Stores.Infrastructure.Repository.Conditions
{
    public class StoreNumberInList : RepositoryMatchConditionDefinition
    {
        public override string WhereClauseFormatString =>
            $"unit_num {RepositoryQueryCondition.InList.GetDescription()}";
    }
}