﻿using BelleTire.RepositoryFramework.Query.ConditionalQuery.MatchCondition;

namespace BelleTire.Stores.Infrastructure.Repository.Conditions
{
    public class StoreConditionIsActive : RepositoryMatchConditionDefinition
    {
        public override string WhereClauseFormatString => "unit_par.record_status = 1";
    }
}
