﻿using System.Collections.Generic;
using System.Linq;
using BelleTire.RepositoryFramework.Core;
using BelleTire.RepositoryFramework.DataMapping;
using BelleTire.RepositoryFramework.DataMapping.Reflection;
using BelleTire.RepositoryFramework.DataProviders;
using BelleTire.RepositoryFramework.Interface;
using BelleTire.Stores.Infrastructure.Repository.Conditions;
using BelleTire.Stores.Infrastructure.Repository.Entities;

namespace BelleTire.Stores.Infrastructure.Repository
{
    public class StoreRepository : RepositoryFramework.Repository.Repository
    {
        protected override IRepositoryQueryConfiguration QueryConfiguration =>
            new RepositoryQueryAutoConfiguration(new Store());

        protected override IRepositoryQueryEntityDefinition EntityDefinition =>
            new ReflectedEntityDefinition(new Store());

        private InformixDataProvider IfxProvider => (InformixDataProvider) DataProvider;

        public StoreRepository(IRepositoryDataProvider dataProvider) : base(dataProvider)
        {
        }

        public List<Store> GetActiveStores()
        {
            return Get<Store>(s => s.RecordStatus == 1).OrderBy(store=>store.StoreNumber).ToList();
        }

        public List<Store> GetStoresForList(List<int> unitNumList)
        {
            var matchCondition = new StoreNumberInList().GetConditionForDefinition(unitNumList);

            return Get<Store>(matchCondition);
        }

    }
}