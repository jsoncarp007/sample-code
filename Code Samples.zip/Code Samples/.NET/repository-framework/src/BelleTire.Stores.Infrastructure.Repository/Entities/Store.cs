﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using BelleTire.RepositoryFramework.Core.CustomAttributes;
using BelleTire.RepositoryFramework.DataMapping;

namespace BelleTire.Stores.Infrastructure.Repository.Entities
{
    [Table("unit_par")]
    public class Store : RepositoryDecoratedObject
    {
        [Key]
        [Column("unit_num")]
        public int StoreNumber { get; set; }

        [ValueListNameProperty]
        [Column("unit_name")]
        [MaxLength(30, ErrorMessage = "Max length is 30")]
        public string StoreName { get; set; }

        [Column("addr1")]
        [MaxLength(30, ErrorMessage = "Max length is 30")]
        public string Address1 { get; set; }

        [Column("addr2")]
        [MaxLength(30, ErrorMessage = "Max length is 30")]
        public string Address2 { get; set; }

        [Column("city")]
        [MaxLength(20, ErrorMessage = "Max length is 20")]
        public string City { get; set; }

        [Column("state")]
        [MaxLength(2, ErrorMessage = "Max length is 2")]
        public string State { get; set; }

        [Column("zip")]
        [MaxLength(10, ErrorMessage = "Max length is 10")]
        public string Zip { get; set; }

        [Column("phone")]
        [MaxLength(14, ErrorMessage = "Max length is 14")]
        public string Phone { get; set; }

        [Column("mgr_name")]
        [MaxLength(20, ErrorMessage = "Max length is 20")]
        public string ManagerName { get; set; }

        [Column("mgr_phone")]
        [MaxLength(14, ErrorMessage = "Max length is 14")]
        public string ManagerPhone { get; set; }

        [Column("asst_name")]
        [MaxLength(20, ErrorMessage = "Max length is 20")]
        public string AssistantManagerName { get; set; }

        [Column("asst_phone")]
        [MaxLength(14, ErrorMessage = "Max length is 14")]
        public string AssistantManagerPhone { get; set; }

        [Column("car_phone")]
        [MaxLength(14, ErrorMessage = "Max length is 14")]
        public string CarPhone { get; set; }

        [Column("price_reg")]
        [MaxLength(2, ErrorMessage = "Max length is 2")]
        public string PriceRegion { get; set; }

        [Column("bin_flag")]
        [MaxLength(1, ErrorMessage = "Max length is 1")]
        public string BinFlag { get; set; }

        [Column("pr_deflt")]
        [MaxLength(5, ErrorMessage = "Max length is 5")]
        public string PrDeflt { get; set; }

        [Column("tax_per")]
        [MaxLength(6, ErrorMessage = "Max length is 6")]
        public string TaxPer { get; set; }

        [Column("comment1")]
        [MaxLength(70, ErrorMessage = "Max length is 70")]
        public string Comment1 { get; set; }

        [Column("comment2")]
        [MaxLength(70, ErrorMessage = "Max length is 70")]
        public string Comment2 { get; set; }

        [Column("comment3")]
        [MaxLength(70, ErrorMessage = "Max length is 70")]
        public string Comment3 { get; set; }

        [Column("cust_num")]
        [MaxLength(8, ErrorMessage = "Max length is 8")]
        public string CustNum { get; set; }

        [Column("default_order_type")]
        [MaxLength(2, ErrorMessage = "Max length is 2")]
        public string DefaultOrderType { get; set; }

        [Column("default_acct_num")]
        [MaxLength(6, ErrorMessage = "Max length is 6")]
        public string DefaultAcctNum { get; set; }

        [Column("default_trans_type")]
        [MaxLength(2, ErrorMessage = "Max length is 2")]
        public string DefaultTransType { get; set; }

        [Column("default_order_grp")]
        [MaxLength(2, ErrorMessage = "Max length is 2")]
        public string DefaultOrderGrp { get; set; }

        [Column("default_area_code")]
        [MaxLength(3, ErrorMessage = "Max length is 3")]
        public string DefaultAreaCode { get; set; }

        [Column("return_stock_flag")]
        [MaxLength(1, ErrorMessage = "Max length is 1")]
        public string ReturnStockFlag { get; set; }

        [Column("use_bundle_flag")]
        [MaxLength(1, ErrorMessage = "Max length is 1")]
        public string UseBundleFlag { get; set; }

        [Column("default_slm")]
        [MaxLength(3, ErrorMessage = "Max length is 3")]
        public string DefaultSlm { get; set; }

        [Column("default_po")]
        [MaxLength(1, ErrorMessage = "Max length is 1")]
        public string DefaultPo { get; set; }

        [Column("default_mail_list")]
        [MaxLength(1, ErrorMessage = "Max length is 1")]
        public string DefaultMailList { get; set; }

        [Column("default_terms_cd")]
        [MaxLength(2, ErrorMessage = "Max length is 2")]
        public string DefaultTermsCd { get; set; }

        [Column("default_cust_type")]
        [MaxLength(2, ErrorMessage = "Max length is 2")]
        public string DefaultCustType { get; set; }

        [Column("default_finance")]
        [MaxLength(1, ErrorMessage = "Max length is 1")]
        public string DefaultFinance { get; set; }

        [Column("default_taxable")]
        [MaxLength(1, ErrorMessage = "Max length is 1")]
        public string DefaultTaxable { get; set; }

        [Column("resrv")]
        [MaxLength(113, ErrorMessage = "Max length is 113")]
        public string Resrv { get; set; }

        [Column("number_drawer")]
        public int NumberDrawer { get; set; }

        [Column("log_access")]
        public int LogAccess { get; set; }

        [Column("log_failure")]
        public int LogFailure { get; set; }

        [Column("use_store_num")]
        public int UseStoreNum { get; set; }

        [Column("record_status")]
        public int RecordStatus { get; set; }

        [Column("int6")]
        public int Int6 { get; set; }

    }
}
