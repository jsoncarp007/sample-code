
//////////////////////////////
// HvacConfiguration.cpp
//////////////////////////////

#include "Arduino.h"
#include <HvacConfiguration.h>

HvacConfiguration::HvacConfiguration() {
	HeatRelayPin = 0;
    AcRelayPin = 0;
    FanRelayPin = 0;
    RelayOnValue = 0;
    RelayOffValue = 0;
}

HvacConfiguration::HvacConfiguration(int heatRelayPin, int fanRelayPin, int acRelayPin, int onValue, int offValue) {
	HeatRelayPin = heatRelayPin;
    AcRelayPin = acRelayPin;
    FanRelayPin = fanRelayPin;
    RelayOnValue = onValue;
    RelayOffValue = offValue;
}