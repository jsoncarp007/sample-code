//////////////////////////////
// HvacConfiguration.h
//////////////////////////////

#ifndef HvacConfiguration_h
#define HvacConfiguration_h

#include "Arduino.h"

class HvacConfiguration
{
  public:
  	HvacConfiguration();
    HvacConfiguration(int heatRelayPin, int fanRelayPin, int acRelayPin, int onValue, int offValue);
    int HeatRelayPin;
    int AcRelayPin;
    int FanRelayPin;
    int RelayOnValue;
    int RelayOffValue;

};

#endif
