//////////////////////////////
// Mcp9808AverageTempCollector.cpp
//////////////////////////////

//////////////////////////////
// possible MCP9808 I2C addresses

  //  A2 A1 A0 address
  //  0  0  0   0x18  this is the default address
  //  0  0  1   0x19
  //  0  1  0   0x1A
  //  0  1  1   0x1B
  //  1  0  0   0x1C
  //  1  0  1   0x1D
  //  1  1  0   0x1E
  //  1  1  1   0x1F

// Sampling modes
  // Mode Resolution SampleTime
  //  0    0.5°C       30 ms
  //  1    0.25°C      65 ms
  //  2    0.125°C     130 ms
  //  3    0.0625°C    250 ms

//////////////////////////////


#include "Arduino.h"
#include "String.h"
#include <FloatValueAverager.h>
#include "Adafruit_MCP9808.h"
#include <elapsedMillis.h>
#include <Mcp9808AverageTempCollector.h>

const int POSSIBLE_I2C_ADDRESSES[8] = { 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F };

Mcp9808AverageTempCollector::Mcp9808AverageTempCollector() {
	_collectionIntervalMs = 30000;	
	_numValuesToAverage = 10;
}

Mcp9808AverageTempCollector::Mcp9808AverageTempCollector(int collectionIntervalMs, int numValuesToAverage) {
	_collectionIntervalMs = collectionIntervalMs;
	_numValuesToAverage = numValuesToAverage;	
}

void Mcp9808AverageTempCollector::Start() {	
	initTempSensors();

	Serial.println("Mcp9808AverageTempCollector: Initilizing FloatValueAverager");

	_floatValueAverager = FloatValueAverager(_numValuesToAverage, 74.0);
}

float Mcp9808AverageTempCollector::GetAveragedValue() {
	return _floatValueAverager.AveragedValue;
}

void Mcp9808AverageTempCollector::initTempSensors(){
	_numTempSensors = 0;

	Serial.println("Mcp9808AverageTempCollector: Looking for MCP9808 Devices");

	if (findSensor(_tempsensor1)) {
		_numTempSensors++;

		if (findSensor(_tempsensor2)) {
			_numTempSensors++;

			if (findSensor(_tempsensor3)) {
				_numTempSensors++;
			}
		}
	}
	else {
		Serial.println("Mcp9808AverageTempCollector: Error no temp sensors found!");
		return;
	}
 

  Serial.println("Mcp9808AverageTempCollector: Found " + String(_numTempSensors) + " MCP9808 sensor(s)");  

}

bool Mcp9808AverageTempCollector::findSensor(Adafruit_MCP9808& sensor) {
	sensor = Adafruit_MCP9808();

	for (int i=0;i<8;i++) {
		if (_inUseI2CAddresses[0] == POSSIBLE_I2C_ADDRESSES[i]) continue;
		if (_inUseI2CAddresses[1] == POSSIBLE_I2C_ADDRESSES[i]) continue;
		if (_inUseI2CAddresses[2] == POSSIBLE_I2C_ADDRESSES[i]) continue;

		if (sensor.begin(POSSIBLE_I2C_ADDRESSES[i])) {
			sensor.setResolution(3);
			Serial.println("Sensor found at " + String(POSSIBLE_I2C_ADDRESSES[i]));
			_inUseI2CAddresses[_numTempSensors] = POSSIBLE_I2C_ADDRESSES[i];
			return true;
		}		
	}

	return false;
}

void Mcp9808AverageTempCollector::AddExternalTempMeasurement(float temp) {
	_floatValueAverager.Add(temp);
}

float _currentReading;
void Mcp9808AverageTempCollector::Update() {	

	if (_sinceLastReading < _collectionIntervalMs) 
		return;

	if (_numTempSensors > 0) {		
		Serial.println("HvacController: Reading temp from sensor 1");
		_currentReading = _tempsensor1.readTempF();
		_floatValueAverager.Add(_currentReading);
		Serial.println("HvacController: Temp read from sensor 1: " + String(_currentReading));
	}

	if (_numTempSensors > 1) {		
		Serial.println("HvacController: Reading temp from sensor 2");
		_currentReading = _tempsensor2.readTempF();
		_floatValueAverager.Add(_currentReading);
		Serial.println("HvacController: Temp read from sensor 2: " + String(_currentReading));
	}

	if (_numTempSensors > 2) {		
		Serial.println("HvacController: Reading temp from sensor 3");
		_currentReading = _tempsensor3.readTempF();
		_floatValueAverager.Add(_currentReading);
		Serial.println("HvacController: Temp read from sensor 3: " + String(_currentReading));
	}

	_sinceLastReading = 0;	
}
