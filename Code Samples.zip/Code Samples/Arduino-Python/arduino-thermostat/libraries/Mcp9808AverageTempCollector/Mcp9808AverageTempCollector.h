
/////////////////////////////
// Mcp9808AverageTempCollector.h
//////////////////////////////

#ifndef Mcp9808AverageTempCollector_h
#define Mcp9808AverageTempCollector_h

#include "Arduino.h"
#include "String.h"
#include "Adafruit_MCP9808.h"
#include <elapsedMillis.h>
#include "FloatValueAverager.h"

class Mcp9808AverageTempCollector
{
  public:
    Mcp9808AverageTempCollector();
    Mcp9808AverageTempCollector(int collectionIntervalMs, int numValuesToAverage);
    void Start();
    void AddExternalTempMeasurement(float temp); 
    void Update();
    float GetAveragedValue();   

  private:
  	FloatValueAverager _floatValueAverager;
  	Adafruit_MCP9808 _tempsensor1;//= Adafruit_MCP9808(); 
  	Adafruit_MCP9808 _tempsensor2;
  	Adafruit_MCP9808 _tempsensor3;
  	int _collectionIntervalMs;
    int _numValuesToAverage;
  	elapsedMillis _sinceLastReading;
  	int _numTempSensors;
  	void initTempSensors();  	
  	bool findSensor(Adafruit_MCP9808& sensor);  	
    int _inUseI2CAddresses[3] = {0,0,0};

};

#endif