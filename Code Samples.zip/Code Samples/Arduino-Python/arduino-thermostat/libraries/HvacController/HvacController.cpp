
//////////////////////////////
// HvacController.cpp
//////////////////////////////

#include "Arduino.h"
#include "String.h"
#include <HvacConfiguration.h>
#include <elapsedMillis.h>
#include <Mcp9808AverageTempCollector.h>
#include <HvacController.h>
#include <EEPROM.h>

HvacController::HvacController(HvacConfiguration config, float tempBufferRange, int numOfTempValuesToAverage, int tempCollectIntervalMs, int heatOrCoolRequiredCheckIntervalMs) {
	_config = config;
	_tempCollectIntervalMs = tempCollectIntervalMs;
	_numOfTempValuesToAverage = numOfTempValuesToAverage;
	_tempBufferRange = tempBufferRange;
	_heatOrCoolRequiredCheckIntervalMs = heatOrCoolRequiredCheckIntervalMs;	
	_desiredTemp = 74.0;
	_sinceLastCoolingOperation = MODE_REVERSAL_DELAY;
	_sinceLastHeatOperation = MODE_REVERSAL_DELAY;
}

int tempEepromLocation = 10;
float _currentEpromValue = 0;
void HvacController::Start() {
	if (!EEPROM.begin(1000)) {
    	Serial.println("Failed to initialise EEPROM");   
  	}

	Serial.println("HvacController: Starting temp collector");
	_tempValueCollector = Mcp9808AverageTempCollector(_tempCollectIntervalMs, _numOfTempValuesToAverage);
	_tempValueCollector.Start();

	Serial.println("HvacController: Initilizing relays");
	initializeRelays(_config);	

	Serial.println("HvacController: Loading saved desired temp");
	_currentEpromValue = EEPROM.readFloat(tempEepromLocation);
	Serial.println("HvacController: Saved Temp EEPROM value = " + String(_currentEpromValue));
	if (_currentEpromValue != 255 && _currentEpromValue > 0) {
		_desiredTemp = _currentEpromValue;
	}
}

void HvacController::initializeRelays(HvacConfiguration config) {

	Serial.println("HvacController: Setting Heat Pin Mode");
	pinMode(config.HeatRelayPin, OUTPUT);

	Serial.println("HvacController: Setting Fan Pin Mode");
	pinMode(config.FanRelayPin, OUTPUT);

	Serial.println("HvacController: Setting AC Pin Mode");
	pinMode(config.AcRelayPin, OUTPUT);

	Serial.println("HvacController: Turning Heat Relay Off");
	digitalWrite(config.HeatRelayPin, config.RelayOffValue);

	Serial.println("HvacController: Turning Fan Relay Off");
	digitalWrite(config.FanRelayPin, config.RelayOffValue);

	Serial.println("HvacController: Turning Ac Relay Off");
	digitalWrite(config.AcRelayPin, config.RelayOffValue);
}

void HvacController::checkHeatingOrCoolingRequired() {		

	if (_sinceLastHeatOrCoolNeededCheck < _heatOrCoolRequiredCheckIntervalMs)
		return;

	if (_sinceLastOperation < MODE_CHANGE_DELAY)
		return;

	_sinceLastHeatOrCoolNeededCheck = 0;

	Serial.println("HvacController: Checking for heating or cooling required");

	switch (_currentOperationMode) {

		case OPERATION_MODE_IDLE:
			if (_tempValueCollector.GetAveragedValue() < _desiredTemp - _tempBufferRange && _sinceLastCoolingOperation > MODE_REVERSAL_DELAY) {
				setOperationMode(OPERATION_MODE_HEATING);
			} 
			else if (_tempValueCollector.GetAveragedValue() > _desiredTemp + _tempBufferRange && _sinceLastHeatOperation > MODE_REVERSAL_DELAY) {
				setOperationMode(OPERATION_MODE_COOLING);
			}
		break;

		case OPERATION_MODE_HEATING:
			if (_tempValueCollector.GetAveragedValue() > _desiredTemp) {
				setOperationMode(OPERATION_MODE_IDLE);
			}
		break;

		case OPERATION_MODE_COOLING:
		case OPERATION_MODE_FAN_ONLY:
			if (_tempValueCollector.GetAveragedValue() < _desiredTemp) {
				setOperationMode(OPERATION_MODE_IDLE);
			}
		break;
	}

}

void HvacController::setOperationMode(int operationMode) {
	switch (operationMode) {
		case OPERATION_MODE_IDLE:
				Serial.println("HvacController: Operaton mode set to IDLE");
				digitalWrite(_config.HeatRelayPin, _config.RelayOffValue);
				digitalWrite(_config.FanRelayPin, _config.RelayOffValue);
				digitalWrite(_config.AcRelayPin, _config.RelayOffValue);
			break;

		case OPERATION_MODE_HEATING:
				Serial.println("HvacController: Operaton mode set to HEATING");
				digitalWrite(_config.HeatRelayPin, _config.RelayOnValue);
				digitalWrite(_config.FanRelayPin, _config.RelayOffValue);
				digitalWrite(_config.AcRelayPin, _config.RelayOffValue);
				_sinceLastHeatOperation = 0;
			break;

		case OPERATION_MODE_FAN_ONLY:
				Serial.println("HvacController: Operaton mode set to FAN ONLY");
				digitalWrite(_config.HeatRelayPin, _config.RelayOffValue);
				digitalWrite(_config.FanRelayPin, _config.RelayOnValue);
				digitalWrite(_config.AcRelayPin, _config.RelayOffValue);
			break;

		case OPERATION_MODE_COOLING:
				Serial.println("HvacController: Operaton mode set to COOLING");
				digitalWrite(_config.HeatRelayPin, _config.RelayOffValue);
				digitalWrite(_config.FanRelayPin, _config.RelayOnValue);
				digitalWrite(_config.AcRelayPin, _config.RelayOnValue);
				_sinceLastCoolingOperation = 0;
			break;
	}

	_currentOperationMode = operationMode;
	_sinceLastOperation = 0;

}

void HvacController::Update() {

	_tempValueCollector.Update();

	if (_sinceLastOperation > _heatOrCoolRequiredCheckIntervalMs) {
		checkHeatingOrCoolingRequired();
	}
	
}

void HvacController::HeatTest() {
	Serial.println("HvacController: Running Heat Test");
	setOperationMode(OPERATION_MODE_HEATING);
}

void HvacController::FanTest() {
	Serial.println("HvacController: Running Fan Test");
	setOperationMode(OPERATION_MODE_FAN_ONLY);
}

void HvacController::AcTest() {
	Serial.println("HvacController: Running AC Test");
	setOperationMode(OPERATION_MODE_COOLING);
}

void HvacController::SetDesiredTemp(float desiredTemp) {
	_desiredTemp = desiredTemp;

	Serial.println("HvacController: Desired temp set to " + String(desiredTemp));

	Serial.println("HvacController: Saving desired temp to EEPROM - " + String(desiredTemp));
	EEPROM.writeFloat(tempEepromLocation, _desiredTemp);
	_currentEpromValue = EEPROM.readFloat(tempEepromLocation);
	Serial.println("HvacController: Temp saved to EEPROM - " + String(_currentEpromValue));
	EEPROM.commit();
}

float HvacController::GetDesiredTemp() {
	return _desiredTemp;
}

float HvacController::GetCurrentTemp() {
	return _tempValueCollector.GetAveragedValue();
}

int HvacController::GetCurrentOperationMode() {
	return _currentOperationMode;
}

String HvacController::GetCurrentOperationModeAsText() {
		switch (_currentOperationMode) {
			case OPERATION_MODE_IDLE:
				return "IDLE";
			break;

		case OPERATION_MODE_HEATING:
				return "HEAT";
			break;

		case OPERATION_MODE_FAN_ONLY:
				return "FAN";
			break;

		case OPERATION_MODE_COOLING:
				return "COOL";
			break;
		}
}

void HvacController::AddExternalTempMeasurement(float temp) {
	_tempValueCollector.AddExternalTempMeasurement(temp);
}

 