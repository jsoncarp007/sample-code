//////////////////////////////
// HvacController.h
//////////////////////////////

#ifndef HvacController_h
#define HvacController_h

#include "Arduino.h"
#include "String.h"
#include <HvacConfiguration.h>
#include "FloatValueAverager.h"
#include <elapsedMillis.h>
#include <Mcp9808AverageTempCollector.h>

class HvacController
{
  public:
    HvacController(HvacConfiguration config, float tempBufferRange, int numOfTempValuesToAverage, int tempCollectIntervalMs, int heatOrCoolRequiredCheckIntervalMs);  
    String GetStatusJson();
    void Start();
    void Update();
    void HeatTest();
    void FanTest();
    void AcTest();
    void SetDesiredTemp(float desiredTemp);
    float GetDesiredTemp();
    float GetCurrentTemp();
    int GetCurrentOperationMode();
    String GetCurrentOperationModeAsText();
    void AddExternalTempMeasurement(float temp);
    elapsedMillis MsSinceStart;
    
    static const int OPERATION_MODE_IDLE = 0;
    static const int OPERATION_MODE_HEATING = 1;
    static const int OPERATION_MODE_FAN_ONLY = 2;
    static const int OPERATION_MODE_COOLING = 3;

    static const int MODE_REVERSAL_DELAY = 8000000; // heat to cool or cool to heat mode change delay - 133 mins
    static const int MODE_CHANGE_DELAY = 90000; // run or idle for at least 1.5 mins

  private:
  	void initializeRelays(HvacConfiguration config);  	
  	void checkHeatingOrCoolingRequired();
  	void setOperationMode(int operationMode);
  	HvacConfiguration _config;
  	Mcp9808AverageTempCollector _tempValueCollector;
  	elapsedMillis _sinceLastOperation;
  	elapsedMillis _sinceLastHeatOperation;
  	elapsedMillis _sinceLastCoolingOperation; 	
    elapsedMillis _sinceLastHeatOrCoolNeededCheck;   
  	int _currentOperationMode;
  	float _desiredTemp;
  	float _tempBufferRange;
    int _heatOrCoolRequiredCheckIntervalMs;
    int _tempCollectIntervalMs;
    int _numOfTempValuesToAverage;
};


#endif
