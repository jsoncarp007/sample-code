/////////////////////////////
// HeltecOledDisplayManager.h
//////////////////////////////

#ifndef HeltecOledDisplayManager_h
#define HeltecOledDisplayManager_h

#include "Arduino.h"
#include "String.h"
#include "heltec.h"

class HeltecOledDisplayManager
{
  public:
    HeltecOledDisplayManager();
    void Start();  
    void ClearScreen();
    void ClearLine(int lineNumber);
    void WriteScreenText(String textToWrite, int lineNumber);
    void DrawProgressBar(int lineNumber, int height, int total, int current);

    static const int DEFAULT_OLED_LINE_HEIGHT = 16;

  private:
  	void initDisplay();
   	int _lineHeight;
   	int _currentProgressBarPercent = 0;
	String _currentProgressBarText = "";    
};

#endif