//////////////////////////////
// HeltecOledDisplayManager.cpp
//////////////////////////////

#include "Arduino.h"
#include "String.h"
#include "heltec.h"
#include "HeltecOledDisplayManager.h"

HeltecOledDisplayManager::HeltecOledDisplayManager() {
	_lineHeight = DEFAULT_OLED_LINE_HEIGHT;
}

void HeltecOledDisplayManager::Start() {
		initDisplay();
}

void HeltecOledDisplayManager::ClearScreen() {
    Heltec.display->clear();  
}

void HeltecOledDisplayManager::ClearLine(int lineNumber) {
    Heltec.display->drawString(0, lineNumber*DEFAULT_OLED_LINE_HEIGHT, "                                      ");
    Heltec.display->display(); 
}

void HeltecOledDisplayManager::WriteScreenText(String textToWrite, int lineNumber) {  
    Heltec.display->drawString(0, lineNumber*DEFAULT_OLED_LINE_HEIGHT, textToWrite);
    Heltec.display->display();
}



void HeltecOledDisplayManager::DrawProgressBar(int lineNumber, int height, int total, int current) {
  _currentProgressBarPercent = (current / (total / 100));
  _currentProgressBarText = String(current / (total / 100)) + "%";
  
  Heltec.display->drawProgressBar(0, lineNumber * DEFAULT_OLED_LINE_HEIGHT, 64, height, _currentProgressBarPercent);
  Heltec.display->setTextAlignment(TEXT_ALIGN_CENTER);          
  Heltec.display->drawString(10, lineNumber * DEFAULT_OLED_LINE_HEIGHT, _currentProgressBarText);
  Heltec.display->display();
}

void HeltecOledDisplayManager::initDisplay() {

  switch (DEFAULT_OLED_LINE_HEIGHT) {
    case 24: 
      Heltec.display->setFont(ArialMT_Plain_24);        
    break;
    case 16: 
      Heltec.display->setFont(ArialMT_Plain_16);        
    break;
    case 10: 
      Heltec.display->setFont(ArialMT_Plain_10);        
    break;
  }   
  
  Heltec.display->setTextAlignment(TEXT_ALIGN_LEFT);
}