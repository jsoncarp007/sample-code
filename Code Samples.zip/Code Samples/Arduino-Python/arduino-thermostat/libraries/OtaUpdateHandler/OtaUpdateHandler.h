//////////////////////////////
// OtaUpdateHandler.h
//////////////////////////////

#ifndef OtaUpdateHandler_h
#define OtaUpdateHandler_h

#include "Arduino.h"
#include <String.h>
#include <ArduinoOTA.h>

class OtaUpdateHandler
{
  public:
  	OtaUpdateHandler();
    void Init();
    void Update();
  private:
};

#endif
