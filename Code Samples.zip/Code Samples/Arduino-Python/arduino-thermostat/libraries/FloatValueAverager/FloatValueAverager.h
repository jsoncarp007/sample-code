/////////////////////////////
// FloatValueAverager.h
//////////////////////////////

#ifndef FloatValueAverager_h
#define FloatValueAverager_h

#include "Arduino.h"
#include "String.h"

class FloatValueAverager
{
  public:
  	FloatValueAverager();
    FloatValueAverager(int numValuesToStore, float initialValue);
    void Add(float value);     
    float AveragedValue;

  private:
  	static const int MAX_VALUES_TO_AVERAGE = 30;
  	void setup(int numValuesToStore, float initialValue);
  	void setAveragedValue();
    float _floatValueArray[30];
    float _currentValueSum;
    String _valuesListAsString;
    int _currentArrayPosition;
    int _currentArrayAveragingIndex;
    int _numValuesToStore;
};

#endif