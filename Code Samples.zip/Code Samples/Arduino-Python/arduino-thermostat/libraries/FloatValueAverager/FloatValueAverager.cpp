
//////////////////////////////
// FloatValueAverager.cpp
//////////////////////////////

#include "Arduino.h"
#include "String.h"
#include "FloatValueAverager.h"

FloatValueAverager::FloatValueAverager() {
	setup(10, 74.0);
}

FloatValueAverager::FloatValueAverager(int numValuesToStore, float initialValue) {	
	setup(numValuesToStore, initialValue);	
}

void FloatValueAverager::Add(float value) {
	_floatValueArray[_currentArrayPosition] = value;

	_currentArrayPosition++;
	if (_currentArrayPosition >= _numValuesToStore) {
		_currentArrayPosition = 0;
	}

	setAveragedValue();
}

void FloatValueAverager::setup(int numValuesToStore, float initialValue) {

	Serial.println("FloatValueAverager: Initilizing array values");

	_numValuesToStore = numValuesToStore;
	_currentArrayPosition = 0;

	if (_numValuesToStore > MAX_VALUES_TO_AVERAGE)
		_numValuesToStore = MAX_VALUES_TO_AVERAGE;

	for(int i=0;i<_numValuesToStore;i++){
		_floatValueArray[i] = initialValue;
	}

	Serial.println("FloatValueAverager: Setting initial averaged value");

	AveragedValue = initialValue;
}

void FloatValueAverager::setAveragedValue(){
	
	_currentValueSum = 0;

	for(_currentArrayAveragingIndex=0;_currentArrayAveragingIndex<_numValuesToStore;_currentArrayAveragingIndex++) {
		_currentValueSum += _floatValueArray[_currentArrayAveragingIndex];
	}

	AveragedValue = _currentValueSum / _numValuesToStore;
}
