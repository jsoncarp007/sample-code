
//////////////////////////////
// SimpleWifiHttpServer.cpp
//////////////////////////////

#include "Arduino.h"
#include "String.h"
#include "SimpleWifiHttpServer.h"
#include "SPIFFS.h"
#include <WiFi.h>
#include "heltec.h"

SimpleWifiHttpServer::SimpleWifiHttpServer()
{
}

bool SimpleWifiHttpServer::Start(const char *ssid, const char *password)
{
  Serial.print("SimpleWifiHttpServer: Connecting to ");
  Serial.println(ssid);

  WiFi.disconnect(true);
  delay(1000);

  WiFi.mode(WIFI_STA);
  WiFi.setAutoConnect(true);
  WiFi.setAutoReconnect(true);
  WiFi.begin(ssid, password);

  int count = 0;
  while (WiFi.status() != WL_CONNECTED && count < 500)
  {
    count++;
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  if (count < 500)
  {
    Serial.println("SimpleWifiHttpServer: WiFi connected.");
    Serial.println("SimpleWifiHttpServer: IP address: ");
    _serverIpAddress = String(WiFi.localIP());
    Serial.println(WiFi.localIP());

    Serial.println("SimpleWifiHttpServer: Starting Wifi Server");
    _server = WiFiServer(80);
    _server.begin();
    loadHtmlFileFromSpffs();
    return true;
  }
  else
  {
    Serial.println("SimpleWifiHttpServer: WiFi startup failed");
    return false;
  }
}

void SimpleWifiHttpServer::loadHtmlFileFromSpffs()
{
  Serial.println("SimpleWifiHttpServer: Starting SPFFS");
  if (!SPIFFS.begin())
  {
    Serial.println("SimpleWifiHttpServer: An Error has occurred while mounting SPIFFS");
    return;
  }

  Serial.println("SimpleWifiHttpServer: Opening Index.html");

  _indexHtmlFile = SPIFFS.open("/Index.html");

  if (!_indexHtmlFile)
  {
    Serial.println("SimpleWifiHttpServer: Failed to open Index.html file for reading");
    return;
  }

  _indexHtmlContents = "";

  while (_indexHtmlFile.available())
  {
    _indexHtmlContents += _indexHtmlFile.readStringUntil('\n');
  }

  Serial.println("SimpleWifiHttpServer: Index contents = " + _indexHtmlContents);

  _indexHtmlFile.close();
}

String SimpleWifiHttpServer::GetIncomingClientCommand()
{

  _readLoopAttempts = 0;
  _currentHttpCommand = "";
  _client = _server.available();

  if (_client)
  {
    Serial.println("SimpleWifiHttpServer: Processing incoming HTTP client request");
    _currentLine = ""; // make a String to hold incoming data from the client
    while (_client.connected() && _readLoopAttempts < 2000)
    { // loop while the client's connected
      _readLoopAttempts++;
      if (_client.available())
      {                                      // if there's bytes to read from the client,
        _currentStreamChar = _client.read(); // read a byte, then
        if (_currentStreamChar == '\n')
        { // if the byte is a newline character

          // if the current line is blank, you got two newline characters in a row.
          // that's the end of the client HTTP request, so send a response:
          if (_currentHttpCommand == "GET / HTTP/1.1")
          {
            sendResponseHeader("html");
            sendIndexHtml();
            sendResponseEnd();
            return "";
          }

          if (_currentLine.length() == 0)
          {

            Serial.println("SimpleWifiHttpServer: Starting HTTP response");

            sendResponseHeader("json");

            Serial.println("SimpleWifiHttpServer: Responding to command - '" + _currentHttpCommand + "'");

            if (_currentHttpCommand == "")
            {
              _client.print("");

              // The HTTP response ends with another blank line:
              _client.println();

              _client.stop();

              Serial.println("SimpleWifiHttpServer: Finished (empty) HTTP Response");
            }

            return _currentHttpCommand;
          }
          else
          { // if you got a newline, run then clear _currentLine:
            if (_currentLine.startsWith("GET /"))
              _currentHttpCommand = _currentLine;

            _currentLine = "";
          }
        }
        else if (_currentStreamChar != '\r')
        {                                     // if you got anything else but a carriage return character,
          _currentLine += _currentStreamChar; // add it to the end of the _currentLine
        }
      }
    }
    Serial.println("SimpleWifiHttpServer: Finished reading incoming request, no data??");
  }
  return "";
}

void SimpleWifiHttpServer::sendResponseHeader(String contentType)
{
  Serial.println("SimpleWifiHttpServer: adding HTTP header to response");
  // HTTP headers always start with a response code (e.g. HTTP/1.1 200 OK)
  // and a content-type so the client knows what's coming, then a blank line:
  _client.println("HTTP/1.1 200 OK");
  _client.println("Content-type:text/" + contentType);
  _client.println("access-control-allow-origin: *");
  _client.println();
}

void SimpleWifiHttpServer::sendIndexHtml()
{
  Serial.println("SimpleWifiHttpServer: adding Index.html contents to response");
  _client.print(_indexHtmlContents);
}

void SimpleWifiHttpServer::sendResponseEnd()
{
  // The HTTP response ends with another blank line:
  _client.println();

  _client.stop();
}

void SimpleWifiHttpServer::SendCommandResponseJson(String commandResponseJson)
{
  Serial.println("SimpleWifiHttpServer: Sending json response: " + commandResponseJson);

  _client.print(commandResponseJson);

  sendResponseEnd();

  Serial.println("SimpleWifiHttpServer: Finished JSON Response");
}

String SimpleWifiHttpServer::GetServerIpAddress()
{
  return _serverIpAddress;
}