
/////////////////////////////
// SimpleWifiHttpServer.h
//////////////////////////////

#ifndef SimpleWifiHttpServer_h
#define SimpleWifiHttpServer_h

#include "Arduino.h"
#include "String.h"
#include <WiFi.h>
#include "heltec.h"
#include "SPIFFS.h"

class SimpleWifiHttpServer
{
  public:
    SimpleWifiHttpServer();
    bool Start(const char* ssid, const char* password);
    String GetIncomingClientCommand();
    void SendCommandResponseJson(String commandResponseJson);
    String GetServerIpAddress();

  private:
    void sendResponseHeader(String contentType);
    void sendIndexHtml();
    void sendResponseEnd();
    void loadHtmlFileFromSpffs();
  	WiFiServer _server;
    WiFiClient _client;
    String _serverIpAddress;
    String _currentLine;
    String _currentHttpCommand;
    char _currentStreamChar;
    int _readLoopAttempts;    
    File _indexHtmlFile;
    String _indexHtmlContents;
};

#endif
