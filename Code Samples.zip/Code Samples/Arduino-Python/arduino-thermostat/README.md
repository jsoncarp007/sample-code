# arduino-thermostat

This repository contains all code required to create an Arduino based WiFi enabled Thermostat, with optional remote temperature sensors.   

Please contact me if you are interested in contributing to this project.  

Primary device: 
- MakerFocus ESP32 Development Board Upgraded Version 8MB Flash, ESP32 WiFi Bluetooth, ESP32 OLED 0.96 Inch OLED Display (https://www.amazon.com/gp/product/B076KJZ5QM/ref=ppx_yo_dt_b_search_asin_title?ie=UTF8&psc=1)
- MCP9808 Temp Sensor
- 3 relays.  For my system I actually replaced the entire 24V AC part of the HVAC system (it died) and use high voltage/amperage relays to turn on the fan, furnace and AC - but just about any simple/cheap 10A relays will work for a normal thermostat implementation.  

Secondary Device(s):
- Raspberry Pi Zero (will run on any Pi or other device that can run Python and support the MCP9809 Python library)
- Pi Supply PaPiRus Zero ePaper/eInk pHAT v1.2 (https://www.adafruit.com/product/3335)  -- optional
- MCP9808 Temp Sensor


Primary Device Features:
- Automatic (configurable) temperature reading averaging
- Automatic detection of up to 3 MCP9808 attached sensors
- HTTP server (over WiFi, with HTML/JS thermostat UI)
- Support for remove temp sensor input (via HTTP request)
- Persistant desired temperature (stored to SPIFFS)
- OLED (0.96") status display

Secondary Device Features: 
- Reads attached MCP9808 temp sensor and sends data (via HTTP) to primary device
- Optionally - displays status/thermostat information (currently supports PaPiRus ePaper pHAT but could easily be switched to an LCD or other display type)

-------------------------------------------------------------------

Wiring / Hardware

Primary Device
- Attach MCP9808 to ESP32 - (note the I2C pin remap that the OLED screen init causes)
- Attach ground output wire
- Attach heat relay + wire
- Attach fan relay + wire
- Attach AC relay + wire


Secondary Devices
- Attach MCP9808


