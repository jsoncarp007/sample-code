import sys
sys.path.append("/home/pi/PaPiRus")

import urllib.request, json, time
from papirus import PapirusTextPos
import Adafruit_MCP9808.MCP9808 as MCP9808

loopSleepTimeSeconds = 30

baseUrl = 'http://10.0.0.230/'
getHvacDataUrl = baseUrl + 'STATUS'
sendTempDataUrl = baseUrl + 'R/'
setDesiredTempUrl = baseUrl +'T/'
pathToFont = '/home/pi/Roboto-Medium.ttf'
pathToBoldFont = '/home/pi/Roboto-Bold.ttf'

text = PapirusTextPos(False)
lineSpacing = 20
startY = 5
startLabelX = 5
startValueX = 140

print("Initilizing Temp Sensor")

mcp = MCP9808.MCP9808()
mcp.begin()

def getHvacData():	
		response = urllib.request.urlopen(getHvacDataUrl)		
		data = json.loads(response.read())
		return data

def initScreen(): 	
	text.Clear()
	
	linePosition = startY
	
	text.AddText("Avg Temp", startLabelX, linePosition, fontPath=pathToFont)
	text.AddText("?", startValueX, linePosition, Id="CurrentTemp", fontPath=pathToBoldFont)
	
	linePosition = linePosition + lineSpacing
	text.AddText("Local Temp", startLabelX, linePosition, fontPath=pathToFont)
	text.AddText("?", startValueX, linePosition, Id="LocalTemp", fontPath=pathToBoldFont)

	linePosition = linePosition + lineSpacing
	text.AddText("Set", startLabelX, linePosition, fontPath=pathToFont)
	text.AddText("?", startValueX, linePosition, Id="SetTemp", fontPath=pathToBoldFont)

	linePosition = linePosition + lineSpacing
	text.AddText("Mode", startLabelX, linePosition, fontPath=pathToFont)
	text.AddText("?", startValueX, linePosition, Id="Mode", fontPath=pathToBoldFont)
	text.WriteAll()
	print("Epaper Screen initilized")

def updateScreen(hvacData, localSensorTemp): 	
	text.UpdateText("LocalTemp", str(localSensorTemp), fontPath=pathToBoldFont)
	if hvacData["responseCode"] == 'STATUS':
		text.UpdateText("SetTemp", str(hvacData["desiredTemp"]), fontPath=pathToBoldFont)
		text.UpdateText("CurrentTemp", str(hvacData["averagedTemp"]), fontPath=pathToBoldFont)	
		text.UpdateText("Mode", getModeName(int(hvacData["operationMode"])), fontPath=pathToBoldFont)		
	text.WriteAll(True)

def getModeName(modeInt):
	modeNames = { 0: "Idle", 1: "Heat", 2: "Fan", 3: "Cool"}
	return modeNames.get(modeInt, "Unknown")


def getTempFromSensor():
	tempC = mcp.readTempC()
	tempF = tempC * 9 / 5 + 32
	return tempF

def sendTempToHvacController(temp):
	urllib.request.urlopen(sendTempDataUrl + str(temp))

def executeActions():
	currentLocalTemp = getTempFromSensor()
	updateScreen(getHvacData(), currentLocalTemp)	
	if currentLocalTemp > 0:
		sendTempToHvacController(currentLocalTemp)


#################################################

initScreen()

print("Initialized")

while True:
	try:
		executeActions()					
	except:
		print(actionError)
	time.sleep(loopSleepTimeSeconds)

print("Exited")