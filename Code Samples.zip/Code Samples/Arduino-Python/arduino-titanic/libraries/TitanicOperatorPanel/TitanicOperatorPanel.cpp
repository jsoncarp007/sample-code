#include <String.h>
#include <TitanicOperatorPanel.h>
#include <TitanicTransmitter.h>
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define BATTERY_HIGH 14.8
#define BATTERY_LOW 12.0
#define TX_BATTERY_HIGH 4.2
#define TX_BATTERY_LOW 3.55

#define POTENTIOMETER_BOTTOM 0
#define POTENTIOMETER_TOP 1023

#define BUTTON1_RANGE_BOTTOM 505
#define BUTTON1_RANGE_TOP 515

#define BUTTON2_RANGE_BOTTOM 198
#define BUTTON2_RANGE_TOP 207

#define BUTTON3_RANGE_BOTTOM 250
#define BUTTON3_RANGE_TOP 260

#define BUTTON4_RANGE_BOTTOM 330
#define BUTTON4_RANGE_TOP 350

#define VOLTAGE_ARRAY_SIZE 4

unsigned long lastScreenUpdate = millis() + 5000;
unsigned long lastVoltageReading = millis();

int txBattReadings[VOLTAGE_ARRAY_SIZE];

TitanicOperatorPanel::TitanicOperatorPanel(TitanicTransmitter& transmitter)
: display(128, 64, &Wire, -1) {
    _titanicTransmitter = transmitter;
}

void TitanicOperatorPanel::Init(double transmitterFrequency) {    

    if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) 
        return;
    
    display.display(); 
    delay(2000);
    display.setTextSize(1);
    display.setTextColor(WHITE);

    _titanicTransmitter.Init(transmitterFrequency);
    initInputPins();   
}

void TitanicOperatorPanel::initInputPins() {// A0, A1, A5
    pinMode(A0, INPUT);
    pinMode(A1, INPUT);
    pinMode(A5, INPUT); 
    pinMode(A7, INPUT);
}

void TitanicOperatorPanel::Update() {
    _titanicTransmitter.Update();

    updateThrottle();
    updateSteeringAngle();
    checkButtonPress();    

    if (millis() - lastScreenUpdate > 3000) {
        updateLcdDisplay();
        updateVoltageArray();
        lastScreenUpdate = millis();
    }    
}

short currentVotageArrayIndex = 0;
void TitanicOperatorPanel::updateVoltageArray() {
    txBattReadings[currentVotageArrayIndex] = analogRead(A7);
    currentVotageArrayIndex++;
    if (currentVotageArrayIndex > VOLTAGE_ARRAY_SIZE) {
        currentVotageArrayIndex = 0;
    }    
}

int totalOfVoltageReadings = 0;
float measuredvbat = 0.0;
float TitanicOperatorPanel::getLocalBatteryVolts() {  
    totalOfVoltageReadings = 0;     
    for(int i=0;i<VOLTAGE_ARRAY_SIZE;i++) {
        totalOfVoltageReadings += txBattReadings[i];
    }
    measuredvbat = totalOfVoltageReadings > 0 ? totalOfVoltageReadings / VOLTAGE_ARRAY_SIZE : 0; 
    measuredvbat *= 2;    // voltage reading divided by 2, so multiply back
    measuredvbat *= 3.3;  // Multiply by 3.3V, the reference voltage
    measuredvbat /= 1024; // convert to voltage
    return measuredvbat;
}

void TitanicOperatorPanel::updateThrottle() {
    _currentThrottle = getThrottlePercent();
    if (_currentThrottle != _previousThrottle) {
        _titanicTransmitter.SetThrottle(_currentThrottle);
        _previousThrottle = _currentThrottle;
    }    
}

int TitanicOperatorPanel::getThrottlePercent() {       
    return map(analogRead(A0), POTENTIOMETER_BOTTOM, POTENTIOMETER_TOP, -50, 50);
}

void TitanicOperatorPanel::updateSteeringAngle() {
    _currentSteeringAngle = getTurnAngle();
    if (_currentSteeringAngle != _previousSteeringAngle) {
        _titanicTransmitter.SetOrientation(_currentSteeringAngle);
    }
    _previousThrottle = _currentThrottle;
}

int TitanicOperatorPanel::getTurnAngle() {
    return map(analogRead(A1), POTENTIOMETER_BOTTOM, POTENTIOMETER_TOP, -45, 45);
}

uint16_t _currentPinValue;
uint8_t _lastActiveButton;
unsigned long lastButtonPress = millis();
void TitanicOperatorPanel::checkButtonPress() {
    if (millis() - lastButtonPress < 1500) return;

    _currentPinValue = analogRead(A5);  

    if (_currentPinValue >= BUTTON1_RANGE_BOTTOM && _currentPinValue <= BUTTON1_RANGE_TOP && _lastActiveButton != 1) {
        _titanicTransmitter.ToggleSteamMode();        
        _lastActiveButton = 1;
        lastButtonPress = millis();
    } else if (_currentPinValue >= BUTTON2_RANGE_BOTTOM && _currentPinValue <= BUTTON2_RANGE_TOP && _lastActiveButton != 2) {
        _titanicTransmitter.SetNextLightPattern();
        _lastActiveButton = 2;
        lastButtonPress = millis();
    } else if (_currentPinValue >= BUTTON3_RANGE_BOTTOM && _currentPinValue <= BUTTON3_RANGE_TOP && _lastActiveButton != 3) {
        _titanicTransmitter.PlaySound();        
        _lastActiveButton = 3;
        lastButtonPress = millis();
    } else if (_currentPinValue >= BUTTON4_RANGE_BOTTOM && _currentPinValue <= BUTTON4_RANGE_TOP && _lastActiveButton != 4) {
        _titanicTransmitter.PlayNextSound();
        _lastActiveButton = 4;
        lastButtonPress = millis();
    } else {
        _lastActiveButton = 0;
    }     
}

uint8_t displayLoopCount = 0;
float txVolts = 0.0;
void TitanicOperatorPanel::updateLcdDisplay() {       
    display.clearDisplay();       

    printDisplayLine(0, F("Batt"), String(map(_titanicTransmitter.RxBatteryVolt, BATTERY_LOW, BATTERY_HIGH, 0, 100)) + F("% (") + String(_titanicTransmitter.RxBatteryVolt) + F("v)"));    
    printDisplayLine(1, F("Signal"), String(map(_titanicTransmitter.RxRssi, -100, -40, 0, 100)) + F("% (") + String(_titanicTransmitter.RxRssi) + F(")"));    
    printDisplayLine(2, F("Speed"), String(_currentThrottle) + F("%"));        
    printDisplayLine(3, F("Turn"), String(_currentSteeringAngle));   
    
    switch (displayLoopCount) {
        case 0: 
            printDisplayLine(4, F("Water"), String(_titanicTransmitter.RxWaterLevel < 100 ? F("No") : F("Alert!")));        
        break;
        case 1:
            printDisplayLine(4, F("Dist"), String(_titanicTransmitter.MetersFromStart));        
        break;
        case 2:
            printDisplayLine(4, F("Steam"), _titanicTransmitter.SteamOn ? F("Yes") : F("No"));        
        break;
        case 3:
            printDisplayLine(4, F("Facing"), String(_titanicTransmitter.FacingDirection));
        break;
        case 4:
            txVolts = getLocalBatteryVolts();
            printDisplayLine(4, F("TxBat"), String(map(txVolts, TX_BATTERY_LOW, TX_BATTERY_HIGH, 0, 100)) + F("% (") + String(txVolts) + F("v)"));        
        break;
    }
    display.display();

    displayLoopCount++;

    if (displayLoopCount > 4) 
        displayLoopCount = 0;
}

void TitanicOperatorPanel::printDisplayLine(int lineNumber, String label, String value) 
{
    display.setCursor(5, 5 + (lineNumber * 10));
    display.print(label);
    display.setCursor(50, 5 + (lineNumber * 10));
    display.print(value);
}