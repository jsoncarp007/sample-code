#ifndef TitanicOperatorPanel_h
#define TitanicOperatorPanel_h

#include <Arduino.h>
#include <TitanicTransmitter.h>
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

class TitanicOperatorPanel
{
  public:
    TitanicOperatorPanel(TitanicTransmitter& transmitter);
    void Init(double transmitterFrequency);   
    void Update();
   private:
    float getLocalBatteryVolts();
    void updateThrottle();
    void updateSteeringAngle();
    void checkButtonPress();
    int getThrottlePercent();
    int getTurnAngle();
    void initInputPins();
    void updateVoltageArray();
    void updateLcdDisplay();
    void printDisplayLine(int lineNumber, String label, String value);

    Adafruit_SSD1306 display;

    TitanicTransmitter _titanicTransmitter;
    
    int _currentThrottle;
    int _previousThrottle;
    int _currentSteeringAngle;
    int _previousSteeringAngle;

    long _lastThrottleValueTransmittedMs;
    long _lastSterringAngleValueTransmission;       
};

#endif
