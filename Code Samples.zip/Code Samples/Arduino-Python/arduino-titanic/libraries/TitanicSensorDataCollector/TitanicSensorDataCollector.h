
#ifndef TitanicSensorDataCollector_h
#define TitanicSensorDataCollector_h

#include <Arduino.h>
#include <Adafruit_INA260.h>
#include <Wire.h>
#include <ADS1X15.h>

class TitanicSensorDataCollector {
    public:       
        void Init();
        void Update();  
        short int GetWaterLevel();
        float GetVoltage();
    private:      
        float getVoltageFromSensor();
        short int getWaterLevelFromSensor();   
        Adafruit_INA260 ina260 = Adafruit_INA260();
        ADS1115 ads = ADS1115(0x48);
};

#endif
