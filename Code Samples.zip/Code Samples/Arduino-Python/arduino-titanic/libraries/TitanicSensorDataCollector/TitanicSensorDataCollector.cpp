#include <TitanicSensorDataCollector.h>

#define WATER_SENSOR_PIN 1

int currentWaterLevelReading;
float currentVoltage = 21.0;
unsigned long lastUpdate = 0;

void TitanicSensorDataCollector::Init() { 
    Serial.print(F("Initilizing sensors... "));
    //pinMode(WATER_SENSOR_PIN, INPUT);    
    ina260.begin(0x44);   
    ads.begin();  //0x48 - is default - set in constructor
    ads.requestADC(0);
    Serial.println("Done");
}

void TitanicSensorDataCollector::Update() {
    if (millis() - lastUpdate < 5000) return;  

    if (ads.isReady())
    {
        currentWaterLevelReading = ads.getValue();
        ads.requestADC(0);       
    }     
    lastUpdate = millis();
}

short int TitanicSensorDataCollector::GetWaterLevel() {    
    return getWaterLevelFromSensor();
}

float TitanicSensorDataCollector::GetVoltage() {   
    return getVoltageFromSensor();
}

short int TitanicSensorDataCollector::getWaterLevelFromSensor() {  
    return currentWaterLevelReading;
}

float TitanicSensorDataCollector::getVoltageFromSensor() {
   return ina260.readBusVoltage() / 1000; 
}