#include <GpsReceiver.h>

unsigned long age = 0;
float startLatitude = 0.0;
float startLongitude = 0.0;
float currentLatitude = 0.0;
float currentLongitude = 0.0;

void GpsReceiver::Init() {      
    Serial.print(F("Initlizing GPS..."));
    gpsSerial.begin(115200);
    Serial.println(F("Done"));
}

void GpsReceiver::Update() {
    while (gpsSerial.available() > 0)
       gps.encode(gpsSerial.read()); 
            
    if (gps.satellites() > 3) {
        gps.f_get_position(&currentLatitude, &currentLongitude, &age);  
        if (!HasGpsFix) {
            setCurrentPositionAsStartPoint();
        }
    }         
}  

short int GpsReceiver::GetTurnDegreesToHome() {
    if (gps.f_course() > gps.course_to(currentLatitude, currentLongitude, startLatitude, startLongitude)){       
        return -(int(gps.f_course()) - int(gps.course_to(currentLatitude, currentLongitude, startLatitude, startLongitude)));
    }
    else {       
        return int(gps.course_to(currentLatitude, currentLongitude, startLatitude, startLongitude)) - int(gps.f_course());
    }
}

float GpsReceiver::GetSpeedMph() {
    return gps.f_speed_mph();
}

const char* GpsReceiver::GetHeadingDirection() {
    return gps.cardinal(gps.f_course());
}

uint32_t GpsReceiver::GetMetersToHome() {
    return gps.distance_between(currentLatitude, currentLongitude, startLatitude, startLongitude);
}

void GpsReceiver::setCurrentPositionAsStartPoint() {
    Serial.println(F("Got GPS Lock"));
    startLatitude = currentLatitude;
    startLongitude = currentLongitude;
    HasGpsFix = true;
}