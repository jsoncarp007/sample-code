/////////////////////////////
// GpsReceiver.h
//////////////////////////////

#ifndef GpsReceiver_h
#define GpsReceiver_h

#include <Arduino.h>
#include <String.h>
#include <SoftwareSerial.h> 
#include <TinyGPS.h>

class GpsReceiver
{
    public:
        GpsReceiver() : gpsSerial(2,50) {}
        void Init();
        void Update();        
        short int GetTurnDegreesToHome();
        const char* GetHeadingDirection();
        float GetSpeedMph();
        uint32_t GetMetersToHome();
        bool HasGpsFix;  
        
    private:
        void setCurrentPositionAsStartPoint();
        SoftwareSerial gpsSerial;
        TinyGPS gps;
};


#endif

