#ifndef TitanicTransmitter_h
#define TitanicTransmitter_h

#include <Arduino.h>
#include <String.h>
#include <LoRaTransceiver.h>
#include <TitanicCommunications.h>

class TitanicTransmitter
{
  public:
    void Init(double frequency);   
    void Update();
   
    void SetThrottle(int throttlePercent);
    void SetOrientation(int turningAngle);
    void PlaySound();
    void PlaySound(uint8_t soundId);
    void PlayNextSound();
    void ToggleSteamMode();
    void SetSteamMode(bool steamOn);
    void SetLightPattern(uint8_t lightPattern);   
    void SetNextLightPattern();
    void ToggleReturnHomeMode();

    int RxRssi = 0;
    float RxBatteryVolt = 0.0;
    int RxWaterLevel = 0;
    float MetersFromStart = 0.0;
    String FacingDirection;
    bool SteamOn;
    bool ReturningHome;

  private: 
    String getSyncMessage();
    String getValue(String data, char separator, int index);
    void processSerialMessage(String message);
    void processReceivedMessage(String message);
    LoRaTransceiver _loRaTransceiver;
    String _receivedMessage; 
    String _incomingMessageCommandCode;
    String _incomingMessageCommandValue;   
};

#endif
