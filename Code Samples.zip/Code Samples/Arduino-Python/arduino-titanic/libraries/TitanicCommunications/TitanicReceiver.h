#ifndef TitanicReceiver_h
#define TitanicReceiver_h

#include <Arduino.h>
#include <String.h>
#include <TitanicCommunications.h>
#include <TitanicSystemsController.h>
#include <LoRaTransceiver.h>

class TitanicReceiver
{
  public:
    void Init(double frequency);   
    void Update();
   private:
    void processIncomingMessage(String message);
    void transmitStatus();
    TitanicSystemsController _systemsController;
    LoRaTransceiver _loRaTransceiver;
    String _incomingMessage;
    String _incomingMessageCommandCode;
    String _incomingMessageCommandValue;  
    long _lastStatusSentAt = millis() + STATUS_UPDATE_INTERVAL;     
};

#endif
