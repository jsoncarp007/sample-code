#include <String.h>
#include <TitanicCommunications.h>
#include <TitanicTransmitter.h>
#include <LoRaTransceiver.h>

int lastCommandMatrix[5] = {0, 0, 0, 0, 0 };
short currentLightPattern = 0;

String ackMessage;

#define SYNC_INTERVAL 200
#define NUM_SOUNDS 4
#define NUM_LIGHT_PATTERNS 9

unsigned long lastSyncUpdate = 0;
unsigned long lastNewSyncMessage = 0;

String syncMessage;
String lastSyncMessage;

void TitanicTransmitter::Init(double frequency) {
    _loRaTransceiver.Init(frequency, 8,4,7);  
}

void TitanicTransmitter::Update() {  
    _receivedMessage = _loRaTransceiver.GetNextReceivedMessage();

    if (_receivedMessage.startsWith(F("1"))) {          
            ackMessage = _receivedMessage;
            return;
        } 


    if (_receivedMessage != EMPTY_STRING) {
        if (_receivedMessage.indexOf(COMMAND_SEPARATOR) > 0)
            {
                while (_receivedMessage.indexOf(COMMAND_SEPARATOR) > 0) {
                    processReceivedMessage(getValue(_receivedMessage, COMMAND_SEPARATOR, 0));
                    _receivedMessage = _receivedMessage.substring(_receivedMessage.indexOf(COMMAND_SEPARATOR)+1);
                }             
            }
            else 
                processReceivedMessage(_receivedMessage);
    }

    if (Serial.available()){        
        processSerialMessage(Serial.readString());
    }

    if (millis() - lastSyncUpdate > SYNC_INTERVAL) {
        syncMessage = getSyncMessage();

        if (syncMessage != ackMessage && millis() - lastNewSyncMessage > SYNC_INTERVAL * 3) {
            _loRaTransceiver.SendMessage(syncMessage);           
            lastNewSyncMessage = millis();
        }

        lastSyncUpdate = millis();
    }
}

String TitanicTransmitter::getSyncMessage() {
    return String(COMMAND_CODE_SET_THROTTLE) + COMMAND_CODE_DIVIDER + String(lastCommandMatrix[COMMAND_CODE_SET_THROTTLE]) + COMMAND_SEPARATOR +
           String(COMMAND_CODE_SET_TURN_ANGLE_DEGREES) + COMMAND_CODE_DIVIDER + String(lastCommandMatrix[COMMAND_CODE_SET_TURN_ANGLE_DEGREES]) + COMMAND_SEPARATOR;
}

void TitanicTransmitter::SetThrottle(int throttlePercent) {
    lastCommandMatrix[COMMAND_CODE_SET_THROTTLE] = throttlePercent;
}

void TitanicTransmitter::SetOrientation(int turningAngle) {
    lastCommandMatrix[COMMAND_CODE_SET_TURN_ANGLE_DEGREES] = turningAngle;
}

void TitanicTransmitter::PlaySound() {
    PlaySound(lastCommandMatrix[COMMAND_CODE_PLAY_SOUND]);
}

void TitanicTransmitter::PlaySound(uint8_t soundId) {
    lastCommandMatrix[COMMAND_CODE_PLAY_SOUND] = soundId;
    _loRaTransceiver.SendMessage(String(COMMAND_CODE_PLAY_SOUND) + COMMAND_CODE_DIVIDER + String(soundId));
}

void TitanicTransmitter::PlayNextSound() {
    lastCommandMatrix[COMMAND_CODE_PLAY_SOUND]++;

    if (lastCommandMatrix[COMMAND_CODE_PLAY_SOUND] > NUM_SOUNDS)
        lastCommandMatrix[COMMAND_CODE_PLAY_SOUND] = 0;    
}

void TitanicTransmitter::SetSteamMode(bool steamOn) {
    lastCommandMatrix[COMMAND_CODE_SET_STEAM_MODE] = steamOn ? 1 : 0;
    _loRaTransceiver.SendMessage(String(COMMAND_CODE_SET_STEAM_MODE) + COMMAND_CODE_DIVIDER + String(lastCommandMatrix[COMMAND_CODE_SET_STEAM_MODE]));  
}

void TitanicTransmitter::ToggleSteamMode() {
    lastCommandMatrix[COMMAND_CODE_SET_STEAM_MODE] = lastCommandMatrix[COMMAND_CODE_SET_STEAM_MODE] == 1 ? 0 : 1;
    _loRaTransceiver.SendMessage(String(COMMAND_CODE_SET_STEAM_MODE) + COMMAND_CODE_DIVIDER + lastCommandMatrix[COMMAND_CODE_SET_STEAM_MODE]);      
}

void TitanicTransmitter::ToggleReturnHomeMode() {
    lastCommandMatrix[COMMAND_CODE_RETURN_HOME] = lastCommandMatrix[COMMAND_CODE_RETURN_HOME] == 1 ? 0 : 1;
    _loRaTransceiver.SendMessage(String(COMMAND_CODE_RETURN_HOME) + COMMAND_CODE_DIVIDER + lastCommandMatrix[COMMAND_CODE_RETURN_HOME]);      
}

void TitanicTransmitter::SetLightPattern(uint8_t lightPattern) {
    lastCommandMatrix[COMMAND_CODE_SET_LIGHT_PATTERN] = lightPattern;
    _loRaTransceiver.SendMessage(String(COMMAND_CODE_SET_LIGHT_PATTERN) + COMMAND_CODE_DIVIDER + String(lightPattern));
}

void TitanicTransmitter::SetNextLightPattern() {
    currentLightPattern++;

    if (currentLightPattern > NUM_LIGHT_PATTERNS)
        currentLightPattern = 0;

    SetLightPattern(currentLightPattern);
}

void TitanicTransmitter::processSerialMessage(String message) {  
    _loRaTransceiver.SendMessage(message);    
}

void TitanicTransmitter::processReceivedMessage(String message) {   
    message.replace(F(";"), EMPTY_STRING);     
    _incomingMessageCommandCode = message.substring(0, message.indexOf(COMMAND_CODE_DIVIDER));
    _incomingMessageCommandValue = message.substring(message.indexOf(COMMAND_CODE_DIVIDER)+1);        

    switch(_incomingMessageCommandCode.toInt()) {        
      
        case STATUS_CODE_BATTERY_VOLT:
            RxBatteryVolt = _incomingMessageCommandValue.toFloat();
            break;        

        case STATUS_CODE_INTERNAL_WATER_LEVEL:
            RxWaterLevel = _incomingMessageCommandValue.toInt();
            break;

        case STATUS_CODE_STEAM_ENABLED:
            SteamOn = _incomingMessageCommandValue.toInt();
            break;

        case STATUS_CODE_DISTANCE_IN_METERS_FROM_START:
            MetersFromStart = _incomingMessageCommandValue.toFloat();
            break;

        case STATUS_CODE_FACING_DIRECTION:
            FacingDirection = _incomingMessageCommandValue;
            break;
    }

    RxRssi = _loRaTransceiver.Rssi;
}


String TitanicTransmitter::getValue(String data, char separator, int index)
{
    int found = 0;
    int strIndex[] = { 0, -1 };
    int maxIndex = data.length() - 1;

    for (int i = 0; i <= maxIndex && found <= index; i++) {
        if (data.charAt(i) == separator || i == maxIndex) {
            found++;
            strIndex[0] = strIndex[1] + 1;
            strIndex[1] = (i == maxIndex) ? i+1 : i;
        }
    }
    return found > index ? data.substring(strIndex[0], strIndex[1]) : EMPTY_STRING;
}