#include <TitanicCommunications.h>
#include <TitanicReceiver.h>
#include <LoRaTransceiver.h>
#include <TitanicSystemsController.h>
#include <String.h>

void TitanicReceiver::Init(double frequency) {
    Serial.println(F("Initlizing receiver..."));
    _loRaTransceiver.Init(frequency, 0, 3, 1);
    _systemsController.Init();    
    Serial.print("Done initlizing receive");
}

void TitanicReceiver::Update() {   
    _systemsController.Update();    
    _incomingMessage = _loRaTransceiver.GetNextReceivedMessage();  

     // acknowledge receipt of this sync message
    if (_incomingMessage.indexOf(COMMAND_SEPARATOR) > 0)
        _loRaTransceiver.SendMessage(_incomingMessage);

    if (_incomingMessage != EMPTY_STRING) {

        if (_incomingMessage.indexOf(COMMAND_SEPARATOR) > 0)
        {
            while (_incomingMessage.indexOf(COMMAND_SEPARATOR) > 0) {
                processIncomingMessage(_incomingMessage.substring(0, _incomingMessage.indexOf(COMMAND_SEPARATOR)));
                _incomingMessage = _incomingMessage.substring(_incomingMessage.indexOf(COMMAND_SEPARATOR)+1);
            }             
        }
        else 
            processIncomingMessage(_incomingMessage);
    }   

    if (millis() - _lastStatusSentAt > STATUS_UPDATE_INTERVAL) {
        transmitStatus();
         if (_systemsController.GetVoltage() < LOW_VOLTAGE_WARNING_AT) {            
            _systemsController.PlaySound(2);            
        }
        _lastStatusSentAt = millis();
    }   
}


String _currentStatusData = EMPTY_STRING;
void TitanicReceiver::transmitStatus() {   
    _currentStatusData = EMPTY_STRING;
    _currentStatusData += String(STATUS_CODE_BATTERY_VOLT) + COMMAND_CODE_DIVIDER + String(_systemsController.GetVoltage()) + COMMAND_SEPARATOR;
    _currentStatusData += String(STATUS_CODE_INTERNAL_WATER_LEVEL) + COMMAND_CODE_DIVIDER + String(_systemsController.GetWaterLevel()) + COMMAND_SEPARATOR;    
    _currentStatusData += String(STATUS_CODE_STEAM_ENABLED) + COMMAND_CODE_DIVIDER + String(_systemsController.SteamOn) + COMMAND_SEPARATOR; 
    _currentStatusData += String(STATUS_CODE_DISTANCE_IN_METERS_FROM_START) + COMMAND_CODE_DIVIDER + String(_systemsController.GetDistanceFromStart()) + COMMAND_SEPARATOR; 
    _currentStatusData += String(STATUS_CODE_FACING_DIRECTION) + COMMAND_CODE_DIVIDER + String(_systemsController.GetFacingDirection()) + COMMAND_SEPARATOR; 
    _loRaTransceiver.SendMessage(_currentStatusData);
}

int currentIncomingCommandValue = 0;
void TitanicReceiver::processIncomingMessage(String message) {      
    message.replace(String(COMMAND_SEPARATOR), EMPTY_STRING); 
    _incomingMessageCommandCode = message.substring(0, message.indexOf(COMMAND_CODE_DIVIDER));
    _incomingMessageCommandValue = message.substring(message.indexOf(COMMAND_CODE_DIVIDER)+1);

    currentIncomingCommandValue = _incomingMessageCommandValue.toInt();
    switch(_incomingMessageCommandCode.toInt()) {
        
        case COMMAND_CODE_SET_THROTTLE:    
            if (currentIncomingCommandValue > 50) return;
            if (currentIncomingCommandValue < -50) return;
            _systemsController.SetThrottle(currentIncomingCommandValue);
            break;

        case COMMAND_CODE_SET_TURN_ANGLE_DEGREES:   
            if (currentIncomingCommandValue > 45) return;
            if (currentIncomingCommandValue < -45) return;
            _systemsController.SetOrientation(currentIncomingCommandValue);
            break;        
      
        case COMMAND_CODE_SET_STEAM_MODE:
            _systemsController.SetSteamMode(currentIncomingCommandValue == 1 ? true : false);
            break;

        case COMMAND_CODE_PLAY_SOUND:
            _systemsController.PlaySound(currentIncomingCommandValue);
            break;

        case COMMAND_CODE_SET_LIGHT_PATTERN:
            _systemsController.SetLightCommand(_incomingMessageCommandValue.toInt());
            break;

        case COMMAND_CODE_RETURN_HOME:
            _systemsController.SetReturnHomeMode(_incomingMessageCommandValue.toInt());
            break;       
    }
}