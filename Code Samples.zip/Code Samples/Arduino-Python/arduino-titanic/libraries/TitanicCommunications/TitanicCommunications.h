#ifndef TitanicCommunications_h
#define TitanicCommunications_h

#include <Arduino.h>
#include <String.h>


    const static uint8_t COMMAND_CODE_SET_THROTTLE = 1; 
    const static uint8_t COMMAND_CODE_SET_TURN_ANGLE_DEGREES = 2;
    const static uint8_t COMMAND_CODE_SET_STEAM_MODE = 3;
    const static uint8_t COMMAND_CODE_PLAY_SOUND = 4;
    const static uint8_t COMMAND_CODE_SET_LIGHT_PATTERN = 5;   
    const static uint8_t COMMAND_CODE_RETURN_HOME = 6;   
    
    const static uint8_t STATUS_CODE_BATTERY_VOLT = 7;
    const static uint8_t STATUS_CODE_INTERNAL_WATER_LEVEL = 8;
    const static uint8_t STATUS_CODE_STEAM_ENABLED = 9;
    const static uint8_t STATUS_CODE_DISTANCE_IN_METERS_FROM_START = 10;
    const static uint8_t STATUS_CODE_FACING_DIRECTION = 11;    

    const static uint16_t STATUS_UPDATE_INTERVAL = 12000;    
    const static float LOW_VOLTAGE_WARNING_AT = 3.0;    //23.1
    
    const static char COMMAND_CODE_DIVIDER = '=';
    const static char COMMAND_SEPARATOR = ';';
    const static String EMPTY_STRING = "";

#endif

