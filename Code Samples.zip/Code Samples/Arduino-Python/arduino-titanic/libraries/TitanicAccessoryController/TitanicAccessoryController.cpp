#include <Arduino.h>
#include <TitanicAccessoryController.h>

void TitanicAccessoryController::Init() {   
    Serial.print(F("Starting AccessoryController "));
    _ioBoard.begin();        
    SetSteamMode(false);

    Serial.print(F("I2C Port Board Connected? "));
    Serial.println(_ioBoard.isConnected());
}

void TitanicAccessoryController::SetSteamMode(bool steamOn) {
    _ioBoard.write(0, steamOn ? HIGH : LOW); 
}