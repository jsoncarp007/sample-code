#ifndef TitanicAccessoryController_h
#define TitanicAccessoryController_h

#include <Arduino.h>
#include <PCF8574.h>

class TitanicAccessoryController
{
  public:   
    void Init();
    void SetSteamMode(bool steamOn);  

  private:
    PCF8574 _ioBoard = PCF8574(0x21);
};

#endif
