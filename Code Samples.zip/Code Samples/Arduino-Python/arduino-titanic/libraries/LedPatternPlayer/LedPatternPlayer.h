#ifndef LedPatternPlayer_h
#define LedPatternPlayer_h

#include <Arduino.h>
#include <String.h>

class LedPatternPlayer
{
  public:
    LedPatternPlayer()  {} //130
    void Init();
    void ExecuteLightCommandCode(uint8_t commandCode);
    void Update();
    void SetPixel(int Pixel, byte red, byte green, byte blue) { setPixel(Pixel, red, green, blue);}
  private:
    void executeCurrentCommand();    
    void normalLights(short brightness);   
    void clearCylon();
    void startCylon(byte red, byte green, byte blue, short eyeSize, short startPosition, short endPosition, bool startDirectionUp); 
    void runCylon();
    void startFlicker(bool partyMode, int updateDelay);
    void runFlicker();
    void setRandomColor(int pixelNumber);
    bool isPixelBlack(int pixelNumber);
    int getRandomPixel();
    void setAll(byte red, byte green, byte blue);
    void setPixel(int Pixel, byte red, byte green, byte blue);
    void showStrip();
    uint8_t activeCommandCode = 0;
    unsigned long lastUpdate = 0;
    int patternInterval = 200;
    
};

#endif
