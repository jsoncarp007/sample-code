#include <Arduino.h>
#include <CylonPattern.h>
#include <FastLED.h>

void CylonPattern::Update() {
    if (_movingForward && _eyePosition < _endPosition - _eyeSize) {
        _eyePosition++;
    }
    else if (!_movingForward && _eyePosition > _startPosition + _eyeSize)    
        _eyePosition--;
    
    else _movingForward = !_movingForward;
    
    setPixel(_eyePosition, _red/10, _green/10, _blue/10);
    for(int j = 1; j <= _eyeSize; j++) {
        setPixel(_eyePosition+j, _red, _green, _blue);
    }
    setPixel(_eyePosition+_eyeSize+1, _red/10, _green/10, _blue/10); 
}


void CylonPattern::setPixel(int pixel, byte red, byte green, byte blue) {
 
  // NeoPixel
  // strip.setPixelColor(Pixel, strip.Color(red, green, blue));

   // FastLED
   _player->SetPixel(pixel,red,green,blue);

}