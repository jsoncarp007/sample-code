#ifndef CylonPattern_h
#define CylonPattern_h

#include <Arduino.h>
#include <String.h>
#include <FastLED.h>
#include <LedPatternPlayer.h>

class CylonPattern {
    public: 
        CylonPattern() { }
        CylonPattern(short startPosition, short endPosition, byte red, byte green, byte blue, short eyeSize, bool startDirectionUp, LedPatternPlayer *patternPlayer) {
            _startPosition = startPosition;
            _eyePosition = startDirectionUp ? startPosition + eyeSize : endPosition - eyeSize;
            _endPosition = endPosition;
            _red = red;
            _green = green;
            _blue = blue;
            _eyeSize = eyeSize;           
            _numLeds = 130;
            _movingForward = startDirectionUp;
            _player = patternPlayer;
        }
        void Update();
        
    private:
        void setPixel(int pixel, byte red, byte green, byte blue);
        LedPatternPlayer *_player;
        byte _red;
        byte _green;
        byte _blue;
        short _eyeSize;
        short _startPosition;
        short _endPosition;
        short _eyePosition;
        bool _movingForward;       
        short _numLeds; 
};

#endif