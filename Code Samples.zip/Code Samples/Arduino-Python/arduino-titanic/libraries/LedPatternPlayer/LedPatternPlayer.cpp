#include <Arduino.h>
#include <LedPatternPlayer.h>
#include <CylonPattern.h>
#include <FastLED.h>

#define NUM_LEDS 130
CRGB leds[NUM_LEDS];
#define PIN 8

#define NUM_PATTERNS 4
CylonPattern patterns[NUM_PATTERNS];
short currentPatternIndex;

void LedPatternPlayer::Init() {
  FastLED.addLeds<WS2811, PIN, GRB>(leds, NUM_LEDS).setCorrection( TypicalLEDStrip );
}

void LedPatternPlayer::Update() {
    if (activeCommandCode == 0) return;
    
    if(millis() - lastUpdate > patternInterval)
        executeCurrentCommand();
}

void LedPatternPlayer::ExecuteLightCommandCode(uint8_t commandCode) {    
  activeCommandCode = commandCode;
  
  setAll(0,0,0);

  if (activeCommandCode == 9) { startFlicker(true, 10); }
  if (activeCommandCode == 8) { startFlicker(true, 200); }
  if (activeCommandCode == 7) { startFlicker(false, 1000); }
  if (activeCommandCode == 6) { 
    patternInterval = 5;
    clearCylon();
    
    startCylon(0xff, 0, 0, 4, 0, NUM_LEDS/2, true);
    startCylon(0xff, 0xff, 0xff, 4, 0, NUM_LEDS/2, false);

    startCylon(0xff, 0, 0, 4, NUM_LEDS/2, NUM_LEDS, true);    
    startCylon(0xff, 0xff, 0xff, 4, NUM_LEDS/2, NUM_LEDS, false);

    showStrip();
  }
  if (activeCommandCode == 5) {
    patternInterval = 10;
    clearCylon();
    startCylon(0xff, 0, 0, 4, 0, NUM_LEDS, true); 
    showStrip();
  }
  if (activeCommandCode == 4) { 
    patternInterval = 5;
    clearCylon();
    
    startCylon(0xff, 0, 0, 4, 0, NUM_LEDS/2, true);
    startCylon(0, 0, 0xff, 4, 0, NUM_LEDS/2, false);

    startCylon(0xff, 0, 0, 4, NUM_LEDS/2, NUM_LEDS, true);    
    startCylon(0, 0, 0xff, 4, NUM_LEDS/2, NUM_LEDS, false);

    showStrip();
  }
  if (activeCommandCode == 3) { normalLights(255); }
  if (activeCommandCode == 2) { normalLights(50); }
  if (activeCommandCode == 1) { normalLights(5); }    
}

void LedPatternPlayer::executeCurrentCommand() { 
  if (activeCommandCode == 4) { setAll(0,0,0); runCylon(); }    
  if (activeCommandCode == 5) { setAll(0,0,0); runCylon(); }    
  if (activeCommandCode == 6) { setAll(0,0,0); runCylon(); }    
  if (activeCommandCode == 7) { runFlicker(); }
  if (activeCommandCode == 8) { runFlicker(); }
  if (activeCommandCode == 9) { runFlicker(); }
  showStrip();
  lastUpdate = millis(); 
}

void LedPatternPlayer::startCylon(byte red, byte green, byte blue, short eyeSize, short startPosition, short endPosition, bool startDirectionUp) { 
   if (currentPatternIndex > NUM_PATTERNS)
    currentPatternIndex = 0;
  patterns[currentPatternIndex] = CylonPattern(startPosition, endPosition, red, green, blue, eyeSize, startDirectionUp, this);
  currentPatternIndex++;
  FastLED.setBrightness(255);
}

void LedPatternPlayer::runCylon() {
  for (int i=0;i<=currentPatternIndex-1;i++) 
    patterns[i].Update();

  showStrip();  
}

void LedPatternPlayer::clearCylon() {
  currentPatternIndex = 0;
}

bool inPartyMode = false;
void LedPatternPlayer::startFlicker(bool partyMode, int updateDelay) {
  patternInterval = updateDelay;
  inPartyMode = partyMode;
  setAll(0,0,0);

  // pick a random number of lights to turn on 
  for (int i = 0; i<50 ;i++) {      
    setPixel(getRandomPixel(), 0xff, 0xff, 0xff);
  } 
  showStrip();
}

void LedPatternPlayer::runFlicker() {
  for(int i=0;i<2;i++) {
      int currentPixel = getRandomPixel();
      if (i % 2 == 0)
        { 
           setPixel(currentPixel, 0xff, 0xff, 0xff);          
        }
        else setPixel(currentPixel, 0, 0, 0);
  } 
}

void LedPatternPlayer::normalLights(short brightness) {  
  patternInterval = 100000;
  FastLED.setBrightness(brightness);
  setAll(255,255,255);
  showStrip();  
}

int LedPatternPlayer::getRandomPixel() {
  return random(0, NUM_LEDS-1);
}

bool LedPatternPlayer::isPixelBlack(int pixelNumber) {
  return leds[pixelNumber].r == byte(0) && leds[pixelNumber].g == byte(0) && leds[pixelNumber].b == byte(0);
}

void LedPatternPlayer::setRandomColor(int pixelNumber) {
  setPixel(pixelNumber, byte(random(0,255)), byte(random(0,255)), byte(random(0,255)));
}

void LedPatternPlayer::showStrip() {

   // NeoPixel
   //strip.show();
 
   // FastLED
   FastLED.show();

}

void LedPatternPlayer::setPixel(int Pixel, byte red, byte green, byte blue) {
 
  // NeoPixel
  // strip.setPixelColor(Pixel, strip.Color(red, green, blue));

   // FastLED
   leds[Pixel].r = red;
   leds[Pixel].g = green;
   leds[Pixel].b = blue;

}

void LedPatternPlayer::setAll(byte red, byte green, byte blue) {
  for(int i = 0; i < NUM_LEDS; i++ ) {
    setPixel(i, red, green, blue);
  }
  showStrip();
}
