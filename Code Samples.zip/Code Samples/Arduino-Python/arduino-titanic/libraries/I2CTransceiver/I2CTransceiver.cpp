#include <I2CTransceiver.h>
#include <Wire.h>

static byte buffer[5];
static boolean receiveFlag = false;

static void clearBuffer() {
    for (int i=0;i<5;i++)
        buffer[i] = 0;
    
    receiveFlag = false;
}

static void receiveEvent(int howMany)
{
  Wire.readBytes(buffer, howMany);
  receiveFlag = true;
}


void I2CTransceiver::Init(short address) {
    Wire.begin(address);
    Wire.onReceive(receiveEvent);
}

void I2CTransceiver::Update() {

}

void I2CTransceiver::Send(byte message, int targetDeviceAddress) {
    Wire.beginTransmission(targetDeviceAddress);
    Wire.write(message);
    Wire.endTransmission();
}


byte I2CTransceiver::GetIncomingMessage() {
    if (!receiveFlag) return 0;
    receiveFlag = false;
    return buffer[0];
} 

