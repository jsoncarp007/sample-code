
#ifndef I2CTransceiver_h
#define I2CTransceiver_h

#include <Arduino.h>
#include <String.h>

class I2CTransceiver{
    public:       
        void Init(short address);
        void Update();  
        void Send(byte message, int targetDeviceAddress);      
        byte GetIncomingMessage();
    private:      
       
};

#endif
