#include <Arduino.h>
#include <String.h>
#include <YX5300AudioPlayer.h>
#include <SoftwareSerial.h>
#include <MD_YX5300.h>

void YX5300AudioPlayer::Init() {
    Serial.print(F("Starting audio player... "));
    mp3Stream.begin(MD_YX5300::SERIAL_BPS);
    mp3.begin();
    mp3.setSynchronous(true);   
    mp3.volumeMax();
    Serial.println(F("Done"));
}

void YX5300AudioPlayer::Update() {
    //mp3.check();
}

void YX5300AudioPlayer::PlaySound(uint8_t soundId) { 
    mp3.playTrack(soundId);
}