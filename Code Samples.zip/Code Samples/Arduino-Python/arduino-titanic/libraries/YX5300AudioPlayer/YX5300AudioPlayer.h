#ifndef YX5300AudioPlayer_h
#define YX5300AudioPlayer_h

#include <Arduino.h>
#include <SoftwareSerial.h>
#include <MD_YX5300.h>

class YX5300AudioPlayer
{
  public:
    YX5300AudioPlayer() : mp3Stream(50,6), mp3(mp3Stream) {}
    void Init();
    void PlaySound(uint8_t soundId);
    void Update();
   
  private:    
    SoftwareSerial mp3Stream;
    MD_YX5300 mp3;   
};

#endif
