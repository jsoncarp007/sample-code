#ifndef TitanicLocomotion_h
#define TitanicLocomotion_h

#include <Arduino.h>
#include <Adafruit_PWMServoDriver.h>

class TitanicLocomotion
{
  public:
    void Init();
    void SetThrottle(int throttlePercent);
    void SetOrientation(int turningAngle);   
    int TurningAngle = 0;
    int ThrottlePercent = 0;

  private:
    void updateHardwareState();
    void updateMainMotorState();
    void updateRightMotorState();
    void updateLeftMotorState();
    void updateRudderServoState();
    int getServoPinValueForTurningAngle(int turningAngle);
    int getServoPinValueForThrottlePercent(int throttlePercent);
    void setServoValue(short servo, short servoPinValue);
    
    Adafruit_PWMServoDriver _pwmServo = Adafruit_PWMServoDriver();

};

#endif
