#include <Arduino.h>
#include <TitanicLocomotion.h>

#define SERVOMIN  85 // This is the 'minimum' pulse length count (out of 4096)
#define SERVOMAX  485 // This is the 'maximum' pulse length count (out of 4096)

// #define ESCMIN  150 // This is the 'minimum' pulse length count (out of 4096)  -150 / 600
// #define ESCMAX  625 // This is the 'maximum' pulse length count (out of 4096)

#define ESCMIN  800 // This is the 'minimum' pulse length count (out of 4096)  -150 / 600
#define ESCMAX  2200 // This is the 'maximum' pulse length count (out of 4096)

void TitanicLocomotion::Init() {
    Serial.print(F("Initilizing Servo controller... "));
    ThrottlePercent = 0;
    TurningAngle = 0;

    _pwmServo.begin();
    _pwmServo.setOscillatorFrequency(27000000);
    _pwmServo.setPWMFreq(50);  // This is the maximum PWM frequency   
    updateHardwareState();
    Serial.println("Done");
}

void TitanicLocomotion::SetThrottle(int throttlePercent) {
    if (throttlePercent > 50) return;
    if (throttlePercent < -50) return;
    ThrottlePercent = throttlePercent;
    updateHardwareState();      
}

void TitanicLocomotion::SetOrientation(int turningAngle) {
    if (turningAngle > 50) return;
    if (turningAngle < -50) return;
    TurningAngle = turningAngle;
    updateHardwareState();    
}

void TitanicLocomotion::updateHardwareState() {  
        updateRudderServoState();    
        updateMainMotorState();
        updateLeftMotorState();
        updateRightMotorState();        
}

void TitanicLocomotion::updateMainMotorState() {  
    setServoValue(1, getServoPinValueForThrottlePercent(ThrottlePercent));  
}

void TitanicLocomotion::updateRightMotorState() {
    setServoValue(2, getServoPinValueForThrottlePercent(ThrottlePercent * (TurningAngle > 0 ? (map(TurningAngle,0,45,0,100)*.01) : 1)));
}

void TitanicLocomotion::updateLeftMotorState() {
    setServoValue(3, getServoPinValueForThrottlePercent(ThrottlePercent * (TurningAngle < 0 ? (map(TurningAngle,-45,0,0,100)*.01) : 1)));
}

void TitanicLocomotion::updateRudderServoState() {
    //setServoValue(0, getServoPinValueForTurningAngle(TurningAngle));    
    _pwmServo.setPWM(0, 0, getServoPinValueForTurningAngle(TurningAngle));   
}

void TitanicLocomotion::setServoValue(short servoNumber, short value) {
    _pwmServo.writeMicroseconds(servoNumber, value);
}

int TitanicLocomotion::getServoPinValueForTurningAngle(int turningAngle) {
    return map(turningAngle, 90, -90, SERVOMIN, SERVOMAX);
}

int TitanicLocomotion::getServoPinValueForThrottlePercent(int throttlePercent) {
    return map(throttlePercent, -50, 50, ESCMIN, ESCMAX);
}