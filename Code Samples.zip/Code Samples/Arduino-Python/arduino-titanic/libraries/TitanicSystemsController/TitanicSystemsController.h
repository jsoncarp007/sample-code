
/////////////////////////////
// TitanicSystemsController.h
//////////////////////////////

#ifndef TitanicSystemsController_h
#define TitanicSystemsController_h

#include <Arduino.h>
#include <TitanicAccessoryController.h>
#include <TitanicLocomotion.h>
#include <TitanicSensorDataCollector.h>
#include <YX5300AudioPlayer.h>
#include <I2CTransceiver.h>
#include <GpsReceiver.h>

class TitanicSystemsController
{
  public:       
    void Init();
    void Update();

    void SetThrottle(int throttlePercent);
    void SetOrientation(int turningAngle);
    void PlaySound(uint8_t soundId);
    void SetSteamMode(bool steamOn);
    void SetLightCommand(byte lightCommand);
    void SetReturnHomeMode(bool returnHomeModeOn) {
      returnHomeMode = returnHomeModeOn;
    }
    
    float GetVoltage() { return SensorDataCollector.GetVoltage(); }
    float GetDistanceFromStart() { return Gps.GetMetersToHome(); }
    uint8_t GetWaterLevel();    
    const char GetFacingDirection() { return *Gps.GetHeadingDirection(); }

    bool SteamOn;
    uint8_t LastSoundId;    
    
    TitanicAccessoryController AccessoryController;
    TitanicLocomotion Locomotion;
    YX5300AudioPlayer AudioPlayer;
    I2CTransceiver I2C;
    TitanicSensorDataCollector SensorDataCollector;
    GpsReceiver Gps;    

  private:
    void executeReturnHome();    
    bool returnHomeMode = false;
};

#endif
