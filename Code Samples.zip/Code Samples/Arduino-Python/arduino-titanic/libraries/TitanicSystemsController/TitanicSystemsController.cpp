#include <Arduino.h>
#include <TitanicSystemsController.h>

unsigned long lastReturnHomeAction = millis();
unsigned long lastTransmitterMessage = millis();

void TitanicSystemsController::Init() { 
    Serial.println(F("Starting systems controller... "));
    AccessoryController.Init();
    AudioPlayer.Init();                
    Locomotion.Init();
    I2C.Init(12);
    SensorDataCollector.Init();
    Gps.Init();    
    Serial.println("Systems controller started");
}

uint8_t TitanicSystemsController::GetWaterLevel() {    
    return SensorDataCollector.GetWaterLevel();
}

void TitanicSystemsController::SetThrottle(int throttlePercent) {  
    Locomotion.SetThrottle(throttlePercent);
}

void TitanicSystemsController::SetOrientation(int turningAngle) {      
    Locomotion.SetOrientation(turningAngle);
}

void TitanicSystemsController::PlaySound(uint8_t soundNumber) {    
    LastSoundId = soundNumber;
    AudioPlayer.PlaySound(soundNumber);
}

void TitanicSystemsController::SetSteamMode(bool steamOn) {   
    SteamOn = steamOn;
    AccessoryController.SetSteamMode(steamOn);
}

void TitanicSystemsController::SetLightCommand(byte lightCommand) {      
    I2C.Send(lightCommand, 9);
}

int currentUpdateIndex = 0;
void TitanicSystemsController::Update() {
    switch (currentUpdateIndex){
        case 0:
            Gps.Update();
        break;
        case 1: 
            AudioPlayer.Update();
        break;
        case 2:
            I2C.Update();    
        break;
        case 3:        
            SensorDataCollector.Update();
        break;
        case 4:
            currentUpdateIndex = 0;
        break;        
    }
    currentUpdateIndex++;

    if (returnHomeMode && millis() - lastReturnHomeAction > 5000){
        executeReturnHome();
        lastReturnHomeAction = millis();
    }
    else if (!returnHomeMode && millis() - lastTransmitterMessage > 300000 && Gps.HasGpsFix && SensorDataCollector.GetVoltage() < 15.0) {
        Serial.println(F("Returning home, battery low!"));
        returnHomeMode = true;
    }
}

void TitanicSystemsController::executeReturnHome() {  
    Locomotion.SetOrientation(Gps.GetTurnDegreesToHome());
    Locomotion.SetThrottle(100);

    if (Gps.GetMetersToHome() < .1) {
        Locomotion.SetThrottle(0);
        returnHomeMode = false;
    }
    else if (Gps.GetMetersToHome() < 2) {
        Locomotion.SetThrottle(25);
    }
}
