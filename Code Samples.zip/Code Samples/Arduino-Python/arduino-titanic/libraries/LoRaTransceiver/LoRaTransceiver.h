#ifndef LoRaTransceiver_h
#define LoRaTransceiver_h

#include <Arduino.h>
#include <String.h>

class LoRaTransceiver {
    public:           
        void Init(double frequency, int ss, int reset, int dio);       
        String GetNextReceivedMessage();
        void SendMessage(String message);   
        unsigned long GetLastMessageReceivedMs() { return lastReceivedMessage;}
        int Rssi;
    private:
        void startLoRa(double frequency, int ss, int reset, int dio);
        String getIncomingMessage();
        String incomingMessage;       
        unsigned long lastReceivedMessage;
};

#endif