#include <Arduino.h>
#include <String.h>
#include <LoRaTransceiver.h>
#include <TitanicCommunications.h>
#include <SPI.h>
#include <LoRa.h>

const static String LORA_IDENTIFIER = "LoRa";
const static String LORA_DIVIDER = "|";

void LoRaTransceiver::Init(double frequency, int ss, int reset, int dio) {     
    startLoRa(frequency, ss, reset, dio);      
}

void LoRaTransceiver::SendMessage(String message) {
  Serial.print(F("Sending: " ));
  Serial.println(message);
    LoRa.beginPacket();
    LoRa.print(LORA_IDENTIFIER + message + LORA_DIVIDER + message);
    LoRa.endPacket();    
}

String LoRaTransceiver::GetNextReceivedMessage() {
    return getIncomingMessage();     
}

void LoRaTransceiver::startLoRa(double frequency, int ss, int reset, int dio) {  
  Serial.print(F("Starting LoRa... "));
    LoRa.setPins(ss, reset, dio);
    LoRa.begin(frequency);
    LoRa.setTxPower(20);       
    Serial.println(F("Done"));
}

String currentMessage;
String currentMessageChecksum;

String LoRaTransceiver::getIncomingMessage() {  
  incomingMessage = EMPTY_STRING;
  if (LoRa.parsePacket()){
    while (LoRa.available())           
      incomingMessage=incomingMessage+((char)LoRa.read());   

      if (incomingMessage != EMPTY_STRING)
        Serial.println(incomingMessage); 
      
      if (!incomingMessage.startsWith(LORA_IDENTIFIER)) {
          incomingMessage = EMPTY_STRING;             
      }
      else {
        incomingMessage.replace(LORA_IDENTIFIER, EMPTY_STRING);          
      }

      // split the message by the divider and make sure the strings match, otherwise reject
      currentMessage = incomingMessage.substring(0, incomingMessage.indexOf(LORA_DIVIDER));
      currentMessageChecksum = incomingMessage.substring(incomingMessage.indexOf(LORA_DIVIDER)+1);

      if (currentMessage != currentMessageChecksum) 
        incomingMessage = EMPTY_STRING;
      else 
        incomingMessage = currentMessage;

      if (incomingMessage != EMPTY_STRING) {
        lastReceivedMessage = millis();
        Rssi = LoRa.packetRssi();   
      }
  }
  
  return incomingMessage;    
}